# Roadmap

- [x] Field timeline above graph: field-only in/out handles; separate full-width playback timeline and transport

- [x] Start time per node (Timing → Start on effectors, fields, sine waves, masks)
- [x] Animate phase view: timeline with draggable Start bars per node
- [ ] Node-by-node pass: review and refine every node's settings one at a time
  - [x] Uniform scale (Build): linked XYZ scaling on Plain Effector and Transform
  - [x] Text node (Build): whole-text or centered line splitting
  - [x] Spherical Field: XYZ center and start/end radius (Build); absolute start/end time and preset/custom easing (Animate), preserving legacy looping fields until edited
  - [x] Mask: XYZ clipping axis (Build), absolute start/end time and preset/custom easing (Animate); legacy linear wipes preserved
  - [x] Sine Wave (Animate): sine/triangle/square/sawtooth, phase in degrees and neutral-to-full strength; legacy sine and clone-offset timing preserved
  - [x] Delay Effector (Animate): per-clone stagger in seconds, reverse incoming order and bypass-to-full strength; preserve legacy spring response and cached deterministic sampling
  - [x] Linear Field: start and end point; no Speed setting — it sweeps from start to end over its time span; choose an ease curve (linear, ease in/out, custom curve graph) for how it moves across the plane (curve choice is Animate-phase)
  - [ ] Other nodes: to be specified one by one (end time, easing, etc.)
- [x] Transform node (Build): offset position, rotation (X/Y/Z) and scale of whatever flows through it
- [x] Cameras (Setup/Look): named scene cameras, position, target, orthographic/perspective, lens/zoom, active render camera; undoable controls and matching preview/video
- [ ] Animated camera moves (Animate): start/end poses and motion curves
- [x] Merge Build and Animate into one workspace — Build has the full-width graph and collapsible timeline, shared selection/undo and an always-visible preview; Export retains Scene JSON
- [x] Scene JSON (Export): move out of the Build inspector into an Export option with JSON download
- [x] 3D inspection preview: Front/3D selector, perspective orbit/pan/zoom, floor grid/axes, guides toggle and reset; inspection does not change the render camera (Setup/Look)
- [x] 3D cloner settings (Build): Grid Count Z and depth spacing; Radial XY/XZ/YZ plane
- [x] 3D Plain Effector settings (Build): weighted position and rotation offsets across XYZ; shared field, sine, Spring and Delay influence
- [x] Render to video (MP4 from the Render button)
- [x] Render at true 1920x1080 (off-screen, framed for 16:9)
- [x] After Effects export (.jsx script, baked keyframes per clone)
- [ ] AE export: carry Mask reveals over (as AE track mattes/masks)
- [ ] AE export (Export): support full 3D Transform matrices; current 2D export explicitly rejects depth, X/Y rotation and shear
- [ ] AE export (Export): support custom scene cameras; current flat export explicitly requires Auto framing
- [x] Scene length, frame rate and seconds/frames counter (collapsible Scene strip under the playbar)
- [x] Grab a wire anywhere along its length in the graph
- [x] Stacked cloners nest (Grid → Radial = a ring at every grid point)
- [x] Output formats: 16:9, 9:16, 1:1, 4:5 and custom size (Scene strip; really a Setup-phase setting)
- [ ] AI-ready engine: an AI gets a reference (video/image/brief) and rebuilds the animation using only the existing nodes — needs a documented node catalog/JSON schema, validation of AI-written scene docs, and an AI "generate scene" flow
- [ ] Batch render (Export): attach a sheet (CSV/Google Sheet) to a Text node, map columns to node fields, render one video per row (e.g. 100 text variants) with names from a column

## Fusion-inspired pass
- [x] 1. Keyframes on settings (diamond, prev/next, Linear/Smooth/Hold)
- [x] Key ticks on playback bar
- [x] Keys on Position/Rotation XYZ (Transform, Plain Effector)
- [ ] 1b. Keys on Scale; custom Bezier per key
- [ ] 2. Spline editor tab above the graph
- [ ] 3. Dual A/B viewer + Fusion-style viewer toolbar
- [ ] 4. Shift+Space "Add tool" search, tile nodes, drop-wire-to-search
