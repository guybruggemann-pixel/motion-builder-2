# 3D cloner controls

- Add Count Z and Depth spacing to Grid Cloner. Existing scenes remain a single flat layer until depth is changed.
- Add XY / XZ / YZ plane selection to Radial Cloner. Existing rings remain in XY.
- Keep stacked-cloner behavior and static transforms intact. Store every setting in the scene document for deterministic playback, video export and future AI generation.
- Update node summaries to show depth and plane settings.
- Make the current flat After Effects export reject nonzero clone depth rather than silently flattening it.
- Leave 3D effector offsets as a separate remaining Build task.

## Verification
- Test centered depth layers, ring coordinates on all planes, legacy flat output, stacked clone counts, transform composition, undo/redo and AE depth rejection.
- Check the controls in the live workspace, orbit the resulting scene in 3D, and render a perspective-camera video with depth visible.