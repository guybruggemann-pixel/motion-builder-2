# Mask node refinement

- Add X/Y/Z clipping-axis choices and retain the existing edge start/end and invert controls.
- Add absolute start/end times and preset/custom easing, matching the field controls. Hold the first edge before the interval and the last edge afterwards; reversed endpoints support opposite-direction wipes.
- Show the Mask interval in Animate. Keep existing scenes linear and ending at the scene duration unless edited.
- Verify editing, playback, undo/redo and clipping in the live preview, plus deterministic engine tests.

## Technical details

Persist optional end/curve/Bézier values in the scene document. Share interval and easing helpers with fields, and extend GPU clipping normals to the Z axis. Preview, bake and video export consume the same evaluated clip values. AE Mask export remains on the roadmap.