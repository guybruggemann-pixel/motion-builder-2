# Fusion-inspired workspace for motion graphics

Recommendation on keyframes: stay procedural-first, keyframes as an opt-in layer. Any number setting can be keyed (diamond next to it), but keys are stored in the scene file as plain curves, so fields, effectors and AI generation keep working. Procedural nodes remain the main way to animate many clones; keyframes are for "hero" values (camera move, one transform, a field endpoint).

## Delivered in 4 steps

1. **Keyframes on settings**
   - Diamond button next to every numeric setting in the Inspector: add/remove key at the playhead; filled when on a key, outlined when animated.
   - Prev/next key arrows. Keys show as ticks on the playback bar for the selected node.
   - Easing per key: linear, smooth, hold, custom Bezier.

2. **Spline editor**
   - New tab in the strip above the graph: Timeline (field in/out) | Spline.
   - Lists animated settings of the selected node; draw curves value-over-time, drag keys and Bezier handles, zoom/frame-all.

3. **Viewer layout**
   - Optional dual viewer (A/B side by side): e.g. A = camera output, B = 3D orbit. Toggle 1 or 2 viewers.
   - Viewer toolbar like Fusion: view mode, guides, safe frames, fit.

4. **Node flow feel**
   - Quick "Add tool" search (Shift+Space) at the mouse position.
   - Tile-style compact nodes with category color strip, cleaner pipe routing, wire dropped on empty space opens the search pre-filtered.

## Technical details
- Schema: optional `anim?: Record<paramPath, Key[]>` per node; Key = { t, v, ease, bezier? }. Missing = static (legacy docs unchanged).
- `src/engine/keyframes.ts`: pure `sampleParam(node, path, t)`; evaluate resolves animated params before node logic, stays deterministic and cached by bake.
- AE export bakes keyed values through existing getFrame path.
- Viewer B reuses the lazy Preview3D with its own inspection store instance; capture still uses the output camera.
- Tests: key sampling/easing, legacy docs unchanged, determinism.
- Roadmap/AGENTS.md updated.
