# Wave node refinement

- Keep the Sine Wave node and add a wave-shape selector: sine, triangle, square, or sawtooth.
- Add phase in degrees and strength from 0–100%. Zero strength leaves the incoming field influence unchanged; full strength applies the selected wave.
- Retain frequency, per-clone offset, and start time. Existing scenes keep their current sine motion and pre-start behavior.
- Show the chosen shape in the graph and verify connected playback, editing, undo/redo and deterministic results.

## Technical details

Persist optional waveform, phase and strength values in the scene document. A pure wave helper feeds the same effector weight path used by preview, Spring/Delay simulation, bake and exports. Wave shaping is an Animate-phase refinement; Build/Animate merging remains undecided.