# Uniform scaling and next node refinement

- Add a Uniform scale toggle and single scale value to Plain Effector and Transform; keep independent XYZ controls available.
- Turning uniform scaling on uses the current X value for all three axes. Old scenes remain unchanged until edited.
- Store the choice in the scene document, with undo/redo and identical preview, bake and export behavior.
- Continue the node review by exposing Text node's existing whole-text/line splitting setting.

## Technical details
- Reuse the attached design system's Switch, Input and Tabs controls.
- Keep scale vectors authoritative; use shared pure scale-edit helpers and regression tests for linking, independent edits, legacy scenes and undo/redo.
- Verify both scale controls and text splitting through the running editor.