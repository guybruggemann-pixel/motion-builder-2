# Editable render cameras

## What changes
- Add named scene cameras with position and target (X/Y/Z), orthographic or perspective projection, zoom or field of view, and an active-camera selector.
- Keep camera settings in a collapsible Camera strip beside the existing Scene settings, available without leaving Build. Camera setup belongs to Setup/Look; animated camera moves remain on the roadmap for Animate.
- Support adding, renaming, duplicating and deleting cameras, with undo/redo. An Auto framing option preserves the current view for existing scenes.
- Show the active camera’s framing in the output preview. Keep the separate 3D inspection view, guides, orbit, pan and zoom independent from exported output.
- Render video using the same active camera and framing as the output preview at every output size.
- Reject unsupported custom cameras in the current flat After Effects export rather than silently exporting a different picture.

## Technical approach
- Store cameras and active camera ID in the serializable scene document; legacy documents without cameras retain existing automatic front framing.
- Centralize camera resolution and projection settings in a browser-safe engine module shared by preview and off-screen render.
- Compose camera controls from the attached design system and keep Three.js behind the existing lazy-loaded preview boundary.
- Update project rules and roadmap to distinguish editable static cameras from future animated camera moves.

## Verification
- Test legacy framing, active-camera selection, valid camera settings, undo/redo and export compatibility.
- Check adding a perspective camera, changing its position/target/lens, switching cameras, and reading settings back through the UI.
- Compare preview and rendered video for custom cameras, then orbit in inspection mode and confirm video output remains unchanged.
- Verify the preview remains visible and controls fit the workspace at wide and narrow window sizes.