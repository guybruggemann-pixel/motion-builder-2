# Orbitable 3D preview

- Add a Front / 3D view selector above the preview. Front remains the default and shows the existing output framing.
- In 3D, orbit, pan and zoom around the scene, with a subtle floor grid and token-coloured X/Y/Z axes.
- Add guide visibility and a reset-view action. Keep the preview visible above the full-width graph in every phase.
- Keep inspection separate from the render camera: orbiting and guides must never alter exported video or After Effects output.
- Keep camera setup and animation, plus cloner depth controls, on the roadmap as later work.

## Technical details

- Use the existing lazy-loaded Three.js preview and Drei camera/orbit controls. Keep inspection state in a separate browser-safe store; no output-affecting state lives outside the scene document.
- Frame the inspection camera from the evaluated scene, including Z positions. Preserve the user's orbit during playback and reset only on explicit request.
- Render guide objects on an inspection-only camera layer. Off-screen captures always use the existing fixed orthographic front camera without guide layers.
- Verify orbit, zoom, reset, guide toggle and mode switching in the running editor; compare rendered frames before and after orbiting to confirm export isolation.