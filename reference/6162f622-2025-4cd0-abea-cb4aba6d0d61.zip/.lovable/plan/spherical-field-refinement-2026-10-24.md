# Spherical Field refinement

- Add an editable XYZ center and start/end radius to Spherical Field.
- Replace Grow speed with start/end times and the same preset/custom motion curves used by Linear Field.
- Hold the starting radius before the interval and the ending radius afterwards; support shrinking as well as growing.
- Show the interval in Animate while keeping the preview visible. Center and radii belong in Build; timing and easing belong in Animate.
- Preserve old speed-based scenes until the field is explicitly edited.

## Technical details
- Store all settings in the serializable scene document; reuse existing design-system controls and curve utilities.
- Evaluate influence from static clone positions relative to the field center in XYZ.
- Add deterministic tests for radius motion, center/depth influence, legacy compatibility, undo/redo and cache invalidation.
- Verify connected-field playback and setting readback in the editor.