# Refine the Linear Field

## What changes
- Add explicit start and end positions for the field’s sweep across the X axis.
- Replace **Sweep speed** with **Start** and **End** times. Motion reaches its endpoint over that interval and holds there afterward; it repeats only when scene playback loops.
- Add selectable motion curves: Linear, Ease in, Ease out, Ease in/out, and Custom, with a curve graph and editable Bézier controls.
- Keep spatial settings in the field’s inspector and motion controls under Timing. Leave the decision to merge Build and Animate open.
- Update the Animate timeline to show the Linear Field’s actual start–end interval.

## Technical details
- Store endpoints, end time, and curve parameters in the serializable scene document so AI, baking, video rendering, and AE export use the same deterministic motion.
- Preserve compatibility with older scene documents that only contain Speed; new and edited fields use the new interval model.
- Use the attached design system for controls and graph colors; graph coordinates represent curve data, not decorative styling.
- Add tests for endpoints, time-span-dependent speed, easing, and deterministic cached evaluation. Verify editing, timeline display, undo, and playback in the app.

## Not included
Transform nodes, cameras, 3D navigation, AI reference generation, and batch export remain on the roadmap for subsequent work.