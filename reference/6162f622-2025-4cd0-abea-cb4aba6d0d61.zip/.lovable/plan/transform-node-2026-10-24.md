# Transform node

Add a **Transform** node under Effectors in Build, with one incoming wire and one outgoing wire.

- Set position X/Y/Z, rotation X/Y/Z in degrees, and scale X/Y/Z in the inspector.
- Default to no change: position and rotation zero, scale one.
- Transform the whole incoming layout around the scene origin. Node order matters: after a cloner, rotate/scale the layout; before a cloner, transform the source.
- Keep all settings in the scene document, with undo/redo and deterministic playback, baking, and video rendering.
- Keep the current workspace layout and Build/Animate separation unchanged.

## Technical details

- Extend the scene schema and compose ordered transforms in the pure evaluator, preserving existing effector and spring behavior. Use a browser-safe math library for matrix composition; no renderer imports during SSR.
- Pass evaluated full transforms to GPU instances so X/Y/Z rotation, nonuniform scale and chained transforms remain correct.
- Keep After Effects export's existing 2D behavior for compatible scenes. Explicitly warn when a scene uses unsupported 3D transforms rather than silently discard them; full 3D AE support remains separate roadmap work.
- Add tests for identity, XYZ translation/rotation/scale, composition order, cloner/effector compatibility, undo and export limitations. Verify adding, wiring and editing the node through the running editor.