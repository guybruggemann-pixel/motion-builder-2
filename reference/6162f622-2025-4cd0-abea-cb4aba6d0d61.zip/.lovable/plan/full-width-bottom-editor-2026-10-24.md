# Full-width bottom editor

- Move the node graph to a bottom pane spanning the app from left to right.
- Keep the library, live preview, playback controls, scene settings, and inspector in the upper area.
- Keep the draggable divider so the upper and lower areas remain resizable.
- Give the Animate timeline the same full-width bottom placement, without merging Build and Animate.
- Verify edge-to-edge sizing, node selection, and divider resizing in the running app.