# 3D Plain Effector

- Add XYZ position offsets and XYZ rotation in degrees alongside existing scale controls.
- Apply offsets per clone, around its own origin, weighted by connected fields and sine waves. Start timing, Spring and Delay continue to control the same influence.
- Preserve old scenes’ radian-based Z rotation until rotation controls are edited. Keep Transform distinct: it changes the whole arrangement; Plain Effector changes individual clones.
- Keep all settings in the scene document, with undo/redo and deterministic baked/video output.
- Preserve cloner behavior: downstream cloners reset effector offsets while retaining static Transform settings.
- Show position, rotation and scale in the graph; reject unsupported depth and tilt in flat AE export.

## Technical approach
- Extend weighted layers with optional translation and XYZ rotation; use the existing gl-matrix transform helper for the 3D path while retaining the legacy flat path.
- Compose controls from the attached design system without changing its appearance.
- Add regression tests for weighted XYZ offsets/rotations, legacy behavior, timing, Spring/Delay, ordered transforms, cloner resets, undo/cache and AE rejection.
- Verify edits, playback, undo/redo and a rendered video through the live workspace.