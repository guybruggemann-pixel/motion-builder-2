import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import { useTime } from "@/engine/time";
import { PlaybackBar } from "@/components/PlaybackBar";
import { FrameBox } from "@/components/FrameBox";
import { BuildWorkspace } from "@/components/BuildWorkspace";
import { SceneBar } from "@/components/SceneBar";
import type { SceneDoc } from "@/engine/schema";
import { bake, cachedCount, totalFrames } from "@/engine/bake";
import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Box, Orbit, CircleDot, AudioWaveform, Spline , Merge, Scissors, Move3d } from "lucide-react";
import { Film, Grid3x3, Timer, Waves,  GripVertical, Undo2, Redo2, Type, Activity } from "lucide-react";
import { Button, Input, Label, Badge, Kbd, PhaseStepper } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { DRAG_MIME } from "@/components/NodeGraph";
import { evaluate, upstream } from "@/engine/evaluate";
import type { NodeType } from "@/engine/schema";
import { Inspector } from "@/components/Inspector";
import { PreviewToolbar } from "@/components/PreviewToolbar";
import { ExportPanel } from "@/components/ExportPanel";

const Preview3D = lazy(() => import("@/components/Preview3D"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nodal — Build & Animate Workspace" },
      { name: "description", content: "Nodal's procedural node graph workspace: clone, effect and animate without keyframes." },
      { property: "og:title", content: "Nodal — Build & Animate Workspace" },
      { property: "og:description", content: "Procedural, node-based motion graphics in the browser." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Shell,
});

const PHASES = ["Setup", "Build", "Look", "Export"] as const;

type LibItem = { name: string; icon: typeof Type; type?: NodeType };
const LIBRARY: { group: string; color: string; items: LibItem[] }[] = [
  { group: "Generators", color: "text-node-generator", items: [{ name: "Text", icon: Type, type: "TextNode" }, { name: "Box Primitive", icon: Box, type: "BoxPrimitive" }] },
  { group: "Cloners", color: "text-node-cloner", items: [{ name: "Grid Cloner", icon: Grid3x3, type: "GridCloner" }, { name: "Radial Cloner", icon: Orbit, type: "RadialCloner" }, { name: "Combiner", icon: Merge, type: "Combiner" }] },
  { group: "Effectors", color: "text-node-effector", items: [{ name: "Plain Effector", icon: Activity, type: "PlainEffector" }, { name: "Transform", icon: Move3d, type: "Transform" }, { name: "Delay Effector", icon: Timer, type: "DelayEffector" }, { name: "Mask", icon: Scissors, type: "Mask" }] },
  { group: "Fields", color: "text-node-field", items: [{ name: "Linear Field", icon: Waves, type: "LinearField" }, { name: "Spherical Field", icon: CircleDot, type: "SphericalField" }] },
  { group: "Math", color: "text-node-math", items: [{ name: "Sine Wave", icon: AudioWaveform, type: "SineWave" }, { name: "Spring", icon: Spline, type: "Spring" }] },
];

function LivePreview({ doc }: { doc: SceneDoc }) {
  const time = useTime((s) => s.time);
  return <Preview3D doc={doc} time={time} />;
}

function BakeControls({ doc }: { doc: SceneDoc }) {
  const time = useTime((s) => s.time);
  const [cached, setCached] = useState(0);
  const [baking, setBaking] = useState(false);
  const cancelBake = useRef<(() => void) | null>(null);
  // Edits make a new doc (= empty cache): stop any running bake.
  useEffect(() => {
    setBaking(false);
    return () => cancelBake.current?.();
  }, [doc]);
  useEffect(() => { setCached(cachedCount(doc)); }, [doc, time]);
  const total = totalFrames(doc);
  const startBake = () => {
    setBaking(true);
    cancelBake.current = bake(doc, (done, all) => {
      setCached(done);
      if (done === all) setBaking(false);
    });
  };
  return (
    <>
      <span className="font-mono text-xs tabular-nums text-muted-foreground" aria-live="polite">
        {cached === total ? "Baked" : `${Math.round((cached / total) * 100)}% cached`}
      </span>
      <Button variant="secondary" size="sm" disabled={baking || cached === total} onClick={startBake}>{baking ? "Baking" : "Bake"}</Button>
    </>
  );
}

function RenderButton({ doc, onStart }: { doc: SceneDoc; onStart: () => void }) {
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const start = async () => {
    const canvas = document.querySelector<HTMLCanvasElement>('section[aria-label="Render preview"] canvas');
    if (!canvas) return setError("Preview isn't ready yet.");
    onStart();
    setError(null);
    setProgress(0);
    try {
      const { renderMp4 } = await import("@/engine/render");
      const blob = await renderMp4(doc, canvas, setProgress);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `nodal-${Math.round(doc.meta.duration * doc.meta.fps)}f-${doc.meta.fps}fps.mp4`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Render failed.");
    } finally {
      setProgress(null);
    }
  };
  return (
    <>
      {error && <span role="alert" className="text-xs text-destructive">{error}</span>}
      <Button size="sm" disabled={progress !== null} onClick={start}>
        <Film /> {progress === null ? "Render" : `Rendering ${Math.round(progress * 100)}%`}
      </Button>
    </>
  );
}

/** Resolve a design-system color token to 0-1 RGB (for the AE script). */
function tokenRgb(name: string): [number, number, number] {
  const ctx = document.createElement("canvas").getContext("2d");
  if (!ctx) throw new Error("Color sampling isn't available in this browser.");
  ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  ctx.fillRect(0, 0, 1, 1);
  const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
  return [r / 255, g / 255, b / 255];
}

function AeExportButton({ doc }: { doc: SceneDoc }) {
  const [error, setError] = useState<string | null>(null);
  const exportAe = async () => {
    setError(null);
    try {
      const { aeScript } = await import("@/engine/aeExport");
      const js = aeScript(doc, { idle: tokenRgb("--foreground"), live: tokenRgb("--primary"), bg: tokenRgb("--surface") });
      const url = URL.createObjectURL(new Blob([js], { type: "text/javascript" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = "nodal-scene.jsx";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { setError(e instanceof Error ? e.message : "AE export failed."); }
  };
  return <>
    {error && <div role="alert" className="absolute right-0 top-full border border-border bg-surface p-3 text-sm text-destructive">{error}</div>}
    <Button variant="secondary" size="sm" onClick={exportAe}>Export AE</Button>
  </>;
}

function Shell() {
  const doc = useScene((s) => s.doc);
  const { undo, redo, past, future } = useScene();
  const duration = doc.meta.duration;
  const [phase, setPhase] = useState<(typeof PHASES)[number]>("Build");
  const [timelineOpen, setTimelineOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [loop, setLoop] = useState(true);
  const [query, setQuery] = useState("");
  const setTime = useTime((s) => s.setTime);
  const [split, setSplit] = useState(55);
  const splitRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (useTime.getState().time > duration) setTime(duration);
  }, [duration, setTime]);

  useEffect(() => {
    if (!playing) return;
    // Frame-locked clock: time always lands on whole frames at doc fps; slow frames skip ahead cleanly.
    const fps = doc.meta.fps;
    const total = Math.round(duration * fps);
    let raf = 0;
    let startFrame = Math.round(useTime.getState().time * fps);
    if (startFrame >= total) startFrame = 0;
    const start = performance.now();
    let shown = -1;
    const tick = (now: number) => {
      let f = startFrame + Math.floor(((now - start) / 1000) * fps);
      if (f >= total) {
        if (!loop) { setTime(duration); setPlaying(false); return; }
        f %= total;
      }
      if (f !== shown) { shown = f; setTime(f / fps); }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, loop, duration, doc.meta.fps]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey) || e.key.toLowerCase() !== "z") return;
      if ((e.target as HTMLElement).tagName === "INPUT") return;
      e.preventDefault();
      if (e.shiftKey) redo();
      else undo();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  const startDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    const move = (ev: PointerEvent) => {
      const r = splitRef.current?.getBoundingClientRect();
      if (!r) return;
      setSplit(Math.min(80, Math.max(20, ((ev.clientY - r.top) / r.height) * 100)));
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const liveIds = upstream(doc);
  const cloneCount = evaluate(doc, 0).clones.length;

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background font-sans text-foreground">
      <header className="glass relative z-10 grid h-12 grid-cols-[1fr_auto_1fr] items-center border-x-0 border-t-0 px-4">
        <div className="flex items-center gap-3">
          <span className="font-display text-lg font-black tracking-tight">NODAL</span>
          <Badge variant="outline">{doc.meta.mode}</Badge>
          <div className="ml-2 flex items-center">
            <Button variant="ghost" size="icon" aria-label="Undo" disabled={!past.length} onClick={undo}><Undo2 /></Button>
            <Button variant="ghost" size="icon" aria-label="Redo" disabled={!future.length} onClick={redo}><Redo2 /></Button>
          </div>
        </div>

        <PhaseStepper phases={[...PHASES]} current={PHASES.indexOf(phase)} onPhaseSelect={(index) => {
          const next = PHASES[index];
          if (next) setPhase(next);
        }} />

        <div className="flex items-center justify-end gap-1">
          <AeExportButton doc={doc} />
          <RenderButton doc={doc} onStart={() => setPlaying(false)} />
        </div>
      </header>

      <main ref={splitRef} className="flex min-h-0 flex-1 flex-col">
      <div style={{ height: `${split}%` }} className="flex min-h-0 shrink-0">
        <aside className="flex w-72 shrink-0 flex-col border-r border-border bg-card">
          <div className="border-b border-border p-3">
            <Label htmlFor="node-search" className="sr-only">Search nodes</Label>
            <Input id="node-search" size="sm" placeholder="Search nodes" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto p-3">
            {LIBRARY.map((g) => {
              const items = g.items.filter((n) => n.name.toLowerCase().includes(query.toLowerCase()));
              if (!items.length) return null;
              return (
                <section key={g.group}>
                  <h2 className="mb-2 flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">
                    <span aria-hidden className={`h-3 w-1 bg-current ${g.color}`} />
                    {g.group}
                  </h2>
                  <ul className="space-y-1">
                    {items.map(({ name, icon: Icon, type }) => (
                      <li
                        key={name}
                        draggable={!!type}
                        onDragStart={(e) => {
                          if (!type) return;
                          e.dataTransfer.setData(DRAG_MIME, type);
                          e.dataTransfer.effectAllowed = "copy";
                        }}
                        aria-disabled={!type}
                        className={`flex items-center gap-2 rounded-xs border border-border bg-background px-2 py-1.5 text-sm transition-all duration-200 ${type ? "cursor-grab hover:bg-accent hover:text-accent-foreground active:cursor-grabbing" : "cursor-not-allowed text-muted-foreground"}`}
                      >
                        <GripVertical aria-hidden className="size-3.5 text-muted-foreground" />
                        <Icon aria-hidden className={`size-3.5 ${g.color}`} />
                        {name}
                        {!type && <Badge className="ml-auto">Soon</Badge>}
                      </li>
                    ))}
                  </ul>
                </section>
              );
            })}
          </div>
          <div className="flex items-center gap-2 border-t border-border p-3 text-xs text-muted-foreground">
            Drag nodes onto the graph · <Kbd>⌫</Kbd> delete
          </div>
        </aside>

          <section aria-label="Render preview" className="relative flex min-h-0 min-w-0 flex-1 flex-col border-b border-border bg-background">
            <div className="flex h-8 shrink-0 items-center justify-between border-b border-border px-3">
              <div className="flex items-center gap-2">
                <span aria-hidden className={`size-1.5 ${playing ? "bg-primary" : "bg-muted-foreground"}`} />
                <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Preview · WebGL</span>
              </div>
              <span className="font-mono text-xs tabular-nums text-muted-foreground">{cloneCount} clones · {doc.meta.fps} fps</span>
            </div>
            <PreviewToolbar />
            <FrameBox meta={doc.meta}>
                <ClientOnly fallback={null}>
                  <Suspense fallback={null}>
                    <LivePreview doc={doc} />
                  </Suspense>
                </ClientOnly>
                {liveIds.size === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">No tree connected to Preview</p>
                  </div>
                )}
            </FrameBox>
          </section>

        <Inspector />
      </div>

          <div
            role="separator"
            aria-orientation="horizontal"
            aria-label="Resize preview"
            aria-valuenow={Math.round(split)}
            tabIndex={0}
            onPointerDown={startDrag}
            onKeyDown={(e) => {
              if (e.key === "ArrowUp") setSplit((v) => Math.max(20, v - 5));
              if (e.key === "ArrowDown") setSplit((v) => Math.min(80, v + 5));
            }}
            className="h-1 shrink-0 cursor-row-resize bg-border transition-colors hover:bg-primary focus-visible:bg-primary focus-visible:outline-none"
          />
          <PlaybackBar doc={doc} playing={playing} loop={loop} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onLoop={() => setLoop((value) => !value)}>
            <BakeControls doc={doc} />
          </PlaybackBar>
          <SceneBar />
          {phase === "Export" ? (
            <ExportPanel doc={doc} />
          ) : (
            <BuildWorkspace timelineOpen={timelineOpen} onToggleTimeline={() => setTimelineOpen((open) => !open)} />
          )}
      </main>
    </div>
  );
}
