import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Button, Input, Label, ParamSlider, Tabs, TabsList, TabsTrigger } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { FORMATS, frameSize } from "@/engine/schema";
import { useTime, type TimeUnit } from "@/engine/time";
import { CameraBar } from "./CameraBar";

/** Collapsible scene settings strip under the playbar: length, frame rate, time display. */
export function SceneBar() {
  const [open, setOpen] = useState(false);
  const meta = useScene((s) => s.doc.meta);
  const updateMeta = useScene((s) => s.updateMeta);
  const unit = useTime((s) => s.unit);
  const setUnit = useTime((s) => s.setUnit);
  const frames = Math.round(meta.duration * meta.fps);
  const size = frameSize(meta);
  const preset = FORMATS.find((f) => f.width === size.width && f.height === size.height);
  const [custom, setCustom] = useState(false);
  const format = custom || !preset ? "custom" : preset.label;
  const setDim = (key: "width" | "height", raw: string) => {
    const v = Number(raw);
    if (Number.isFinite(v) && v >= 16) updateMeta({ [key]: Math.min(4096, Math.round(v)) });
  };

  return (
    <div className="grid shrink-0 grid-cols-2">
    <div className="min-w-0 max-h-64 overflow-y-auto border-t border-border">
      <div className="flex items-center gap-3 px-3">
        <Button variant="ghost" size="sm" aria-expanded={open} aria-controls="scene-settings" onClick={() => setOpen(!open)}>
          {open ? <ChevronDown /> : <ChevronRight />} Scene
        </Button>
        {!open && (
          <span className="font-mono text-xs tabular-nums text-muted-foreground">
            {unit === "frames" ? `${frames} f` : `${meta.duration} s`} · {meta.fps} fps · {size.width}×{size.height}
          </span>
        )}
      </div>
      {open && (
        <div id="scene-settings" className="flex flex-wrap items-end gap-6 px-3 pb-3">
          {unit === "frames" ? (
            <ParamSlider label="Length" unit=" f" value={frames} onValueChange={(f) => updateMeta({ duration: f / meta.fps })} min={1} max={60 * meta.fps} step={1} className="w-56" />
          ) : (
            <ParamSlider label="Length" unit=" s" value={Math.round(meta.duration * 100) / 100} onValueChange={(d) => updateMeta({ duration: d })} min={0.5} max={60} step={0.5} className="w-56" />
          )}
          <div className="space-y-2">
            <Label>Frame rate</Label>
            <Tabs defaultValue="30" value={String(meta.fps)} onValueChange={(v) => updateMeta({ fps: Number(v) })}>
              <TabsList>
                {["24", "25", "30", "60"].map((f) => <TabsTrigger key={f} value={f}>{f}</TabsTrigger>)}
              </TabsList>
            </Tabs>
          </div>
          <div className="space-y-2">
            <Label>Format</Label>
            <Tabs defaultValue="16:9" value={format} onValueChange={(v) => {
              const f = FORMATS.find((k) => k.label === v);
              setCustom(!f);
              if (f) updateMeta({ width: f.width, height: f.height });
            }}>
              <TabsList>
                {FORMATS.map((f) => <TabsTrigger key={f.label} value={f.label}>{f.label}</TabsTrigger>)}
                <TabsTrigger value="custom">Custom</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          {format === "custom" && (
            <div className="flex items-end gap-2">
              <div className="space-y-2">
                <Label htmlFor="scene-w">Width</Label>
                <Input id="scene-w" type="number" min={16} max={4096} step={2} defaultValue={size.width} key={`w${size.width}`} onBlur={(e) => setDim("width", e.target.value)} onKeyDown={(e) => e.key === "Enter" && setDim("width", e.currentTarget.value)} className="w-24" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="scene-h">Height</Label>
                <Input id="scene-h" type="number" min={16} max={4096} step={2} defaultValue={size.height} key={`h${size.height}`} onBlur={(e) => setDim("height", e.target.value)} onKeyDown={(e) => e.key === "Enter" && setDim("height", e.currentTarget.value)} className="w-24" />
              </div>
            </div>
          )}
          <div className="space-y-2">
            <Label>Time display</Label>
            <Tabs defaultValue="seconds" value={unit} onValueChange={(v) => setUnit(v as TimeUnit)}>
              <TabsList>
                <TabsTrigger value="seconds">Seconds</TabsTrigger>
                <TabsTrigger value="frames">Frames</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      )}
    </div>
    <div className="min-w-0 max-h-64 overflow-y-auto border-l border-border">
      <CameraBar />
    </div>
    </div>
  );
}
