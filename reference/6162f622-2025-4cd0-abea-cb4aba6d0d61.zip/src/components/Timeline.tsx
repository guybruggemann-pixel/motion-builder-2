import { useRef } from "react";
import { GripVertical } from "lucide-react";
import { useScene } from "@/engine/store";
import { useTime, formatTime } from "@/engine/time";
import { fieldInterval } from "@/engine/fieldMotion";
import { editFieldBoundary, type TimelineField } from "@/engine/timeline";
import { getFrame } from "@/engine/bake";
import { Button } from "@/design-system/motionbuilder---brandbook-c4b4eb";

/** Only field in/out points belong here; playback has its own full-width transport. */
export function Timeline() {
  const doc = useScene((s) => s.doc);
  const selectedId = useScene((s) => s.selectedId);
  const select = useScene((s) => s.select);
  const rows = doc.nodes.filter((node): node is TimelineField => node.type === "LinearField" || node.type === "SphericalField");
  const checkpoint = () => useScene.setState((s) => ({ past: [...s.past.slice(-99), s.doc], future: [] }));
  const change = (id: string, boundary: "start" | "end", value: number) => {
    const current = useScene.getState().doc;
    const positions = getFrame(current, 0).clones.map((clone) => clone.position);
    useScene.setState({ doc: { ...current, nodes: current.nodes.map((node) => node.id === id && (node.type === "LinearField" || node.type === "SphericalField")
      ? editFieldBoundary(node, boundary, value, current.meta.duration, current.meta.fps, positions) : node) } });
  };
  return (
    <div className="flex flex-col">
      <div className="flex h-8 shrink-0 items-center border-b border-border px-3 font-mono text-xs uppercase text-muted-foreground">
        <span className="w-48 shrink-0">Field</span><span className="flex-1">In / Out</span>
      </div>
      {rows.length === 0 && <p className="p-3 font-mono text-xs text-muted-foreground">No fields</p>}
      {rows.map((node) => <Row key={node.id} node={node} duration={doc.meta.duration} fps={doc.meta.fps} selected={selectedId === node.id} onSelect={() => select(node.id)} checkpoint={checkpoint} onChange={(boundary, value) => change(node.id, boundary, value)} />)}
    </div>
  );
}

function Row({ node, duration, fps, selected, onSelect, checkpoint, onChange }: {
  node: TimelineField; duration: number; fps: number; selected: boolean; onSelect: () => void; checkpoint: () => void;
  onChange: (boundary: "start" | "end", value: number) => void;
}) {
  const track = useRef<HTMLDivElement>(null);
  const drag = useRef<{ boundary: "start" | "end"; x: number; value: number } | null>(null);
  const unit = useTime((state) => state.unit);
  const { start, end } = fieldInterval(node, duration);
  return (
    <div className={`flex h-10 items-center border-b border-border ${selected ? "bg-accent" : ""}`}>
      <div className="w-48 shrink-0 px-3">
        <Button variant="ghost" size="sm" onClick={onSelect} aria-label={`Select ${node.id}`}><span aria-hidden className="size-1.5 bg-node-field" />{node.id}</Button>
      </div>
      <div ref={track} className="relative mr-3 h-8 min-w-0 flex-1">
        <div className="absolute inset-x-0 inset-y-2 bg-muted" />
        <div data-testid={`${node.id}-interval`} className="absolute inset-y-2 bg-node-field" style={{ left: `${start / duration * 100}%`, right: `${(1 - end / duration) * 100}%` }} />
        {(["start", "end"] as const).map((boundary) => {
          const value = boundary === "start" ? start : end;
          return <Button key={boundary} asChild variant="secondary" size="icon">
            <div role="slider" tabIndex={0} aria-label={`${node.id} ${boundary === "start" ? "in" : "out"}`} aria-valuemin={boundary === "start" ? 0 : start} aria-valuemax={boundary === "start" ? end : duration} aria-valuenow={value} aria-valuetext={formatTime(value, unit, fps)} title={`${boundary === "start" ? "In" : "Out"} · ${formatTime(value, unit, fps)}`}
            className={`absolute inset-y-0 z-10 cursor-ew-resize ${boundary === "end" ? "-translate-x-full" : ""}`}
            style={{ left: `${value / duration * 100}%` }}
            onPointerDown={(event) => { if (event.button !== 0) return; event.preventDefault(); onSelect(); checkpoint(); drag.current = { boundary, x: event.clientX, value }; event.currentTarget.setPointerCapture(event.pointerId); }}
            onPointerMove={(event) => { const active = drag.current; const width = track.current?.getBoundingClientRect().width; if (active && width && event.currentTarget.hasPointerCapture(event.pointerId)) onChange(active.boundary, active.value + (event.clientX - active.x) / width * duration); }}
            onPointerUp={() => { drag.current = null; }} onPointerCancel={() => { drag.current = null; }}
            onKeyDown={(event) => { if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return; event.preventDefault(); onSelect(); checkpoint(); onChange(boundary, value + (event.key === "ArrowRight" ? 1 : -1) / fps); }}>
            <GripVertical aria-hidden />
          </div></Button>;
        })}
      </div>
      <span className="w-32 shrink-0 font-mono text-xs tabular-nums text-muted-foreground">{formatTime(start, unit, fps)} / {formatTime(end, unit, fps)}</span>
    </div>
  );
}
