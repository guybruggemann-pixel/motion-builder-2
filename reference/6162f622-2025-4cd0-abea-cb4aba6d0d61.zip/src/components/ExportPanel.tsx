import { useState } from "react";
import { ChevronDown, ChevronRight, Download, FileJson } from "lucide-react";
import { Button } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import type { SceneDoc } from "@/engine/schema";

export function ExportPanel({ doc }: { doc: SceneDoc }) {
  const [open, setOpen] = useState(false);
  const json = JSON.stringify(doc, (key, value) => key === "ui" ? undefined : value, 2);
  const download = () => {
    const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "nodal-scene.json";
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <section aria-label="Export options" className="flex min-h-0 flex-1 flex-col bg-surface">
      <div className="flex items-center justify-between border-b border-border p-3">
        <h2 className="font-display text-sm font-bold">Export</h2>
      </div>
      <div className="flex items-center justify-between border-b border-border p-3">
        <Button variant="ghost" size="sm" aria-expanded={open} aria-controls="scene-json-content" onClick={() => setOpen(!open)}>
          {open ? <ChevronDown /> : <ChevronRight />}<FileJson />Scene JSON
        </Button>
        <Button variant="secondary" size="sm" onClick={download}><Download />Download JSON</Button>
      </div>
      {open && <pre id="scene-json-content" className="min-h-0 flex-1 overflow-auto p-4 font-mono text-xs text-muted-foreground">{json}</pre>}
    </section>
  );
}