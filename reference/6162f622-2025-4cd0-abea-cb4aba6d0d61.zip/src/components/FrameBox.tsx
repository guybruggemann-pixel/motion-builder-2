import { useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { frameSize, type SceneDoc } from "@/engine/schema";

/** Preview frame that keeps the scene's output aspect ratio, as large as fits the available space. */
export function FrameBox({ meta, children }: { meta: SceneDoc["meta"]; children: ReactNode }) {
  const outer = useRef<HTMLDivElement>(null);
  const [box, setBox] = useState({ w: 0, h: 0 });
  const { width, height } = frameSize(meta);

  useLayoutEffect(() => {
    const el = outer.current;
    if (!el) return;
    const fit = () => {
      const cs = getComputedStyle(el);
      const aw = el.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      const ah = el.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
      const s = Math.max(0, Math.min(aw / width, ah / height));
      setBox({ w: Math.floor(width * s), h: Math.floor(height * s) });
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    return () => ro.disconnect();
  }, [width, height]);

  return (
    <div ref={outer} className="flex min-h-0 flex-1 items-center justify-center p-6">
      {/* Size is computed from the output format at runtime, so it is set inline. */}
      <div className="relative overflow-hidden border border-border bg-surface shadow-panel" style={{ width: box.w, height: box.h }}>
        {children}
      </div>
    </div>
  );
}
