import { useLayoutEffect, useMemo } from "react";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { cameraView } from "@/engine/cameras";
import type { SceneCamera } from "@/engine/schema";

export function configuredCamera(camera: SceneCamera | undefined, width: number, height: number, extent: number) {
  const view = cameraView(camera, width, height, extent);
  const result = view.projection === "perspective"
    ? new THREE.PerspectiveCamera(view.fov, view.aspect, view.near, view.far)
    : new THREE.OrthographicCamera(view.left, view.right, view.top, view.bottom, view.near, view.far);
  result.zoom = view.zoom;
  result.position.set(...view.position);
  result.up.set(...view.up);
  result.lookAt(...view.target);
  result.updateProjectionMatrix();
  result.updateMatrixWorld();
  return result;
}

export function OutputCamera({ camera, extent }: { camera?: SceneCamera; extent: number }) {
  const { size, set, get } = useThree();
  const output = useMemo(() => configuredCamera(camera, size.width, size.height, extent), [camera, size.width, size.height, extent]);
  useLayoutEffect(() => {
    const previous = get().camera;
    set({ camera: output });
    return () => { set({ camera: previous }); };
  }, [output, set, get]);
  return null;
}