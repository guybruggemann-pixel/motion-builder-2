import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  Controls,
  Handle,
  Position,
  NodeResizer,
  applyNodeChanges,
  useReactFlow,
  useViewport,
  useStore,
  type Node,
  type Edge,
  type NodeChange,
  type EdgeChange,
  type Connection,
  type NodeProps,
} from "@xyflow/react";
import { Grid3x3, Timer, Waves, Type, Activity, Monitor, BoxSelect, Box, CircleDot, Orbit, AudioWaveform, Spline , Merge, Scissors, Move3d } from "lucide-react";
import { Button, Input, Label, NodeCard, NodePort } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { upstream } from "@/engine/evaluate";
import { effectorRotation } from "@/engine/transforms";
import { CATEGORY, MAX_INPUTS, type NodeType, type SceneNode } from "@/engine/schema";

export const DRAG_MIME = "application/x-nodal-node";

const ICON: Record<NodeType, typeof Type> = {
  TextNode: Type, BoxPrimitive: Box, GridCloner: Grid3x3, RadialCloner: Orbit, PlainEffector: Activity,
  Transform: Move3d,
  DelayEffector: Timer, LinearField: Waves, SphericalField: CircleDot, SineWave: AudioWaveform, Spring: Spline, Combiner: Merge, Mask: Scissors, Preview: Monitor,
};
const HEADER = 48; // card header + padding to the first row's centre
const ROW = 24;

type Row = { label: string; value?: string; dir: "in" | "out" };

function rows(n: SceneNode): Row[] {
  const params: Row[] = (() => {
    switch (n.type) {
      case "TextNode": return [{ label: "Text", value: n.text, dir: "in" }];
      case "BoxPrimitive": return [{ label: "Size", value: n.size.toFixed(1), dir: "in" }];
      case "GridCloner": return [{ label: "Count", value: `[${n.count[0]}, ${n.count[1]}, ${n.count[2] ?? 1}]`, dir: "in" }];
      case "RadialCloner": return [{ label: "Count", value: String(n.count), dir: "in" }, { label: "Plane", value: n.plane ?? "XY", dir: "in" }];
      case "PlainEffector": return [{ label: "Position", value: `[${(n.position ?? [0, 0, 0]).join(", ")}]`, dir: "in" }, { label: "Rotation", value: `[${effectorRotation(n).map((v) => Number(v.toFixed(1))).join(", ")}]°`, dir: "in" }, { label: "Scale", value: `[${n.scale.join(", ")}]`, dir: "in" }];
      case "Transform": return [{ label: "Position", value: `[${n.position.join(", ")}]`, dir: "in" }, { label: "Rotation", value: `[${n.rotation.join(", ")}]°`, dir: "in" }, { label: "Scale", value: `[${n.scale.join(", ")}]`, dir: "in" }];
      case "DelayEffector": return [{ label: "Tension", value: n.tension.toFixed(2), dir: "in" }, { label: "Stagger", value: `${(n.stagger ?? 0).toFixed(3)} s`, dir: "in" }, { label: "Order", value: n.reverse ? "Reverse" : "Forward", dir: "in" }, { label: "Strength", value: `${Math.round((n.strength ?? 1) * 100)}%`, dir: "in" }];
      case "LinearField": return [{ label: "Falloff", value: n.falloff.toFixed(1), dir: "in" }];
      case "SphericalField": return [{ label: "Center", value: `[${(n.center ?? [0, 0, 0]).join(", ")}]`, dir: "in" }, { label: "Radius", value: n.radiusFrom !== undefined || n.radiusTo !== undefined ? `${n.radiusFrom ?? 0} → ${n.radiusTo ?? 8}` : "Auto loop", dir: "in" }, { label: "Falloff", value: n.falloff.toFixed(1), dir: "in" }];
      case "SineWave": return [{ label: "Shape", value: n.waveform ?? "sine", dir: "in" }, { label: "Frequency", value: `${n.frequency.toFixed(2)} Hz`, dir: "in" }, { label: "Strength", value: `${Math.round((n.strength ?? 1) * 100)}%`, dir: "in" }];
      case "Spring": return [{ label: "Stiffness", value: n.stiffness.toFixed(2), dir: "in" }];
      case "Combiner": return [{ label: "Offset", value: n.offset.toFixed(1), dir: "in" }];
      case "Mask": return [{ label: "Axis", value: n.axis.toUpperCase(), dir: "in" }];
      case "Preview": return [];
    }
  })();
  const hasIn = MAX_INPUTS[n.type] > 0;
  const hasOut = n.type !== "Preview";
  return [...(hasIn ? [{ label: "In", dir: "in" as const }] : []), ...params, ...(hasOut ? [{ label: "Out", dir: "out" as const }] : [])];
}

type SceneNodeData = { node: SceneNode; connectedOut: boolean; live: boolean };
type ClusterData = { id: string; name: string };

const handleCls = "!size-3 !min-w-0 !rounded-none !border-0 !bg-transparent";

function SceneNodeView({ data, selected }: NodeProps<Node<SceneNodeData>>) {
  const n = data.node;
  const Icon = ICON[n.type];
  const r = rows(n);
  const inIdx = r.findIndex((x) => x.label === "In");
  return (
    <div className="relative">
      <NodeCard title={n.type} nodeId={n.id} category={CATEGORY[n.type]} state={selected ? "selected" : data.live || n.type !== "Preview" ? "idle" : "bypassed"} icon={<Icon />}>
        {r.map((row) => (
          <NodePort
            key={row.label}
            label={row.label}
            direction={row.dir}
            value={row.value}
            connected={row.dir === "out" ? data.connectedOut : row.label === "In" && n.inputs.length > 0}
          />
        ))}
        {n.type === "Preview" && (
          <p className="px-2.5 font-mono text-xs text-muted-foreground">{data.live ? "Rendering upstream tree" : "Connect a node to render"}</p>
        )}
      </NodeCard>
      {inIdx >= 0 && <Handle type="target" position={Position.Left} className={handleCls} style={{ top: HEADER + inIdx * ROW }} />}
      {n.type !== "Preview" && <Handle type="source" position={Position.Right} className={handleCls} style={{ top: HEADER + (r.length - 1) * ROW }} />}
    </div>
  );
}

function ClusterView({ data, selected }: NodeProps<Node<ClusterData>>) {
  const update = useScene((s) => s.updateCluster);
  return (
    <div className="h-full w-full rounded-md border border-dashed border-wire bg-muted/40">
      <NodeResizer onResizeStart={checkpoint} isVisible={selected} minWidth={160} minHeight={80} lineClassName="!border-primary" handleClassName="!size-2 !rounded-none !border-0 !bg-primary" />
      <div className="flex items-center gap-2 p-2">
        <BoxSelect aria-hidden className="size-3.5 text-muted-foreground" />
        <Label htmlFor={`cluster-${data.id}`} className="sr-only">Cluster name</Label>
        <Input
          id={`cluster-${data.id}`}
          size="sm"
          variant="mono"
          className="nodrag w-48"
          value={data.name}
          onChange={(e) => update(data.id, { name: e.target.value })}
        />
      </div>
    </div>
  );
}

/** Snapshot the doc into undo history before a continuous edit (drag, resize). */
const checkpoint = () => useScene.setState((s) => ({ past: [...s.past.slice(-99), s.doc], future: [] }));

/** Ids of scene nodes whose top-left sits inside a cluster's bounds. */
const membersOf = (c: { x: number; y: number; w: number; h: number }, nodes: SceneNode[]) =>
  nodes.filter((n) => n.ui.x >= c.x && n.ui.y >= c.y && n.ui.x <= c.x + c.w && n.ui.y <= c.y + c.h).map((n) => n.id);

/** The Preview output: a small socket pinned to the graph's right edge. */
function OutputView({ data }: NodeProps<Node<{ live: boolean; zoom: number }>>) {
  return (
    <div className="flex w-24 origin-right items-center justify-end gap-2" style={{ transform: `scale(${1 / data.zoom})` }}>
      <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Preview</span>
      <span aria-hidden className={`size-3 rotate-45 border border-primary ${data.live ? "bg-primary shadow-glow" : "bg-background"}`} />
      <Handle type="target" position={Position.Left} className="!left-auto !right-0 !size-6 !min-w-0 !translate-x-1 !rounded-none !border-0 !bg-transparent" />
    </div>
  );
}

const nodeTypes = { scene: SceneNodeView, cluster: ClusterView, output: OutputView };

function Graph() {
  const { doc, selectedId, select, moveNode, removeNodes, connect, disconnect, addNode, addCluster, updateCluster, removeClusters } = useScene();
  const { screenToFlowPosition, getViewport } = useReactFlow();
  const live = useMemo(() => upstream(doc), [doc]);
  const vp = useViewport();
  const paneW = useStore((st) => st.width);
  const paneH = useStore((st) => st.height);

  const build = useCallback((): Node[] => {
    const outs = new Set(doc.nodes.flatMap((n) => n.inputs));
    const previewLive = live.size > 0;
    return [
      ...doc.clusters.map<Node>((c) => ({
        id: c.id,
        type: "cluster",
        position: { x: c.x, y: c.y },
        width: c.w,
        height: c.h,
        zIndex: -1,
        selected: selectedId === c.id,
        data: { id: c.id, name: c.name },
      })),
      ...doc.nodes.filter((n) => n.type === "Preview").map<Node>((n) => ({
        id: n.id,
        type: "output",
        // Pinned to the right edge of the visible pane, vertically centred.
        position: { x: (paneW - 16 - vp.x) / vp.zoom - 96, y: (paneH / 2 - 12 - vp.y) / vp.zoom },
        draggable: false,
        deletable: false,
        selectable: false,
        data: { live: previewLive, zoom: vp.zoom },
      })),
      ...doc.nodes.filter((n) => n.type !== "Preview").map<Node>((n) => ({
        id: n.id,
        type: "scene",
        position: n.ui,
        selected: selectedId === n.id,
        data: { node: n, connectedOut: outs.has(n.id), live: live.has(n.id) },
      })),
    ];
  }, [doc, selectedId, live, vp, paneW, paneH]);

  const [nodes, setNodes] = useState<Node[]>(build);
  useEffect(() => {
    setNodes((prev) => build().map((n) => ({ ...n, measured: prev.find((p) => p.id === n.id)?.measured })));
  }, [build]);

  const edges: Edge[] = useMemo(
    () =>
      doc.nodes.flatMap((n) =>
        n.inputs.map((src) => {
          const on = live.has(src) && (live.has(n.id) || n.type === "Preview");
          return {
            id: `${src}->${n.id}`,
            source: src,
            target: n.id,
            animated: on,
            style: { stroke: on ? "var(--primary)" : "var(--wire)", strokeWidth: 1.5 },
          };
        }),
      ),
    [doc, live],
  );

  const isCluster = (id: string) => doc.clusters.some((c) => c.id === id);

  const onNodesChange = (changes: NodeChange[]) => {
    setNodes((nds) => applyNodeChanges(changes, nds));
    const removed: string[] = [];
    for (const c of changes) {
      if (c.type === "position" && c.position && !doc.nodes.some((n) => n.id === c.id && n.type === "Preview")) {
        if (isCluster(c.id)) {
          const pos = c.position;
          const members = membersRef.current[c.id] ?? [];
          useScene.setState((st) => {
            const cl = st.doc.clusters.find((k) => k.id === c.id);
            if (!cl) return st;
            const dx = pos.x - cl.x;
            const dy = pos.y - cl.y;
            return {
              doc: {
                ...st.doc,
                clusters: st.doc.clusters.map((k) => (k.id === c.id ? { ...k, x: pos.x, y: pos.y } : k)),
                nodes: st.doc.nodes.map((n) => (members.includes(n.id) ? { ...n, ui: { x: n.ui.x + dx, y: n.ui.y + dy } } : n)),
              },
            };
          });
        }
        else moveNode(c.id, c.position);
      }
      if (c.type === "dimensions" && c.resizing && c.dimensions && isCluster(c.id))
        updateCluster(c.id, { w: c.dimensions.width, h: c.dimensions.height }, false);
      if (c.type === "select" && c.selected) select(c.id);
      if (c.type === "remove") removed.push(c.id);
    }
    if (removed.length) {
      removeNodes(removed.filter((id) => !isCluster(id)));
      removeClusters(removed.filter(isCluster));
      select(null);
    }
  };

  const onEdgesChange = (changes: EdgeChange[]) => {
    for (const c of changes) {
      if (c.type !== "remove") continue;
      const [source, target] = c.id.split("->");
      disconnect(source, target);
    }
  };

  // Grab a wire end and drop it on another port to rewire, or on empty space to unplug it.
  const reconnected = useRef(true);
  const membersRef = useRef<Record<string, string[]>>({});
  const onNodeDragStart = (_: unknown, node: Node) => {
    checkpoint();
    const cl = doc.clusters.find((c) => c.id === node.id);
    if (cl) membersRef.current[cl.id] = membersOf(cl, doc.nodes);
  };
  const onReconnect = (old: Edge, c: Connection) => {
    reconnected.current = true;
    if (old.source === c.source && old.target === c.target) return;
    disconnect(old.source, old.target);
    if (c.source && c.target) connect(c.source, c.target);
  };
  const onReconnectEnd = (_: unknown, edge: Edge) => {
    if (!reconnected.current) disconnect(edge.source, edge.target);
    reconnected.current = true;
  };


  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData(DRAG_MIME) as NodeType;
    if (!type) return;
    const p = screenToFlowPosition({ x: e.clientX, y: e.clientY });
    addNode(type, { x: p.x - 112, y: p.y - 20 });
  };

  const newCluster = () => {
    const { x, y, zoom } = getViewport();
    addCluster({ name: "New cluster", x: (40 - x) / zoom, y: (40 - y) / zoom, w: 320, h: 200 });
  };

  // Grab a wire anywhere along its length: forward the press to the wire's input-end grab point,
  // so the wire stays attached to its source and follows the cursor (drop on a port or empty space).
  const onWireGrab = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const el = e.target as Element;
    if (el.closest(".react-flow__edgeupdater")) return;
    const edge = el.closest(".react-flow__edge");
    const anchor = edge?.querySelector(".react-flow__edgeupdater-target");
    if (!anchor) return;
    e.preventDefault();
    e.stopPropagation();
    anchor.dispatchEvent(
      new MouseEvent("mousedown", { bubbles: true, cancelable: true, button: 0, clientX: e.clientX, clientY: e.clientY }),
    );
  };

  return (
    <ReactFlow
      onMouseDownCapture={onWireGrab}
      defaultEdgeOptions={{ interactionWidth: 24 }}
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={(c: Connection) => c.source && c.target && connect(c.source, c.target)}
      onNodeDragStart={onNodeDragStart}
      edgesReconnectable
      reconnectRadius={16}
      onReconnectStart={() => (reconnected.current = false)}
      onReconnect={onReconnect}
      onReconnectEnd={onReconnectEnd}
      onPaneClick={() => select(null)}
      onDragOver={(e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
      }}
      onDrop={onDrop}
      fitView
      fitViewOptions={{ padding: 0.15 }}
      minZoom={0.2}
      maxZoom={2}
      deleteKeyCode={["Backspace", "Delete"]}
      proOptions={{ hideAttribution: true }}
      colorMode="dark"
      className="bg-background"
    >
      <Background variant={BackgroundVariant.Dots} gap={20} size={1.5} patternClassName="fill-grid" />
      <Controls showInteractive={false} className="!m-3 !shadow-panel" />
      <div className="absolute right-3 top-3 z-10">
        <Button variant="secondary" size="sm" onClick={newCluster}>
          <BoxSelect /> Add cluster
        </Button>
      </div>
    </ReactFlow>
  );
}

export function NodeGraph() {
  return (
    <ReactFlowProvider>
      <Graph />
    </ReactFlowProvider>
  );
}
