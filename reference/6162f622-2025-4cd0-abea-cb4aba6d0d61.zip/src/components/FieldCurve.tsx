import { Button, Input, Label } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { CURVES, curvePoints } from "@/engine/fieldMotion";
import type { BezierPoints, MotionCurve } from "@/engine/schema";

type CurveSettings = { id: string; curve?: MotionCurve; bezier?: BezierPoints };

/** The SVG coordinates are normalized curve data; all appearance comes from kit tokens. */
export function FieldCurve({ field, onChange }: { field: CurveSettings; onChange: (patch: Partial<CurveSettings>) => void }) {
  const points = curvePoints(field.curve, field.bezier);
  const [x1, y1, x2, y2] = points;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2" role="group" aria-label="Motion curve">
        {CURVES.map((curve) => (
          <Button key={curve.value} size="sm" variant={(field.curve ?? "linear") === curve.value ? "primary" : "secondary"}
            aria-pressed={(field.curve ?? "linear") === curve.value}
            onClick={() => onChange({ curve: curve.value })}>
            {curve.label}
          </Button>
        ))}
      </div>
      <svg viewBox="0 0 1 1" className="h-32 w-full border border-border bg-background" role="img" aria-label={`${field.curve ?? "linear"} motion curve`}>
        <path d="M 0 1 L 1 0" fill="none" className="stroke-wire" vectorEffect="non-scaling-stroke" />
        <path d={`M 0 1 L ${x1} ${1 - y1} M 1 0 L ${x2} ${1 - y2}`} fill="none" className="stroke-node-field" vectorEffect="non-scaling-stroke" />
        <path d={`M 0 1 C ${x1} ${1 - y1} ${x2} ${1 - y2} 1 0`} fill="none" className="stroke-primary" vectorEffect="non-scaling-stroke" />
      </svg>
      {field.curve === "custom" && (
        <div className="grid grid-cols-2 gap-2">
          {(["Control 1 X", "Control 1 Y", "Control 2 X", "Control 2 Y"] as const).map((label, i) => (
            <div key={label} className="grid gap-1.5">
              <Label htmlFor={`${field.id}-curve-${i}`}>{label}</Label>
              <Input id={`${field.id}-curve-${i}`} variant="mono" size="sm" type="number" min={0} max={1} step={0.01} value={points[i]}
                onChange={(e) => {
                  const value = Number(e.target.value);
                  if (!Number.isFinite(value)) return;
                  const next: BezierPoints = [...points];
                  next[i] = Math.min(1, Math.max(0, value));
                  onChange({ bezier: next });
                }} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}