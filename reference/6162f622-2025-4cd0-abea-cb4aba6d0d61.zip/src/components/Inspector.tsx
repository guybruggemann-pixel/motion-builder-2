import { Badge, Button, Input, Label, ParamSlider, Switch, Tabs, TabsList, TabsTrigger } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { TIMED, type SceneNode } from "@/engine/schema";
import { editableField, fieldInterval } from "@/engine/fieldMotion";
import { getFrame } from "@/engine/bake";
import { effectorRotation } from "@/engine/transforms";
import { FieldCurve } from "./FieldCurve";
import { ScaleControls } from "./ScaleControls";
import { editableSphere } from "@/engine/sphericalMotion";
import { WAVEFORMS } from "@/engine/waveMotion";
import { Keyed } from "./Keyed";
import { VectorKeyed } from "./VectorKeyed";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-4">
      <h3 className="font-mono text-xs uppercase tracking-wider text-muted-foreground">{title}</h3>
      {children}
    </section>
  );
}

function Params({ node }: { node: SceneNode }) {
  const update = useScene((s) => s.updateNode);
  const doc = useScene((s) => s.doc);
  const set = (patch: Partial<SceneNode>) => update(node.id, patch);
  switch (node.type) {
    case "TextNode":
      return (
        <Section title="Text">
          <div className="grid gap-1.5">
            <Label htmlFor="txt">Content</Label>
            <textarea id="txt" rows={3} value={node.text} onChange={(e) => set({ text: e.target.value })}
              className="w-full rounded-sm border border-border bg-muted px-2 py-1.5 font-sans text-xs text-foreground focus-visible:outline-none focus-visible:border-ring focus-visible:ring-1 focus-visible:ring-ring" />
          </div>
          <Tabs defaultValue="none" value={node.split} onValueChange={(split) => {
            if (split === "none" || split === "lines") set({ split });
          }}>
            <TabsList aria-label="Text splitting">
              <TabsTrigger value="none">Whole text</TabsTrigger>
              <TabsTrigger value="lines">Lines</TabsTrigger>
            </TabsList>
          </Tabs>
        </Section>
      );
    case "GridCloner":
      return (
        <Section title="Grid">
          <div className="grid grid-cols-3 gap-2">
            {(["X", "Y", "Z"] as const).map((axis, i) => (
              <div key={axis} className="grid gap-1.5">
                <Label htmlFor={`count-${axis}`}>Count {axis}</Label>
                <Input
                  id={`count-${axis}`}
                  variant="mono"
                  size="sm"
                  type="number"
                  min={1}
                  max={20}
                  value={node.count[i] ?? 1}
                  onChange={(e) => {
                    const value = Number(e.target.value);
                    if (!Number.isFinite(value)) return;
                    const c: [number, number, number] = [node.count[0], node.count[1], node.count[2] ?? 1];
                    c[i] = Math.min(20, Math.max(1, Math.round(value) || 1));
                    set({ count: c });
                  }}
                />
              </div>
            ))}
          </div>
          <Keyed node={node} param="spacing" label="XY spacing" min={0.5} max={4} step={0.1} />
          <ParamSlider label="Depth spacing" value={node.depthSpacing ?? node.spacing} onValueChange={(v) => set({ depthSpacing: v })} min={0.5} max={4} step={0.1} />
        </Section>
      );
    case "Transform":
      return (
        <>
          <Section title="Transform">
            <VectorKeyed node={node} param="position" label="Position" base={node.position} step={0.1} />
            <VectorKeyed node={node} param="rotation" label="Rotation · degrees" base={node.rotation} step={1} />
          </Section>
          <Section title="Scale"><ScaleControls node={node} /></Section>
          <Button variant="secondary" size="sm" onClick={() => set({ position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] })}>Reset transform</Button>
        </>
      );
    case "PlainEffector":
      return (
        <>
        <Section title="Offsets">
          <VectorKeyed node={node} param="position" label="Position offset" base={node.position ?? [0, 0, 0]} step={0.1} />
          <VectorKeyed node={node} param="rotationXYZ" label="Rotation offset · degrees" base={effectorRotation(node)} step={1} extra={{ rotation: 0 }} />
        </Section>
        <Section title="Transform offset">
          <ScaleControls node={node} />
        </Section>
        </>
      );
    case "LinearField":
      { const field = editableField(node, doc.meta.duration, getFrame(doc, 0).clones.map((c) => c.position[0]));
      const change = (patch: Partial<typeof field>) => set({ ...field, ...patch });
      return (
        <Section title="Field">
          <div className="grid grid-cols-2 gap-2">
            {(["from", "to"] as const).map((key) => (
              <div key={key} className="grid gap-1.5">
                <Label htmlFor={`${node.id}-${key}`}>{key === "from" ? "Start X" : "End X"}</Label>
                <Input id={`${node.id}-${key}`} variant="mono" size="sm" type="number" step={0.1} value={field[key]}
                  onChange={(e) => { const value = Number(e.target.value); if (Number.isFinite(value)) change({ [key]: value }); }} />
              </div>
            ))}
          </div>
          <ParamSlider label="Falloff" value={node.falloff} onValueChange={(v) => change({ falloff: v })} min={0} max={10} step={0.1} />
        </Section>
      ); }
    case "BoxPrimitive":
      return (
        <Section title="Box">
          <Keyed node={node} param="size" label="Size" min={0.1} max={2} step={0.1} />
        </Section>
      );
    case "RadialCloner":
      return (
        <Section title="Radial">
          <Keyed node={node} param="count" label="Count" min={1} max={64} step={1} />
          <Keyed node={node} param="radius" label="Radius" min={0.5} max={8} step={0.1} />
          <Tabs defaultValue="XY" value={node.plane ?? "XY"} onValueChange={(plane) => {
            if (plane === "XY" || plane === "XZ" || plane === "YZ") set({ plane });
          }}>
            <TabsList aria-label="Radial plane">
              {(["XY", "XZ", "YZ"] as const).map((plane) => <TabsTrigger key={plane} value={plane}>{plane}</TabsTrigger>)}
            </TabsList>
          </Tabs>
        </Section>
      );
    case "SphericalField":
      { const field = editableSphere(node, doc.meta.duration, getFrame(doc, 0).clones.map((c) => c.position));
      const change = (patch: Partial<typeof field>) => set({ ...field, ...patch });
      return (
        <Section title="Field">
          <div className="grid grid-cols-3 gap-2">
            {(["X", "Y", "Z"] as const).map((axis, i) => <div key={axis} className="grid gap-1.5">
              <Label htmlFor={`${node.id}-center-${axis}`}>Center {axis}</Label>
              <Input id={`${node.id}-center-${axis}`} variant="mono" size="sm" type="number" step={0.1} value={field.center?.[i] ?? 0}
                onChange={(e) => {
                  if (!e.target.value.trim()) return;
                  const value = Number(e.target.value);
                  if (!Number.isFinite(value)) return;
                  const center: [number, number, number] = [...(field.center ?? [0, 0, 0])];
                  center[i] = value; change({ center });
                }} />
            </div>)}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(["radiusFrom", "radiusTo"] as const).map((key) => <div key={key} className="grid gap-1.5">
              <Label htmlFor={`${node.id}-${key}`}>{key === "radiusFrom" ? "Start radius" : "End radius"}</Label>
              <Input id={`${node.id}-${key}`} variant="mono" size="sm" type="number" min={0} step={0.1} value={field[key]}
                onChange={(e) => {
                  if (!e.target.value.trim()) return;
                  const value = Number(e.target.value);
                  if (Number.isFinite(value)) change({ [key]: Math.max(0, value) });
                }} />
            </div>)}
          </div>
          <ParamSlider label="Falloff" value={field.falloff} onValueChange={(v) => change({ falloff: v })} min={0} max={10} step={0.1} />
        </Section>
      ); }
    case "SineWave":
      return (
        <Section title="Wave">
          <div className="grid grid-cols-2 gap-2" role="group" aria-label="Wave shape">
            {WAVEFORMS.map((shape) => <Button key={shape.value} variant={(node.waveform ?? "sine") === shape.value ? "primary" : "secondary"} size="sm"
              aria-pressed={(node.waveform ?? "sine") === shape.value} onClick={() => set({ waveform: shape.value })}>{shape.label}</Button>)}
          </div>
          <Keyed node={node} param="frequency" label="Frequency" min={0.1} max={4} step={0.05} unit=" Hz" />
          <Keyed node={node} param="offset" label="Clone offset" min={0} max={2} step={0.05} unit=" rad" />
          <div className="grid gap-1.5">
            <Label htmlFor={`${node.id}-phase`}>Phase · degrees</Label>
            <Input id={`${node.id}-phase`} variant="mono" size="sm" type="number" step={1} value={node.phase ?? 0}
              onChange={(e) => {
                if (!e.target.value.trim()) return;
                const phase = Number(e.target.value);
                if (Number.isFinite(phase)) set({ phase });
              }} />
          </div>
          <ParamSlider label="Strength" value={(node.strength ?? 1) * 100} onValueChange={(v) => set({ strength: v / 100 })} min={0} max={100} step={1} unit="%" />
        </Section>
      );
    case "Spring":
      return (
        <Section title="Spring">
          <Keyed node={node} param="stiffness" label="Stiffness" />
          <Keyed node={node} param="damping" label="Damping" />
        </Section>
      );
    case "Mask":
      return (
        <Section title="Mask">
          <div className="space-y-2">
            <Tabs defaultValue="x" value={node.axis} onValueChange={(axis) => {
              if (axis === "x" || axis === "y" || axis === "z") set({ axis });
            }}>
              <TabsList aria-label="Mask axis">
                <TabsTrigger value="x">X</TabsTrigger>
                <TabsTrigger value="y">Y</TabsTrigger>
                <TabsTrigger value="z">Z</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <Keyed node={node} param="from" label="Edge start" min={-15} max={15} step={0.1} />
          <Keyed node={node} param="to" label="Edge end" min={-15} max={15} step={0.1} />
          <div className="flex items-center justify-between">
            <Label htmlFor={`inv-${node.id}`}>Invert</Label>
            <Switch id={`inv-${node.id}`} checked={node.invert} onCheckedChange={(v) => set({ invert: v })} />
          </div>
        </Section>
      );
    case "Combiner":
      return (
        <Section title="Combine">
          <Keyed node={node} param="offset" label="Spread X" min={0} max={20} step={0.5} />
          <p className="text-sm text-muted-foreground">Wire any number of trees in. Each one renders together; Spread X places them side by side.</p>
        </Section>
      );
    case "Preview":
      return (
        <Section title="Output">
          <p className="text-sm text-muted-foreground">Renders the tree wired into it. It takes one wire; a new wire replaces the old one.</p>
        </Section>
      );
    case "DelayEffector":
      return (
        <Section title="Delay">
          <Keyed node={node} param="tension" label="Spring Tension" />
          <Keyed node={node} param="friction" label="Friction" />
          <div className="grid gap-1.5">
            <Label htmlFor={`${node.id}-stagger`}>Stagger per clone · s</Label>
            <Input id={`${node.id}-stagger`} variant="mono" size="sm" type="number" min={0} step={1 / doc.meta.fps} value={node.stagger ?? 0}
              onChange={(e) => {
                if (!e.target.value.trim()) return;
                const value = Number(e.target.value);
                if (Number.isFinite(value)) set({ stagger: Math.max(0, value) });
              }} />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor={`${node.id}-reverse`}>Reverse order</Label>
            <Switch id={`${node.id}-reverse`} checked={node.reverse ?? false} onCheckedChange={(reverse) => set({ reverse })} />
          </div>
          <ParamSlider label="Strength" value={(node.strength ?? 1) * 100} onValueChange={(v) => set({ strength: v / 100 })} min={0} max={100} step={1} unit="%" />
        </Section>
      );
  }
}

export function Inspector() {
  const { doc, selectedId, removeNodes, select } = useScene();
  const node = doc.nodes.find((n) => n.id === selectedId);
  const cluster = doc.clusters.find((c) => c.id === selectedId);
  return (
    <aside className="flex w-80 shrink-0 flex-col border-l border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Inspector</p>
          <h2 className="font-display text-sm font-bold tracking-tight">{node?.type ?? (cluster ? "Cluster" : "Nothing selected")}</h2>
        </div>
        {node && <Badge variant="primary">{node.id}</Badge>}
      </div>
      <div className="flex-1 space-y-6 overflow-y-auto p-4">
        {node ? (
          <>
            <Params node={node} />
            {TIMED.includes(node.type) && <Timing node={node} />}
            <Button variant="destructive" size="sm" onClick={() => { removeNodes([node.id]); select(null); }}>Delete node</Button>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">{cluster ? `"${cluster.name}" — rename it in the graph, drag to move, pull the corners to resize.` : "Select a node in the graph."}</p>
        )}
      </div>
    </aside>
  );
}

/** Animate-phase timing: when the node kicks in. */
function Timing({ node }: { node: SceneNode }) {
  const update = useScene((s) => s.updateNode);
  const doc = useScene((s) => s.doc);
  const { duration, fps } = doc.meta;
  if (node.type === "LinearField" || node.type === "SphericalField" || node.type === "Mask") {
    const field = node.type === "LinearField" ? editableField(node, duration, getFrame(doc, 0).clones.map((c) => c.position[0])) : node.type === "SphericalField" ? editableSphere(node, duration, getFrame(doc, 0).clones.map((c) => c.position)) : { ...node, curve: node.curve ?? "linear" };
    const { start, end } = fieldInterval(field, duration);
    const change = (patch: Partial<typeof field>) => update(node.id, { ...field, ...patch });
    return (
      <Section title="Timing">
        <div className="grid grid-cols-2 gap-2">
          {(["start", "end"] as const).map((key) => (
            <div key={key} className="grid gap-1.5">
              <Label htmlFor={`${node.id}-${key}`}>{key === "start" ? "Start time" : "End time"} · s</Label>
              <Input id={`${node.id}-${key}`} variant="mono" size="sm" type="number" min={0} max={duration} step={1 / fps} value={key === "start" ? start : end}
                onChange={(e) => {
                  const value = Number(e.target.value);
                  if (!Number.isFinite(value)) return;
                  const snapped = Math.min(duration, Math.max(0, Math.round(value * fps) / fps));
                  change(key === "start" ? { start: snapped, end: Math.max(end, snapped) } : { end: Math.max(start, snapped) });
                }} />
            </div>
          ))}
        </div>
        <FieldCurve field={field} onChange={change} />
      </Section>
    );
  }
  return (
    <Section title="Timing">
      <ParamSlider label="Start" unit=" s" value={node.start ?? 0} onValueChange={(v) => update(node.id, { start: v })} min={0} max={duration} step={0.05} />
    </Section>
  );
}
