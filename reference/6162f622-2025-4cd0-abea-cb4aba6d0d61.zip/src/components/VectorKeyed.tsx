import { Diamond } from "lucide-react";
import { Button, Input, Label } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { useTime } from "@/engine/time";
import { animOf, keyAt, removeKey, sampleKeys, setKey } from "@/engine/keyframes";
import type { SceneNode, Vec3 } from "@/engine/schema";

/** XYZ number inputs with one keyframe diamond keying all three axes ("param.0/1/2"). */
export function VectorKeyed({ node, param, label, base, step, extra }: {
  node: SceneNode; param: string; label: string; base: Vec3; step: number; extra?: Partial<SceneNode>;
}) {
  const update = useScene((s) => s.updateNode);
  const fps = useScene((s) => s.doc.meta.fps);
  const raw = useTime((s) => s.time);
  const t = Math.round(raw * fps) / fps;
  const anim = animOf(node) ?? {};
  const paths = [0, 1, 2].map((i) => `${param}.${i}`);
  const animated = paths.some((p) => anim[p]?.length);
  const value = base.map((v, i) => (anim[paths[i]]?.length ? sampleKeys(anim[paths[i]], t) : v)) as Vec3;
  const onKey = paths.every((p) => keyAt(anim[p], t));

  const commit = (a: typeof anim, vec: Vec3) =>
    update(node.id, { ...extra, [param]: vec, anim: Object.keys(a).length ? a : undefined } as Partial<SceneNode>);
  const change = (i: number, v: number) => {
    const vec = [...value] as Vec3; vec[i] = v;
    if (!animated) return commit(anim, vec);
    commit({ ...anim, [paths[i]]: setKey(anim[paths[i]], t, v) }, base);
  };
  const toggle = () => {
    const a = { ...anim };
    paths.forEach((p, i) => {
      const next = onKey ? removeKey(a[p], t) : setKey(a[p], t, value[i]);
      if (next.length) a[p] = next; else delete a[p];
    });
    commit(a, onKey && !paths.some((p) => a[p]) ? value : base);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
        <Button variant={onKey ? "primary" : animated ? "outline" : "ghost"} size="icon" aria-pressed={onKey}
          aria-label={onKey ? `Remove ${label} key` : `Add ${label} key`} onClick={toggle}><Diamond /></Button>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {(["X", "Y", "Z"] as const).map((axis, i) => (
          <div key={axis} className="grid gap-1.5">
            <Label htmlFor={`${node.id}-${param}-${axis}`}>{axis}</Label>
            <Input id={`${node.id}-${param}-${axis}`} aria-label={`${label} ${axis}`} variant="mono" size="sm" type="number" step={step}
              value={Number(value[i].toFixed(4))}
              onChange={(e) => {
                if (!e.target.value.trim()) return;
                const v = Number(e.target.value);
                if (Number.isFinite(v)) change(i, v);
              }} />
          </div>
        ))}
      </div>
    </div>
  );
}
