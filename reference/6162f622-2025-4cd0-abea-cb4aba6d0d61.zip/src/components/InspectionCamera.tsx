import { useLayoutEffect, useMemo, useRef } from "react";
import { OrbitControls, PerspectiveCamera } from "@react-three/drei";
import { useThree } from "@react-three/fiber";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import * as THREE from "three";
import { inspectionBounds, inspectionDistance, useInspection } from "@/engine/inspection";
import type { Clone } from "@/engine/evaluate";

export const INSPECTION_LAYER = 1;

export function InspectionCamera({ clones }: { clones: Clone[] }) {
  const camera = useRef<THREE.PerspectiveCamera>(null);
  const controls = useRef<OrbitControlsImpl>(null);
  const latest = useRef(clones);
  latest.current = clones;
  const revision = useInspection((s) => s.revision);
  const { size, camera: activeCamera } = useThree();
  const aspect = size.width / Math.max(1, size.height);
  useLayoutEffect(() => {
    const cam = camera.current;
    const orbit = controls.current;
    if (!cam || !orbit || activeCamera !== cam) return;
    const { center, radius } = inspectionBounds(latest.current);
    const distance = inspectionDistance(radius, aspect);
    const target = new THREE.Vector3(...center);
    cam.position.copy(target).add(new THREE.Vector3(0.4, 0.3, 1).normalize().multiplyScalar(distance));
    cam.zoom = 1;
    cam.near = Math.max(0.01, distance / 10000);
    cam.far = Math.max(1000, distance + radius * 100);
    cam.layers.enable(INSPECTION_LAYER);
    cam.lookAt(target);
    cam.updateProjectionMatrix();
    orbit.target.copy(target);
    orbit.minDistance = Math.max(0.1, radius / 20);
    orbit.maxDistance = distance * 100;
    orbit.update();
  }, [revision, aspect, activeCamera]);
  return <>
    <PerspectiveCamera ref={camera} makeDefault fov={45} />
    <OrbitControls ref={controls} makeDefault enableDamping={false} />
  </>;
}

export function InspectionGuides({ clones, colors }: { clones: Clone[]; colors: { grid: string; wire: string; x: string; y: string; z: string } }) {
  const helpers = useMemo(() => {
    const { radius, floor, center } = inspectionBounds(clones);
    const span = Math.max(10, Math.ceil(radius * 3));
    const grid = new THREE.GridHelper(span, Math.min(100, Math.ceil(span)), colors.wire, colors.grid);
    grid.position.set(center[0], floor, center[2]);
    const axes = new THREE.AxesHelper(Math.max(2, radius));
    axes.setColors(new THREE.Color(colors.x), new THREE.Color(colors.y), new THREE.Color(colors.z));
    grid.layers.set(INSPECTION_LAYER);
    axes.layers.set(INSPECTION_LAYER);
    return { grid, axes };
  }, [clones, colors]);
  useLayoutEffect(() => () => {
    helpers.grid.dispose();
    helpers.axes.dispose();
  }, [helpers]);
  return <><primitive object={helpers.grid} /><primitive object={helpers.axes} /></>;
}