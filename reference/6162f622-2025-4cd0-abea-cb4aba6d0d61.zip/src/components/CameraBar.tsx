import { useState } from "react";
import { Camera, ChevronDown, ChevronRight, Copy, Plus, Trash2 } from "lucide-react";
import { Button, Input, Label, Tabs, TabsList, TabsTrigger } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { activeCamera, cameraView } from "@/engine/cameras";
import { frameSize, type SceneCamera, type Vec3 } from "@/engine/schema";
import { extentOf } from "@/engine/framing";
import { getFrame } from "@/engine/bake";
import { useTime } from "@/engine/time";

function CameraNumber({ id, label, value, min, max, commit }: { id: string; label: string; value: number; min?: number; max?: number; commit: (value: number) => void }) {
  const [draft, setDraft] = useState(String(value));
  const save = () => {
    const number = Number(draft);
    if (draft.trim() && Number.isFinite(number)) commit(number);
    else setDraft(String(value));
  };
  return <div className="space-y-2 w-24">
    <Label htmlFor={id}>{label}</Label>
    <Input id={id} variant="mono" type="number" step="0.1" min={min} max={max} value={draft} onChange={(event) => setDraft(event.target.value)} onBlur={save}
      onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }} />
  </div>;
}

export function CameraBar() {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { doc, addCamera, updateCamera, removeCamera, setActiveCamera } = useScene();
  const camera = activeCamera(doc);
  const change = (patch: Partial<Omit<SceneCamera, "id">>) => {
    if (camera) setError(updateCamera(camera.id, patch));
  };
  const add = (duplicate = false) => {
    const { width, height } = frameSize(doc.meta);
    const extent = extentOf(getFrame(doc, useTime.getState().time).clones);
    const view = cameraView(undefined, width, height, extent);
    addCamera(view.top * 2, duplicate ? camera?.id : undefined);
    setError(null);
  };
  return <div className="shrink-0 border-t border-border">
    <div className="flex items-center gap-3 px-3">
      <Button variant="ghost" size="sm" aria-expanded={open} aria-controls="camera-settings" onClick={() => setOpen(!open)}>
        {open ? <ChevronDown /> : <ChevronRight />} <Camera /> Camera
      </Button>
      {!open && <span className="font-mono text-xs text-muted-foreground">{camera?.name ?? "Auto framing"}</span>}
    </div>
    {open && <div id="camera-settings" className="space-y-3 px-3 pb-3">
      <div className="flex flex-wrap items-center gap-2">
        <Button variant={!camera ? "secondary" : "ghost"} size="sm" onClick={() => { setActiveCamera(); setError(null); }}>Auto</Button>
        {doc.cameras?.map((item) => <Button key={item.id} variant={camera?.id === item.id ? "secondary" : "ghost"} size="sm"
          onClick={() => { setActiveCamera(item.id); setError(null); }}>{item.name}</Button>)}
        <Button variant="ghost" size="icon" aria-label="Add camera" title="Add camera" onClick={() => add()}><Plus /></Button>
        <Button variant="ghost" size="icon" disabled={!camera} aria-label="Duplicate camera" title="Duplicate camera" onClick={() => add(true)}><Copy /></Button>
        <Button variant="ghost" size="icon" disabled={!camera} aria-label="Delete camera" title="Delete camera" onClick={() => { if (camera) removeCamera(camera.id); setError(null); }}><Trash2 /></Button>
      </div>
      {camera && <div key={camera.id} className="flex flex-wrap items-end gap-3">
        <div className="space-y-2 w-40">
          <Label htmlFor="camera-name">Name</Label>
          <Input id="camera-name" key={camera.name} defaultValue={camera.name} onBlur={(event) => change({ name: event.target.value.trim() })}
            onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="camera-projection">Projection</Label>
          <Tabs defaultValue="orthographic" value={camera.projection} onValueChange={(projection) => {
            if (projection === "orthographic" || projection === "perspective") change({ projection });
          }}><TabsList id="camera-projection"><TabsTrigger value="orthographic">Ortho</TabsTrigger><TabsTrigger value="perspective">Perspective</TabsTrigger></TabsList></Tabs>
        </div>
        {(["position", "target"] as const).map((property) => <div key={property} className="flex flex-wrap gap-2">
          {(["X", "Y", "Z"] as const).map((axis, index) => <CameraNumber key={`${camera.id}-${property}-${axis}-${camera[property][index]}`}
            id={`camera-${property}-${axis}`} label={`${property} ${axis}`} value={camera[property][index]} commit={(value) => {
              const vector: Vec3 = [...camera[property]];
              vector[index] = value;
              change({ [property]: vector });
            }} />)}
        </div>)}
        <CameraNumber key={`zoom-${camera.zoom}`} id="camera-zoom" label="Zoom" value={camera.zoom} min={0.01} max={100} commit={(zoom) => change({ zoom })} />
        {camera.projection === "perspective"
          ? <CameraNumber key={`fov-${camera.fov}`} id="camera-fov" label="FOV °" value={camera.fov} min={1} max={179} commit={(fov) => change({ fov })} />
          : <CameraNumber key={`height-${camera.viewHeight}`} id="camera-height" label="View height" value={camera.viewHeight} min={0.01} commit={(viewHeight) => change({ viewHeight })} />}
      </div>}
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    </div>}
  </div>;
}