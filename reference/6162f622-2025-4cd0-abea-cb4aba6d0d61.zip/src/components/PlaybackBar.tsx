import { ChevronFirst, ChevronLast, SkipBack, SkipForward, Play, Pause, Repeat } from "lucide-react";
import { Button, ParamSlider } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { formatTime, useTime } from "@/engine/time";
import { useScene } from "@/engine/store";
import { animOf } from "@/engine/keyframes";
import type { SceneDoc } from "@/engine/schema";
import type { ReactNode } from "react";

export function PlaybackBar({ doc, playing, loop, onPlay, onPause, onLoop, children }: {
  doc: SceneDoc; playing: boolean; loop: boolean;
  onPlay: () => void; onPause: () => void; onLoop: () => void; children: ReactNode;
}) {
  const { duration, fps } = doc.meta;
  const time = useTime((state) => state.time);
  const unit = useTime((state) => state.unit);
  const setTime = useTime((state) => state.setTime);
  const selectedId = useScene((state) => state.selectedId);
  const selected = doc.nodes.find((n) => n.id === selectedId);
  const keyTimes = [...new Set(Object.values((selected && animOf(selected)) ?? {}).flat().map((k) => k.t))];
  const seek = (value: number) => { onPause(); setTime(Math.min(duration, Math.max(0, Math.round(value * fps) / fps))); };
  return (
    <section aria-label="Playback timeline" className="shrink-0 border-t border-border bg-surface px-3 py-2">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" aria-label="First frame" title="First frame" onClick={() => seek(0)}><ChevronFirst /></Button>
          <Button variant="ghost" size="icon" aria-label="Previous frame" title="Previous frame" onClick={() => seek(time - 1 / fps)}><SkipBack /></Button>
          <Button variant={playing ? "secondary" : "ghost"} size="icon" aria-label={playing ? "Pause" : "Play"} title={playing ? "Pause" : "Play"} aria-pressed={playing} onClick={playing ? onPause : onPlay}>{playing ? <Pause /> : <Play />}</Button>
          <Button variant="ghost" size="icon" aria-label="Next frame" title="Next frame" onClick={() => seek(time + 1 / fps)}><SkipForward /></Button>
          <Button variant="ghost" size="icon" aria-label="Last frame" title="Last frame" onClick={() => seek(duration)}><ChevronLast /></Button>
          <Button variant={loop ? "secondary" : "ghost"} size="icon" aria-label="Loop" title="Loop" aria-pressed={loop} onClick={onLoop}><Repeat /></Button>
        </div>
        <output aria-label="Current time" className="font-mono text-xs tabular-nums">{formatTime(time, unit, fps)}</output>
        <div className="min-w-0 flex-1">
          <ParamSlider id="scrub" label="Frame" min={0} max={Math.round(duration * fps)} step={1} value={Math.round(time * fps)} unit=" f" onValueChange={(frame) => seek(frame / fps)} />
          {keyTimes.length > 0 && (
            <div className="relative h-3" aria-label="Keyframes of selected node">
              {keyTimes.map((t) => (
                <button key={t} type="button" aria-label={`Go to key at ${formatTime(t, unit, fps)}`} onClick={() => seek(t)}
                  style={{ left: `${(t / duration) * 100}%` }}
                  className="absolute top-0 size-2.5 -translate-x-1/2 rotate-45 rounded-xs bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
              ))}
            </div>
          )}
          <div aria-hidden className="flex justify-between font-mono text-xs tabular-nums text-muted-foreground">
            {[0, 1, 2, 3, 4].map((tick) => <span key={tick}>{formatTime(duration * tick / 4, unit, fps)}</span>)}
          </div>
        </div>
        {children}
      </div>
    </section>
  );
}