import { Grid3x3, RotateCcw } from "lucide-react";
import { Button, Tabs, TabsList, TabsTrigger } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useInspection } from "@/engine/inspection";
import { useScene } from "@/engine/store";
import { activeCamera } from "@/engine/cameras";

export function PreviewToolbar() {
  const { mode, setMode, guides, toggleGuides, reset } = useInspection();
  const camera = useScene((s) => activeCamera(s.doc));
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-between gap-2 border-b border-border px-3 py-1">
      <Tabs defaultValue="front" value={mode} onValueChange={(value) => { if (value === "front" || value === "3d") setMode(value); }}>
        <TabsList>
          <TabsTrigger value="front">{camera ? "Camera" : "Front"}</TabsTrigger>
          <TabsTrigger value="3d">3D</TabsTrigger>
        </TabsList>
      </Tabs>
      <div className="flex items-center gap-1">
        <Button variant={guides && mode === "3d" ? "secondary" : "ghost"} size="icon" disabled={mode === "front"}
          aria-label="Toggle 3D guides" aria-pressed={guides} title="Toggle 3D guides" onClick={toggleGuides}><Grid3x3 /></Button>
        <Button variant="ghost" size="icon" disabled={mode === "front"} aria-label="Reset 3D view" title="Reset 3D view" onClick={reset}><RotateCcw /></Button>
      </div>
    </div>
  );
}