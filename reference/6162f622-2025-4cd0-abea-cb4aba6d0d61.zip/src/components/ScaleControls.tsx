import { Input, Label, ParamSlider, Switch } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { editScale, setUniformScale, type ScaleNode } from "@/engine/scale";
import { useScene } from "@/engine/store";

export function ScaleControls({ node }: { node: ScaleNode }) {
  const update = useScene((s) => s.updateNode);
  const uniform = node.uniformScale ?? false;
  const axes = uniform ? ["Uniform"] : ["X", "Y", "Z"];
  return <div className="space-y-4">
    <div className="flex items-center justify-between">
      <Label htmlFor={`${node.id}-uniform-scale`}>Uniform scale</Label>
      <Switch id={`${node.id}-uniform-scale`} aria-label="Uniform scale" checked={uniform}
        onCheckedChange={(checked) => update(node.id, setUniformScale(node, checked))} />
    </div>
    <div className={node.type === "Transform" && !uniform ? "grid grid-cols-3 gap-2" : "grid gap-2"}>
      {axes.map((axis, i) => node.type === "PlainEffector" ?
        <ParamSlider key={axis} label={uniform ? "Scale" : `Scale ${axis}`} value={node.scale[i]}
          min={0} max={5} step={0.1} onValueChange={(value) => update(node.id, editScale(node, i, value))} /> :
        <div key={axis} className="grid gap-1.5">
          <Label htmlFor={`${node.id}-scale-${axis}`}>{uniform ? "Scale" : axis}</Label>
          <Input id={`${node.id}-scale-${axis}`} aria-label={uniform ? "Uniform scale value" : `scale ${axis}`}
            variant="mono" size="sm" type="number" step={0.1} value={node.scale[i]}
            onChange={(e) => {
              if (!e.target.value.trim()) return;
              update(node.id, editScale(node, i, Number(e.target.value)));
            }} />
        </div>)}
    </div>
  </div>;
}