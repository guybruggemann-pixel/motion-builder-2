import { ChevronLeft, ChevronRight, Diamond } from "lucide-react";
import { Button, ParamSlider, Tabs, TabsList, TabsTrigger } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { useScene } from "@/engine/store";
import { useTime } from "@/engine/time";
import { animOf, keyAt, neighbourKey, removeKey, sampleKeys, setKey, type KeyEase } from "@/engine/keyframes";
import type { SceneNode } from "@/engine/schema";

interface Props { node: SceneNode; param: string; label: string; min?: number; max?: number; step?: number; unit?: string }

/** ParamSlider with a Fusion-style keyframe diamond: key at playhead, prev/next, per-key ease. */
export function Keyed({ node, param, label, ...slider }: Props) {
  const update = useScene((s) => s.updateNode);
  const fps = useScene((s) => s.doc.meta.fps);
  const raw = useTime((s) => s.time);
  const setTime = useTime((s) => s.setTime);
  const t = Math.round(raw * fps) / fps;
  const anim = animOf(node) ?? {};
  const keys = anim[param];
  const animated = !!keys?.length;
  const base = (node as unknown as Record<string, number>)[param];
  const value = animated ? sampleKeys(keys, t) : base;
  const onKey = keyAt(keys, t);

  const write = (next: typeof keys) => {
    const a = { ...anim };
    if (next?.length) a[param] = next; else delete a[param];
    update(node.id, { anim: Object.keys(a).length ? a : undefined, ...(animated && !next?.length ? { [param]: value } : {}) } as Partial<SceneNode>);
  };
  const change = (v: number) => (animated ? write(setKey(keys, t, v)) : update(node.id, { [param]: v } as Partial<SceneNode>));
  const toggle = () => write(onKey ? removeKey(keys, t) : setKey(keys, t, value));
  const jump = (dir: 1 | -1) => { const k = neighbourKey(keys, t, dir); if (k) setTime(k.t); };

  return (
    <div className="space-y-1.5">
      <div className="flex items-end gap-1">
        <div className="min-w-0 flex-1"><ParamSlider label={label} value={value} onValueChange={change} {...slider} /></div>
        {animated && <Button variant="ghost" size="icon" aria-label={`Previous ${label} key`} onClick={() => jump(-1)}><ChevronLeft /></Button>}
        <Button variant={onKey ? "primary" : animated ? "outline" : "ghost"} size="icon" aria-pressed={!!onKey}
          aria-label={onKey ? `Remove ${label} key` : `Add ${label} key`} onClick={toggle}><Diamond /></Button>
        {animated && <Button variant="ghost" size="icon" aria-label={`Next ${label} key`} onClick={() => jump(1)}><ChevronRight /></Button>}
      </div>
      {onKey && (
        <Tabs defaultValue="smooth" value={onKey.ease ?? "smooth"} onValueChange={(ease) => write(keys.map((k) => (k === onKey ? { ...k, ease: ease as KeyEase } : k)))}>
          <TabsList aria-label={`${label} key easing`}>
            <TabsTrigger value="linear">Linear</TabsTrigger>
            <TabsTrigger value="smooth">Smooth</TabsTrigger>
            <TabsTrigger value="hold">Hold</TabsTrigger>
          </TabsList>
        </Tabs>
      )}
    </div>
  );
}
