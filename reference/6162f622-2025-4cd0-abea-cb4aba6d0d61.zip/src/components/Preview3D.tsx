import { useEffect, useLayoutEffect, useMemo, useRef } from "react";
import { Canvas, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { getFrame } from "@/engine/bake";
import type { Clip, Clone } from "@/engine/evaluate";
import type { SceneDoc } from "@/engine/schema";
import { registerCapture } from "@/engine/offscreen";
import { FONT_SIZE, extentOf } from "@/engine/framing";
import { activeCamera } from "@/engine/cameras";
import { OutputCamera, configuredCamera } from "./OutputCamera";
import { useInspection } from "@/engine/inspection";
import { InspectionCamera, InspectionGuides } from "./InspectionCamera";

/** Resolve a design-system CSS color token to an rgb string three.js can parse. */
function token(name: string) {
  const c = document.createElement("canvas");
  c.width = c.height = 1;
  const ctx = c.getContext("2d");
  if (!ctx) return "white";
  ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  ctx.fillRect(0, 0, 1, 1);
  const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
  return `rgb(${r},${g},${b})`;
}


/** Rasterise a string once (white, so instance colors tint it) in the DS display font. */
function textTexture(text: string) {
  const px = 128;
  const family = getComputedStyle(document.documentElement).getPropertyValue("--font-display").trim() || "sans-serif";
  const font = `600 ${px}px ${family}`;
  const measure = document.createElement("canvas").getContext("2d")!;
  measure.font = font;
  const w = Math.max(1, Math.ceil(measure.measureText(text).width + px * 0.2));
  const h = Math.ceil(px * 1.3);
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  ctx.font = font;
  ctx.fillStyle = "white";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, w / 2, h / 2);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return { tex, aspect: w / h };
}

type Colors = { idle: THREE.Color; live: THREE.Color };
const tmp = new THREE.Object3D();
const instanceMatrix = new THREE.Matrix4();

/** One draw call for every clone sharing the same shape/text/size. */
function Instances({ clones, colors, kind }: { clones: Clone[]; colors: Colors; kind: "text" | "box" }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const first = clones[0];
  const capacity = useMemo(() => Math.max(16, 2 ** Math.ceil(Math.log2(clones.length))), [clones.length]);
  const text = useMemo(() => (kind === "text" ? textTexture(first.text) : null), [kind, first.text]);
  useEffect(() => () => text?.tex.dispose(), [text]);

  const geometry = useMemo(() => {
    if (kind === "box") return new THREE.BoxGeometry(first.size, first.size, first.size);
    const h = FONT_SIZE * 1.3;
    return new THREE.PlaneGeometry(h * (text?.aspect ?? 1), h);
  }, [kind, first.size, text]);
  const material = useMemo(
    () =>
      kind === "box"
        ? new THREE.MeshBasicMaterial({ wireframe: true })
        : new THREE.MeshBasicMaterial({ map: text?.tex, transparent: true, depthWrite: false, side: THREE.DoubleSide }),
    [kind, text],
  );

  // Mask nodes → real GPU clipping planes; constants move each frame, the material stays.
  const planes = useMemo(() => first.clips.map(() => new THREE.Plane()), [first.clips.length]);
  useLayoutEffect(() => {
    first.clips.forEach((c: Clip, i) => {
      const sign = c.invert ? 1 : -1;
      planes[i].normal.set(c.axis === "x" ? sign : 0, c.axis === "y" ? sign : 0, c.axis === "z" ? sign : 0);
      planes[i].constant = -sign * c.value;
    });
    material.clippingPlanes = planes;
    material.needsUpdate = true;
  }, [first.clips, planes, material]);

  useLayoutEffect(() => {
    const m = ref.current;
    if (!m) return;
    clones.forEach((c, i) => {
      if (c.matrix) {
        instanceMatrix.fromArray(c.matrix);
        m.setMatrixAt(i, instanceMatrix);
      } else {
        tmp.position.set(...c.position);
        tmp.scale.set(...c.scale);
        if (kind === "box") tmp.rotation.set(0.5, 0.6, c.rotation);
        else tmp.rotation.set(0, 0, c.rotation);
        tmp.updateMatrix();
        m.setMatrixAt(i, tmp.matrix);
      }
      m.setColorAt(i, c.weight > 0.5 ? colors.live : colors.idle);
    });
    m.count = clones.length;
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }, [clones, colors, kind]);

  return <instancedMesh key={capacity} ref={ref} args={[geometry, material, capacity]} frustumCulled={false} />;
}

export default function Preview3D({ doc, time }: { doc: SceneDoc; time: number }) {
  const mode = useInspection((s) => s.mode);
  const guides = useInspection((s) => s.guides);
  const frame = useMemo(() => getFrame(doc, time), [doc, time]);
  const guideClones = useMemo(() => getFrame(doc, 0).clones, [doc]);
  const guideColors = useMemo(() => ({ grid: token("--grid"), wire: token("--wire"), x: token("--iris-magenta"), y: token("--primary"), z: token("--iris-cyan") }), []);
  const colors = useMemo(
    () => ({ bg: token("--surface"), idle: new THREE.Color(token("--foreground")), live: new THREE.Color(token("--primary")) }),
    [],
  );
  const groups = useMemo(() => {
    const g = new Map<string, Clone[]>();
    for (const c of frame.clones) {
      const masks = c.clips.map((k) => k.id).join(",");
      const key = (c.shape === "box" ? `box:${c.size}` : `text:${c.text}`) + `|${masks}`;
      (g.get(key) ?? g.set(key, []).get(key)!).push(c);
    }
    return [...g.entries()];
  }, [frame]);
  // Fit the camera to the clone layout (text is wider than tall, so weight X more).
  const extent = useMemo(() => extentOf(frame.clones), [frame]);

  return (
    <Canvas gl={{ preserveDrawingBuffer: true }} onCreated={({ gl }) => { gl.localClippingEnabled = true; }} orthographic camera={{ position: [0, 0, 10], zoom: 40 }} dpr={[1, 2]}>
      <Capture extent={extent} camera={activeCamera(doc)} />
      {mode === "front" && <OutputCamera extent={extent} camera={activeCamera(doc)} />}
      {mode === "3d" && <InspectionCamera clones={frame.clones} />}
      {mode === "3d" && guides && <InspectionGuides clones={guideClones} colors={guideColors} />}
      <color attach="background" args={[colors.bg]} />
      {groups.map(([key, clones]) => (
        <Instances key={key} clones={clones} colors={colors} kind={clones[0].shape} />
      ))}
    </Canvas>
  );
}


function Capture({ extent, camera }: { extent: number; camera?: import("@/engine/schema").SceneCamera }) {
  const { gl, scene } = useThree();

  // Off-screen capture at the export size, framed the same way as the preview (used by Render).
  const extentRef = useRef(extent);
  extentRef.current = extent;
  const cameraRef = useRef(camera);
  cameraRef.current = camera;
  useEffect(() => {
    let rt: THREE.WebGLRenderTarget | null = null;
    registerCapture({
      draw: (w, h) => {
        if (!rt || rt.width !== w || rt.height !== h) {
          rt?.dispose();
          rt = new THREE.WebGLRenderTarget(w, h, { samples: 4, colorSpace: THREE.SRGBColorSpace });
        }
        // Only the scene doc drives output; inspection controls never change this camera.
        const cam = configuredCamera(cameraRef.current, w, h, extentRef.current);
        gl.setRenderTarget(rt);
        gl.render(scene, cam);
        const raw = new Uint8Array(w * h * 4);
        gl.readRenderTargetPixels(rt, 0, 0, w, h, raw);
        gl.setRenderTarget(null);
        // WebGL reads bottom-up; video frames are top-down.
        const out = new Uint8Array(raw.length);
        const row = w * 4;
        for (let y = 0; y < h; y++) out.set(raw.subarray((h - 1 - y) * row, (h - y) * row), y * row);
        return out;
      },
      dispose: () => { rt?.dispose(); rt = null; },
    });
    return () => { rt?.dispose(); registerCapture(null); };
  }, [gl, scene]);
  return null;
}
