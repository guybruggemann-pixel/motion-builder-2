import { ClientOnly } from "@tanstack/react-router";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "@/design-system/motionbuilder---brandbook-c4b4eb";
import { NodeGraph } from "@/components/NodeGraph";
import { Timeline } from "@/components/Timeline";

/** Graph and timing share selection and scene state; folding timing never changes output. */
export function BuildWorkspace({ timelineOpen, onToggleTimeline }: {
  timelineOpen: boolean;
  onToggleTimeline: () => void;
}) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex shrink-0 items-center border-t border-border bg-surface px-3">
        <Button variant="ghost" size="sm" aria-expanded={timelineOpen} aria-controls="build-timeline" onClick={onToggleTimeline}>
          {timelineOpen ? <ChevronDown /> : <ChevronRight />} Timeline
        </Button>
      </div>
      {timelineOpen && (
        <section id="build-timeline" aria-label="Field timeline" className="relative max-h-48 shrink-0 overflow-y-auto border-t border-border">
          <Timeline />
        </section>
      )}
      <section aria-label="Node graph" className="relative min-h-0 flex-1 border-t border-border">
        <ClientOnly fallback={null}>
          <NodeGraph />
        </ClientOnly>
      </section>
    </div>
  );
}