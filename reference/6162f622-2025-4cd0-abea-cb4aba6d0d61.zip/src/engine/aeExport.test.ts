import { describe, expect, it } from "vitest";
import { aeScript } from "./aeExport";
import { defaultDoc } from "./schema";
import { evaluate } from "./evaluate";

describe("After Effects export", () => {
  const c = { idle: [1, 1, 1] as [number, number, number], live: [0, 1, 0] as [number, number, number], bg: [0, 0, 0] as [number, number, number] };
  it("makes a comp at the scene size, fps and length", () => {
    const js = aeScript(defaultDoc, c);
    expect(js).toContain("addComp(\"Nodal\", 1920, 1080, 1, 4, 30)");
  });
  it("has one layer per clone with a key on every frame", () => {
    const js = aeScript(defaultDoc, c);
    const clones = evaluate(defaultDoc, 0).clones.length;
    expect(js.match(/comp\.layers\.add/g)!.length).toBe(clones);
    const T = js.match(/var T = \[(.*)\];/)![1].split(",");
    expect(T.length).toBe(120);
  });
});
