import { create } from "zustand";
import type { Clone } from "./evaluate";
import type { Vec3 } from "./schema";

/** Inspection never affects scene output or the export camera. */
export const useInspection = create<{
  mode: "front" | "3d";
  guides: boolean;
  revision: number;
  setMode: (mode: "front" | "3d") => void;
  toggleGuides: () => void;
  reset: () => void;
}>((set) => ({
  mode: "front", guides: true, revision: 0,
  setMode: (mode) => set({ mode }),
  toggleGuides: () => set((s) => ({ guides: !s.guides })),
  reset: () => set((s) => ({ revision: s.revision + 1 })),
}));

/** Conservative bounds for camera inspection, including depth and transformed geometry. */
export function inspectionBounds(clones: Clone[]) {
  if (!clones.length) return { center: [0, 0, 0] as Vec3, radius: 6, floor: -3 };
  const lo = [Infinity, Infinity, Infinity];
  const hi = [-Infinity, -Infinity, -Infinity];
  for (const clone of clones) {
    const half: Vec3 = clone.shape === "box"
      ? [clone.size / 2, clone.size / 2, clone.size / 2]
      : [Math.max(0.5, clone.text.length * 0.16), 0.3, 0];
    for (let axis = 0; axis < 3; axis++) {
      const m = clone.matrix;
      const padding = m
        ? Math.abs(m[axis]) * half[0] + Math.abs(m[axis + 4]) * half[1] + Math.abs(m[axis + 8]) * half[2]
        : Math.hypot(...half) * Math.max(...clone.scale.map(Math.abs));
      lo[axis] = Math.min(lo[axis], clone.position[axis] - padding);
      hi[axis] = Math.max(hi[axis], clone.position[axis] + padding);
    }
  }
  const center = lo.map((value, axis) => (value + hi[axis]) / 2) as Vec3;
  const radius = Math.max(1, Math.hypot(...lo.map((value, axis) => (hi[axis] - value) / 2)));
  return { center, radius, floor: lo[1] - 0.5 };
}

export function inspectionDistance(radius: number, aspect: number, fov = 45) {
  const vertical = fov * Math.PI / 360;
  const horizontal = Math.atan(Math.tan(vertical) * Math.max(0.01, aspect));
  return radius * 1.25 / Math.sin(Math.min(vertical, horizontal));
}