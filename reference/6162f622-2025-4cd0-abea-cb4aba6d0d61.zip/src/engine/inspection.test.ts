import { describe, expect, it } from "vitest";
import { inspectionBounds, inspectionDistance, useInspection } from "./inspection";
import { evaluate } from "./evaluate";
import { defaultDoc } from "./schema";

describe("3D inspection", () => {
  it("fits scene depth as well as X/Y", () => {
    const clone = evaluate(defaultDoc, 0).clones[0];
    const bounds = inspectionBounds([
      { ...clone, position: [0, 0, -10] },
      { ...clone, position: [0, 0, 10] },
    ]);
    expect(bounds.center).toEqual([0, 0, 0]);
    expect(bounds.radius).toBeGreaterThan(10);
  });
  it("increases camera distance for narrow views", () => {
    expect(inspectionDistance(6, 0.5)).toBeGreaterThan(inspectionDistance(6, 2));
  });
  it("keeps output unchanged by view mode, guides and reset", () => {
    const before = evaluate(defaultDoc, 2);
    useInspection.getState().setMode("3d");
    useInspection.getState().toggleGuides();
    useInspection.getState().reset();
    expect(evaluate(defaultDoc, 2)).toEqual(before);
    expect(defaultDoc.meta).toEqual({ mode: "ae-strict", fps: 30, duration: 4, width: 1920, height: 1080 });
  });
});