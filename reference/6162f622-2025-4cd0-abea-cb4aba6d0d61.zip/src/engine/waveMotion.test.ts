import { afterEach, describe, expect, it } from "vitest";
import { waveSample, waveWeight } from "./waveMotion";
import { evaluate } from "./evaluate";
import { getFrame } from "./bake";
import { useScene } from "./store";
import { type SceneDoc, type SineWave } from "./schema";

const wave: SineWave = { id: "s", type: "SineWave", inputs: [], ui: { x: 0, y: 0 }, frequency: 1, offset: 0.3 };
function doc(w = wave, tail: "PlainEffector" | "Spring" | "DelayEffector" = "PlainEffector"): SceneDoc {
  const ui = { x: 0, y: 0 };
  return { meta: { fps: 30, duration: 4, mode: "ae-strict" }, clusters: [], nodes: [
    { id: "b", type: "BoxPrimitive", size: 1, inputs: [], ui },
    { id: "g", type: "GridCloner", count: [2, 1], spacing: 1, inputs: ["b"], ui }, w,
    { id: "e", type: "PlainEffector", scale: [1, 3, 1], rotation: 0, inputs: ["g", "s"], ui },
    ...(tail === "Spring" ? [{ id: "tail", type: "Spring" as const, stiffness: 0.6, damping: 0.15, inputs: ["e"], ui }]
      : tail === "DelayEffector" ? [{ id: "tail", type: "DelayEffector" as const, tension: 0.5, friction: 0.3, inputs: ["e"], ui }] : []),
    { id: "o", type: "Preview", inputs: [tail === "PlainEffector" ? "e" : "tail"], ui },
  ] };
}
const initial = useScene.getState();
afterEach(() => useScene.setState(initial));

describe("Wave motion", () => {
  it("retains legacy sine including radian clone offsets", () => {
    for (const t of [0, 0.25, 1, 2.5]) for (const i of [0, 1, 8]) {
      expect(waveWeight(wave, i, t)).toBe(0.5 + 0.5 * Math.sin(Math.PI * 2 * t - i * 0.3));
    }
    expect(evaluate(doc(), 1)).toEqual(evaluate(doc({ ...wave, waveform: "sine", phase: 0, strength: 1 }), 1));
  });
  it("samples triangle at quarter-cycle boundaries", () => {
    [0.5, 1, 0.5, 0, 0.5].forEach((expected, i) => expect(waveSample(i * Math.PI / 2, "triangle")).toBeCloseTo(expected));
  });
  it("square starts high and changes to low at half cycle", () => {
    expect([0, 0.25, 0.5, 0.75, 1].map((c) => waveSample(c * Math.PI * 2, "square"))).toEqual([1, 1, 0, 0, 1]);
  });
  it("sawtooth rises and resets with wrapped negative cycles", () => {
    expect([0, 0.25, 0.5, 0.75, 1, -0.25].map((c) => waveSample(c * Math.PI * 2, "sawtooth"))).toEqual([0, 0.25, 0.5, 0.75, 0, 0.75]);
  });
  it("phase uses degrees in both directions", () => {
    expect(waveWeight({ ...wave, phase: 90 }, 0, 0)).toBe(1);
    expect(waveWeight({ ...wave, phase: -90 }, 0, 0)).toBe(0);
  });
  it("strength zero is neutral and half strength blends influence", () => {
    expect(evaluate(doc({ ...wave, strength: 0 }), 0.75).clones[0].scale).toEqual([1, 3, 1]);
    expect(waveWeight({ ...wave, strength: 0.5 }, 0, 0.75)).toBe(0.5);
  });
  it("clamps strength and falls back on nonfinite optional settings", () => {
    expect(waveWeight({ ...wave, strength: -1 }, 0, 0)).toBe(1);
    expect(waveWeight({ ...wave, strength: 2 }, 0, 0)).toBe(0.5);
    expect(waveWeight({ ...wave, strength: NaN, phase: Infinity }, 0, 0)).toBe(0.5);
  });
  it("holds the local wave clock before its own start", () => {
    const w = { ...wave, start: 2 };
    expect(waveWeight(w, 0, 1)).toBe(0.5);
    expect(waveWeight(w, 0, 2.25)).toBe(1);
    const d = doc(w);
    d.nodes = d.nodes.map((n) => n.type === "PlainEffector" ? { ...n, start: 1 } : n);
    expect(evaluate(d, 0).clones[0].scale[1]).toBe(1);
    expect(evaluate(d, 2.25).clones[0].scale[1]).toBe(3);
  });
  it("multiplies mixed waves with field influence", () => {
    const d = doc({ ...wave, strength: 0.5, phase: -90 });
    d.nodes.push({ ...wave, id: "s2", waveform: "square" }, { id: "f", type: "LinearField", from: 0, to: 0, falloff: 2, inputs: [], ui: { x: 0, y: 0 } });
    d.nodes = d.nodes.map((n) => n.type === "PlainEffector" ? { ...n, inputs: [...n.inputs, "s2", "f"] } : n);
    expect(evaluate(d, 0).clones[0].weight).toBe(0.375);
  });
  it.each(["Spring", "DelayEffector"] as const)("%s agrees in ordered and random-access sampling", (tail) => {
    const d = doc({ ...wave, waveform: "triangle", phase: 30 }, tail);
    for (let frame = 0; frame <= 60; frame++) evaluate(d, frame / 30);
    expect(evaluate(d, 2)).toEqual(evaluate(structuredClone(d), 2));
    expect(getFrame(d, 2)).toEqual(evaluate(d, 2));
  });
  it("undo/redo replaces documents and invalidates cached wave frames", () => {
    const d = doc();
    useScene.setState({ doc: d, past: [], future: [] });
    expect(getFrame(d, 0).clones[0].weight).toBe(0.5);
    useScene.getState().updateNode("s", { phase: 90 });
    const changed = useScene.getState().doc;
    expect(getFrame(changed, 0).clones[0].weight).toBe(1);
    useScene.getState().undo();
    expect(useScene.getState().doc).toBe(d);
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(changed);
  });
});