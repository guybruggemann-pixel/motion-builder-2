import { create } from "zustand";

/** Playhead lives in its own store so only the preview + playbar re-render each frame, not the whole workspace. */
export type TimeUnit = "seconds" | "frames";
export const useTime = create<{ time: number; setTime: (t: number) => void; unit: TimeUnit; setUnit: (u: TimeUnit) => void }>((set) => ({
  time: 1.2,
  setTime: (time) => set({ time }),
  unit: "seconds",
  setUnit: (unit) => set({ unit }),
}));

/** Readout for a time value: mm:ss.ff in seconds mode, zero-padded frame number in frames mode. */
export function formatTime(t: number, unit: TimeUnit, fps: number) {
  if (unit === "frames") return String(Math.round(t * fps)).padStart(4, "0");
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${String(m).padStart(2, "0")}:${s.toFixed(2).padStart(5, "0")}`;
}
