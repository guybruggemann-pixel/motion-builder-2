import { afterEach, describe, expect, it } from "vitest";
import { editScale, setUniformScale } from "./scale";
import { createNode, defaultDoc, type PlainEffector, type SceneDoc, type TransformNode } from "./schema";
import { evaluate } from "./evaluate";
import { getFrame } from "./bake";
import { useScene } from "./store";
import { aeScript } from "./aeExport";

const initial = useScene.getState();
afterEach(() => useScene.setState(initial));
const ui = { x: 0, y: 0 };
function scene(node: PlainEffector | TransformNode): SceneDoc {
  return { ...defaultDoc, clusters: [], nodes: [
    { ...createNode("BoxPrimitive", "b", ui) },
    { ...node, inputs: ["b"] },
    { id: "out", type: "Preview", ui, inputs: [node.id] },
  ] };
}

describe.each(["PlainEffector", "Transform"] as const)("%s uniform scaling", (type) => {
  function node(): PlainEffector | TransformNode {
    const n = createNode(type, "n", ui);
    if (n.type !== "PlainEffector" && n.type !== "Transform") throw new Error("Expected scalable node");
    return { ...n, scale: [2, 3, 4] };
  }
  it("links all XYZ axes using X without mutating the old scene", () => {
    const n = node();
    expect(setUniformScale(n, true)).toEqual({ uniformScale: true, scale: [2, 2, 2] });
    expect(n.scale).toEqual([2, 3, 4]);
  });
  it("edits every linked axis and evaluates the same uniform scale", () => {
    const n = { ...node(), ...setUniformScale(node(), true) };
    const updated = { ...n, ...editScale(n, 1, 3) };
    expect(updated.scale).toEqual([3, 3, 3]);
    expect(evaluate(scene(updated), 0).clones[0].scale).toEqual([3, 3, 3]);
  });
  it("unlinking preserves values and allows independent axes", () => {
    const n = { ...node(), uniformScale: true, scale: [2, 2, 2] as [number, number, number] };
    const unlinked = { ...n, ...setUniformScale(n, false) };
    expect(unlinked.scale).toEqual([2, 2, 2]);
    expect(editScale(unlinked, 1, 4).scale).toEqual([2, 4, 2]);
  });
  it("keeps legacy nonuniform vectors unchanged until edited", () => {
    const n = node();
    expect(evaluate(scene(n), 0)).toEqual(evaluate(scene({ ...n, uniformScale: false }), 0));
    expect(editScale(n, 0, 5).scale).toEqual([5, 3, 4]);
  });
  it("undoes/redoes linked mode and invalidates cached frames", () => {
    const n = node();
    useScene.setState({ doc: scene(n), past: [], future: [] });
    const before = useScene.getState().doc;
    const oldFrame = getFrame(before, 0);
    useScene.getState().updateNode("n", setUniformScale(n, true));
    const after = useScene.getState().doc;
    expect(getFrame(after, 0)).not.toEqual(oldFrame);
    expect(JSON.parse(JSON.stringify(after)).nodes[1].uniformScale).toBe(true);
    useScene.getState().undo();
    expect(useScene.getState().doc).toBe(before);
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(after);
  });
  it("keeps bake and flat AE export identical to explicit XYZ vectors", () => {
    const n = { ...node(), ...setUniformScale(node(), true) };
    const doc = scene(n);
    expect(getFrame(doc, 0)).toEqual(evaluate(doc, 0));
    const colors = { idle: [1, 1, 1] as [number, number, number], live: [1, 1, 1] as [number, number, number], bg: [0, 0, 0] as [number, number, number] };
    expect(aeScript(doc, colors)).toBe(aeScript(scene({ ...n, uniformScale: false }), colors));
  });
});

it("preserves zero and negative uniform Transform scale", () => {
  const n: TransformNode = { id: "t", type: "Transform", ui, inputs: [], scale: [1, 1, 1], position: [0, 0, 0], rotation: [0, 0, 0], uniformScale: true };
  expect(editScale(n, 0, 0).scale).toEqual([0, 0, 0]);
  expect(editScale(n, 0, -2).scale).toEqual([-2, -2, -2]);
  expect(editScale(n, 0, NaN).scale).toEqual([1, 1, 1]);
});