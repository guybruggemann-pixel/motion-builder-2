import type { SineWave, Waveform } from "./schema";

export const WAVEFORMS: { value: Waveform; label: string }[] = [
  { value: "sine", label: "Sine" }, { value: "triangle", label: "Triangle" },
  { value: "square", label: "Square" }, { value: "sawtooth", label: "Sawtooth" },
];

/** Normalized waveform. Square starts high; sawtooth resets to zero each cycle. */
export function waveSample(angle: number, waveform: Waveform = "sine"): number {
  const cycle = ((angle / (Math.PI * 2)) % 1 + 1) % 1;
  switch (waveform) {
    case "triangle": return 0.5 + Math.asin(Math.sin(angle)) / Math.PI;
    case "square": return cycle < 0.5 ? 1 : 0;
    case "sawtooth": return cycle;
    default: return 0.5 + 0.5 * Math.sin(angle);
  }
}

/** Neutral strength leaves other modifiers intact; old docs retain full sine influence. */
export function waveWeight(wave: SineWave, cloneIndex: number, time: number): number {
  const phase = Number.isFinite(wave.phase) ? wave.phase ?? 0 : 0;
  const strength = Math.min(1, Math.max(0, Number.isFinite(wave.strength) ? wave.strength ?? 1 : 1));
  const local = Math.max(0, time - (wave.start ?? 0));
  const angle = Math.PI * 2 * wave.frequency * local - cloneIndex * wave.offset + phase * Math.PI / 180;
  return 1 - strength + strength * waveSample(angle, wave.waveform);
}