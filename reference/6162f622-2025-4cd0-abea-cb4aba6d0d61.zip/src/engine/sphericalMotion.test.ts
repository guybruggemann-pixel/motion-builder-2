import { afterEach, describe, expect, it } from "vitest";
import { editableSphere, isLegacySphere, sphereRadius } from "./sphericalMotion";
import { evaluate } from "./evaluate";
import { getFrame } from "./bake";
import { useScene } from "./store";
import { createNode, defaultDoc, type SceneDoc, type SphericalField } from "./schema";

const ui = { x: 0, y: 0 };
const field = (patch: Partial<SphericalField> = {}): SphericalField => ({ id: "f", type: "SphericalField", inputs: [], ui, falloff: 0, center: [0, 0, 0], radiusFrom: 0, radiusTo: 8, start: 1, end: 3, curve: "linear", ...patch });
const scene = (f: SphericalField, effStart = 0): SceneDoc => ({ ...defaultDoc, clusters: [], nodes: [
  { id: "b", type: "BoxPrimitive", ui, inputs: [], size: 1 },
  { id: "g", type: "GridCloner", ui, inputs: ["b"], count: [1, 1, 3], spacing: 2 },
  f,
  { id: "e", type: "PlainEffector", ui, inputs: ["g", "f"], scale: [2, 2, 2], rotation: 0, start: effStart },
  { id: "out", type: "Preview", ui, inputs: ["e"] },
] });
const initial = useScene.getState();
afterEach(() => useScene.setState(initial));

describe("Spherical Field intervals", () => {
  it("holds start/end radii outside its absolute interval", () => {
    const f = field({ radiusFrom: 2, radiusTo: 6 });
    expect([0, 1, 2, 3, 4].map((t) => sphereRadius(f, t, 4, []))).toEqual([2, 2, 4, 6, 6]);
  });
  it("supports shrinking and static radii", () => {
    expect(sphereRadius(field({ radiusFrom: 8, radiusTo: 0 }), 2, 4, [])).toBe(4);
    expect(sphereRadius(field({ radiusFrom: 3, radiusTo: 3 }), 4, 4, [])).toBe(3);
  });
  it("uses preset and custom easing", () => {
    expect(sphereRadius(field({ curve: "ease-in" }), 2, 4, [])).toBeLessThan(4);
    expect(sphereRadius(field({ curve: "ease-out" }), 2, 4, [])).toBeGreaterThan(4);
    expect(sphereRadius(field({ curve: "custom", bezier: [0, 0, 1, 1] }), 2, 4, [])).toBe(4);
  });
  it("handles instantaneous intervals and nonnegative radii", () => {
    const f = field({ start: 2, end: 2, radiusFrom: -2, radiusTo: 6 });
    expect(sphereRadius(f, 1, 4, [])).toBe(0);
    expect(sphereRadius(f, 2, 4, [])).toBe(6);
  });
  it("preserves speed-only legacy looping, including start offsets", () => {
    const old: SphericalField = { id: "f", type: "SphericalField", inputs: [], ui, falloff: 2, speed: 2, start: 1 };
    expect(isLegacySphere(old)).toBe(true);
    expect([0, 1, 2, 3, 4].map((t) => sphereRadius(old, t, 4, [0, 2, 4]))).toEqual([0, 0, 3, 0, 3]);
    expect(evaluate(scene(old), 2).clones.map((c) => c.weight)).toEqual([0.5, 1, 0.5]);
  });
  it("converts legacy settings only on edit and defaults new nodes to explicit motion", () => {
    const old: SphericalField = { id: "f", type: "SphericalField", inputs: [], ui, falloff: 2, speed: 1 };
    const edited = editableSphere(old, 4, [[0, 0, 6]]);
    expect(edited).toMatchObject({ radiusFrom: 0, radiusTo: 8, center: [0, 0, 0], start: 0, end: 4, curve: "linear", speed: undefined });
    expect(isLegacySphere(edited)).toBe(false);
    expect(old.speed).toBe(1);
    expect(createNode("SphericalField", "new", ui)).toMatchObject({ center: [0, 0, 0], radiusFrom: 0, radiusTo: 8, curve: "linear" });
  });
});

describe("Spherical influence", () => {
  it("measures XYZ distance from its center including depth", () => {
    const clones = evaluate(scene(field({ center: [0, 0, 2], radiusFrom: 0.5, radiusTo: 0.5 })), 0).clones;
    expect(clones.map((c) => c.weight)).toEqual([0, 0, 1]);
    expect(clones.map((c) => c.scale)).toEqual([[1, 1, 1], [1, 1, 1], [2, 2, 2]]);
  });
  it("applies soft falloff around the radius", () => {
    expect(evaluate(scene(field({ radiusFrom: 2, radiusTo: 2, falloff: 2 })), 0).clones.map((c) => c.weight)).toEqual([0.5, 1, 0.5]);
  });
  it("keeps absolute field timing independent of Plain Effector start", () => {
    const doc = scene(field({ radiusFrom: 0, radiusTo: 4, start: 1, end: 3 }), 1);
    expect(evaluate(doc, 0.5).clones.map((c) => c.weight)).toEqual([0, 0, 0]);
    expect(evaluate(doc, 2).clones.map((c) => c.weight)).toEqual([1, 1, 1]);
  });
  it("samples static transform anchors and ignores animated offsets", () => {
    const doc = scene(field({ center: [1, 0, 5], radiusFrom: 0.5, radiusTo: 0.5 }));
    doc.nodes.splice(2, 0,
      { id: "t", type: "Transform", ui, inputs: ["g"], position: [1, 0, 3], rotation: [0, 0, 0], scale: [1, 1, 1] },
      { id: "offset", type: "PlainEffector", ui, inputs: ["t"], position: [10, 0, 0], rotation: 0, scale: [1, 1, 1] });
    const eff = doc.nodes.find((n) => n.id === "e");
    if (!eff) throw new Error("Missing effector");
    eff.inputs = ["offset", "f"];
    expect(evaluate(doc, 0).clones.map((c) => c.scale)).toEqual([[1, 1, 1], [1, 1, 1], [2, 2, 2]]);
  });
  it("combines fields with max influence and keeps deterministic cached frames", () => {
    const doc = scene(field({ center: [0, 0, 2], radiusFrom: 0.5, radiusTo: 0.5 }));
    doc.nodes.splice(3, 0, field({ id: "f2", center: [0, 0, -2], radiusFrom: 0.5, radiusTo: 0.5 }));
    const eff = doc.nodes.find((n) => n.id === "e");
    if (!eff) throw new Error("Missing effector");
    eff.inputs.push("f2");
    expect(evaluate(doc, 2).clones.map((c) => c.weight)).toEqual([1, 0, 1]);
    expect(getFrame(doc, 2)).toEqual(evaluate(structuredClone(doc), 2));
  });
  it("undoes/redoes field edits and invalidates bake caches", () => {
    useScene.setState({ doc: scene(field()), past: [], future: [] });
    const before = useScene.getState().doc;
    const frame = getFrame(before, 2);
    useScene.getState().updateNode("f", { center: [0, 0, 2], radiusFrom: 0.5, radiusTo: 0.5 });
    const after = useScene.getState().doc;
    expect(getFrame(after, 2)).not.toEqual(frame);
    useScene.getState().undo();
    expect(useScene.getState().doc).toBe(before);
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(after);
  });
});