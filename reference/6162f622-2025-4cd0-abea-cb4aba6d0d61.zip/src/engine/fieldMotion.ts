import BezierEasing from "bezier-easing";
import type { BezierPoints, LinearField, MotionCurve } from "./schema";

export const CURVES: { value: MotionCurve; label: string; points: BezierPoints }[] = [
  { value: "linear", label: "Linear", points: [0, 0, 1, 1] },
  { value: "ease-in", label: "Ease in", points: [0.42, 0, 1, 1] },
  { value: "ease-out", label: "Ease out", points: [0, 0, 0.58, 1] },
  { value: "ease-in-out", label: "Ease in/out", points: [0.42, 0, 0.58, 1] },
  { value: "custom", label: "Custom", points: [0.25, 0.1, 0.25, 1] },
];

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const finite = (v: number | undefined, fallback: number) => v !== undefined && Number.isFinite(v) ? v : fallback;

export function curvePoints(curve: MotionCurve = "linear", custom?: BezierPoints): BezierPoints {
  const points = curve === "custom" && custom ? custom : CURVES.find((c) => c.value === curve)?.points ?? CURVES[0].points;
  return points.map((v, i) => clamp(finite(v, i < 2 ? 0 : 1), 0, 1)) as BezierPoints;
}

const easingCache = new Map<string, (t: number) => number>();
export function easeProgress(progress: number, curve: MotionCurve = "linear", custom?: BezierPoints) {
  const points = curvePoints(curve, custom);
  const key = points.join(",");
  let ease = easingCache.get(key);
  if (!ease) {
    ease = BezierEasing(...points);
    if (easingCache.size >= 256) easingCache.clear();
    easingCache.set(key, ease);
  }
  return ease(clamp(progress, 0, 1));
}

export function fieldInterval(field: { start?: number; end?: number }, duration: number) {
  const start = clamp(finite(field.start, 0), 0, duration);
  const end = clamp(finite(field.end, duration), start, duration);
  return { start, end };
}

export function isLegacyField(field: LinearField) {
  return field.speed !== undefined && field.from === undefined && field.to === undefined && field.end === undefined && field.curve === undefined;
}

/** Old documents retain their automatic, looping sweep until explicitly edited. */
export function fieldPosition(field: LinearField, time: number, duration: number, xs: number[]): number {
  const lo = (xs.length ? Math.min(...xs) : 0) - field.falloff;
  const hi = (xs.length ? Math.max(...xs) : 0) + field.falloff;
  if (isLegacyField(field)) {
    const local = Math.max(0, time - (field.start ?? 0));
    return lo + (hi - lo) * ((local * (field.speed ?? 1)) % duration) / duration;
  }
  const { start, end } = fieldInterval(field, duration);
  const progress = end > start ? (time - start) / (end - start) : time < start ? 0 : 1;
  const eased = easeProgress(progress, field.curve, field.bezier);
  const from = finite(field.from, lo);
  const to = finite(field.to, hi);
  return from + (to - from) * eased;
}

/** Resolve old automatic endpoints from the same incoming clones used by evaluation. */
export function editableField(field: LinearField, duration: number, xs: number[]): LinearField {
  const { start, end } = fieldInterval(field, duration);
  return {
    ...field, speed: undefined, start, end,
    from: finite(field.from, (xs.length ? Math.min(...xs) : 0) - field.falloff),
    to: finite(field.to, (xs.length ? Math.max(...xs) : 0) + field.falloff),
    curve: field.curve ?? "linear",
  };
}