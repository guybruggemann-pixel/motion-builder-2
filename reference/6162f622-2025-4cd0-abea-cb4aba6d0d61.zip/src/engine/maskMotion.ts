import { easeProgress, fieldInterval } from "./fieldMotion";
import type { MaskNode } from "./schema";

/** Absolute scene-time clipping; optional settings preserve old linear wipes. */
export function maskPosition(mask: MaskNode, time: number, duration: number): number {
  const { start, end } = fieldInterval(mask, duration);
  const legacy = mask.end === undefined && mask.curve === undefined && mask.bezier === undefined;
  const progress = end > start ? (time - start) / (end - start) : legacy || time >= start ? 1 : 0;
  return mask.from + (mask.to - mask.from) * easeProgress(progress, mask.curve, mask.bezier);
}