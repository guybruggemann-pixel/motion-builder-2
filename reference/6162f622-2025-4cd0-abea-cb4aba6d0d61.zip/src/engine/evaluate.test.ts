import { describe, expect, it } from "vitest";
import { evaluate, fieldWeight, gridPositions, upstream } from "./evaluate";
import { defaultDoc, type SceneDoc } from "./schema";

const without = (doc: SceneDoc, types: string[]): SceneDoc => {
  const nodes = doc.nodes.filter((n) => !types.includes(n.type));
  const ids = new Set(nodes.map((n) => n.id));
  return { ...doc, nodes: nodes.map((n) => ({ ...n, inputs: n.inputs.filter((i) => ids.has(i)) })) };
};

describe("engine", () => {
  it("grid cloner makes count X × count Y clones", () => {
    expect(gridPositions([6, 4], 1)).toHaveLength(24);
  });
  it("linear field is full behind the plane and zero ahead of it", () => {
    expect(fieldWeight(-10, 0, 2)).toBe(1);
    expect(fieldWeight(10, 0, 2)).toBe(0);
    expect(fieldWeight(0, 0, 2)).toBe(0.5);
  });
  it("same doc and time give the same frame", () => {
    expect(evaluate(defaultDoc, 1.5)).toEqual(evaluate(defaultDoc, 1.5));
  });
  it("plain effector scale [1,3,1] is reached at full field weight", () => {
    const doc = without(defaultDoc, ["DelayEffector", "LinearField"]);
    doc.nodes = doc.nodes.map((n) => (n.type === "Preview" ? { ...n, inputs: ["eff_1"] } : n));
    expect(evaluate(doc, 0).clones[0].scale).toEqual([1, 3, 1]);
  });
  it("only the tree connected to Preview is rendered", () => {
    const doc = { ...defaultDoc, nodes: defaultDoc.nodes.map((n) => (n.type === "Preview" ? { ...n, inputs: [] } : n)) };
    expect(upstream(doc).size).toBe(0);
    expect(evaluate(doc, 1).clones).toHaveLength(0);
  });
  it("Preview connected straight to a cloner shows the clones without effects", () => {
    const doc = { ...defaultDoc, nodes: defaultDoc.nodes.map((n) => (n.type === "Preview" ? { ...n, inputs: ["cln_1"] } : n)) };
    const f = evaluate(doc, 2);
    expect(f.clones).toHaveLength(24);
    expect(f.clones[0].scale).toEqual([1, 1, 1]);
  });
});

describe("node set", () => {
  const base = (nodes: SceneDoc["nodes"]): SceneDoc => ({ ...defaultDoc, nodes, clusters: [] });
  const ui = { x: 0, y: 0 };
  it("radial cloner makes `count` clones on a circle of `radius`", () => {
    const f = evaluate(base([
      { id: "b", type: "BoxPrimitive", size: 1, inputs: [], ui },
      { id: "r", type: "RadialCloner", count: 12, radius: 3, inputs: ["b"], ui },
      { id: "o", type: "Preview", inputs: ["r"], ui },
    ]), 0);
    expect(f.clones[0].shape).toBe("box");
    expect(f.clones).toHaveLength(12);
    expect(Math.hypot(f.clones[5].position[0], f.clones[5].position[1])).toBeCloseTo(3);
  });
  it("two stacked effectors multiply their scale", () => {
    const f = evaluate(base([
      { id: "t", type: "TextNode", text: "A", split: "none", inputs: [], ui },
      { id: "e1", type: "PlainEffector", scale: [2, 1, 1], rotation: 0, inputs: ["t"], ui },
      { id: "e2", type: "PlainEffector", scale: [3, 1, 1], rotation: 0, inputs: ["e1"], ui },
      { id: "o", type: "Preview", inputs: ["e2"], ui },
    ]), 0);
    expect(f.clones[0].scale[0]).toBe(6);
  });
  it("sine wave modulates the effector weight between 0 and 1", () => {
    const f = evaluate(base([
      { id: "t", type: "TextNode", text: "A", split: "none", inputs: [], ui },
      { id: "s", type: "SineWave", frequency: 1, offset: 0, inputs: [], ui },
      { id: "e", type: "PlainEffector", scale: [1, 3, 1], rotation: 0, inputs: ["t", "s"], ui },
      { id: "o", type: "Preview", inputs: ["e"], ui },
    ]), 0.25);
    expect(f.clones[0].weight).toBeCloseTo(1);
  });
});

describe("Combiner", () => {
  it("renders every wired tree together, spread along X", async () => {
    const { createNode } = await import("./schema");
    const t = createNode("TextNode", "t1", { x: 0, y: 0 });
    const b = createNode("BoxPrimitive", "b1", { x: 0, y: 0 });
    const c = { ...createNode("Combiner", "c1", { x: 0, y: 0 }), inputs: ["t1", "b1"], offset: 4 } as any;
    const p = { ...createNode("Preview", "out", { x: 0, y: 0 }), inputs: ["c1"] };
    const f = evaluate({ meta: { mode: "ae-strict", fps: 30, duration: 4 }, nodes: [t, b, c, p], clusters: [] }, 0);
    expect(f.clones.map((x) => x.shape)).toEqual(["text", "box"]);
    expect(f.clones.map((x) => x.position[0])).toEqual([-2, 2]);
  });
});

describe("spring cache", () => {
  it("gives the same frame whether time is visited in order or jumped to", () => {
    const a = structuredClone(defaultDoc);
    for (let f = 0; f <= 90; f++) evaluate(a, f / 30);
    const fresh = structuredClone(defaultDoc);
    expect(evaluate(a, 3).clones).toEqual(evaluate(fresh, 3).clones);
  });
});

describe("Mask", () => {
  it("sweeps its edge from start to end over the clip", async () => {
    const { createNode } = await import("./schema");
    const t = createNode("TextNode", "t1", { x: 0, y: 0 });
    const m = { ...createNode("Mask", "m1", { x: 0, y: 0 }), inputs: ["t1"], from: -4, to: 4 } as any;
    const p = { ...createNode("Preview", "out", { x: 0, y: 0 }), inputs: ["m1"] };
    const doc = { meta: { mode: "ae-strict" as const, fps: 30, duration: 4 }, nodes: [t, m, p], clusters: [] };
    expect(evaluate(doc, 0).clones[0].clips[0].value).toBe(-4);
    expect(evaluate(doc, 2).clones[0].clips[0].value).toBe(0);
    expect(evaluate(doc, 4).clones[0].clips[0].value).toBe(4);
  });
});

import { createNode as _cn } from "./schema";
describe("nested cloners", () => {
  it("Grid -> Radial puts a ring at every grid point", () => {
    const txt = { ..._cn("TextNode", "t", { x: 0, y: 0 }) };
    const grid = { ..._cn("GridCloner", "g", { x: 0, y: 0 }), inputs: ["t"], count: [2, 2, 1] } as never;
    const rad = { ..._cn("RadialCloner", "r", { x: 0, y: 0 }), inputs: ["g"], count: 6 } as never;
    const out = { ..._cn("Preview", "o", { x: 0, y: 0 }), inputs: ["r"] } as never;
    const doc = { meta: { mode: "ae-strict", fps: 30, duration: 4 }, nodes: [txt, grid, rad, out], clusters: [] } as never;
    expect(evaluate(doc, 0).clones.length).toBe(24);
  });
});

describe("node start time", () => {
  it("a Plain Effector with Start 2 s has no effect before 2 s", () => {
    const doc = { ...defaultDoc, nodes: defaultDoc.nodes.map((n) => (n.type === "PlainEffector" ? { ...n, start: 2 } : n)) };
    expect(evaluate(doc, 1).clones.every((c) => c.scale.every((v) => v === 1))).toBe(true);
    expect(evaluate(doc, 3).clones.some((c) => c.scale.some((v) => v !== 1))).toBe(true);
  });
  it("a Mask with Start 2 s holds its start edge until 2 s", () => {
    const base = defaultDoc.nodes.find((n) => n.type === "Preview")!;
    const mask = { id: "m", type: "Mask", axis: "x", from: -6, to: 6, invert: false, start: 2, inputs: base.inputs, ui: { x: 0, y: 0 } } as never;
    const doc = { ...defaultDoc, nodes: [...defaultDoc.nodes.map((n) => (n.type === "Preview" ? { ...n, inputs: ["m"] } : n)), mask] };
    expect(evaluate(doc, 1).clones[0].clips[0].value).toBe(-6);
    expect(evaluate(doc, 3).clones[0].clips[0].value).toBe(0);
  });
});
