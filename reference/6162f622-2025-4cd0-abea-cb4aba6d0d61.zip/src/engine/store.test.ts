import { beforeEach, describe, expect, it } from "vitest";
import { useScene } from "./store";
import { defaultDoc } from "./schema";

const node = (id: string) => useScene.getState().doc.nodes.find((n) => n.id === id)!;

describe("connections", () => {
  beforeEach(() => useScene.setState({ doc: defaultDoc, past: [], future: [] }));
  it("Preview accepts one wire; a new wire replaces the old one", () => {
    useScene.getState().connect("eff_1", "out_1");
    expect(node("out_1").inputs).toEqual(["eff_1"]);
  });
  it("generators and fields accept no incoming wires", () => {
    useScene.getState().connect("cln_1", "fld_1");
    expect(node("fld_1").inputs).toEqual([]);
  });
  it("the Preview node cannot be deleted", () => {
    useScene.getState().removeNodes(["out_1"]);
    expect(node("out_1")).toBeDefined();
  });
});

describe("scene settings", () => {
  it("changes length and frame rate, undoably", async () => {
    const { useScene } = await import("./store");
    const { totalFrames } = await import("./bake");
    useScene.getState().updateMeta({ duration: 10, fps: 24 });
    expect(totalFrames(useScene.getState().doc)).toBe(241);
    useScene.getState().undo();
    expect(useScene.getState().doc.meta.duration).not.toBe(10);
  });
});
