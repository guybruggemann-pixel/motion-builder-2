import { resolveNode } from "./keyframes";
import { CATEGORY, type SceneDoc, type SceneNode, type Vec3 } from "./schema";
import { fieldPosition } from "./fieldMotion";
import { maskPosition } from "./maskMotion";
import { waveWeight } from "./waveMotion";
import { delayBlend, delayTargetTime } from "./delayMotion";
import { isLegacySphere, sphereCenter, sphereDistance, sphereRadius } from "./sphericalMotion";
import { mat4 } from "gl-matrix";
import { effectorRotation, identityMatrix, matrixPosition, matrixValues, transformMatrix } from "./transforms";

/** Keep the side where axis value <= `value` (or >= when inverted). `id` is the Mask node id. */
export interface Clip { id: string; axis: "x" | "y" | "z"; value: number; invert: boolean }
export interface Clone { position: Vec3; scale: Vec3; rotation: number; matrix?: number[]; weight: number; shape: "text" | "box"; text: string; size: number; clips: Clip[] }
export interface Frame { clones: Clone[] }

/** One effector's contribution: a transform offset scaled by a per-clone weight over time. */
interface Layer { scale: Vec3; rotation: number; position?: Vec3; rotationXYZ?: Vec3; weight: (i: number, time: number) => number; matrix?: mat4 }
interface Part { shape: "text" | "box"; text: string; size: number; positions: Vec3[]; bases?: number[][]; layers: Layer[]; clips: Clip[] }
/** A stream is one or more independent parts; a Combiner merges several trees into one stream. */
type Stream = Part[];

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Static transforms multiply on the left; effector offsets act in clone-local space. */
function partMatrix(part: Part, i: number, time: number, staticOnly = false): mat4 {
  const matrix = identityMatrix();
  const base = part.bases?.[i];
  if (base) mat4.copy(matrix, base);
  else mat4.translate(matrix, matrix, part.positions[i]);
  for (const layer of part.layers) {
    if (layer.matrix) mat4.multiply(matrix, layer.matrix, matrix);
    else if (!staticOnly) {
      const w = layer.weight(i, time);
      if (layer.position) mat4.translate(matrix, matrix, layer.position.map((v) => v * w) as Vec3);
      if (layer.rotationXYZ?.[0] || layer.rotationXYZ?.[1]) {
        const offset = transformMatrix({ position: [0, 0, 0], rotation: layer.rotationXYZ.map((v) => v * w) as Vec3, scale: layer.scale.map((v) => 1 + (v - 1) * w) as Vec3 });
        mat4.multiply(matrix, matrix, offset);
      } else {
        mat4.rotateZ(matrix, matrix, layer.rotation * w);
        mat4.scale(matrix, matrix, layer.scale.map((v) => 1 + (v - 1) * w) as Vec3);
      }
    }
  }
  return matrix;
}

/** Ids of every node feeding into the Preview node (the Preview itself excluded). */
export function upstream(doc: SceneDoc): Set<string> {
  const byId = new Map(doc.nodes.map((n) => [n.id, n]));
  const out = new Set<string>();
  const preview = doc.nodes.find((n) => n.type === "Preview");
  const stack = [...(preview?.inputs ?? [])];
  while (stack.length) {
    const id = stack.pop();
    if (!id || out.has(id)) continue;
    const node = byId.get(id);
    if (!node) continue;
    out.add(id);
    stack.push(...node.inputs);
  }
  return out;
}

/** Linear field: a plane sweeping along X; returns 0..1 influence for a point. */
export function fieldWeight(x: number, planeX: number, falloff: number) {
  if (falloff <= 0) return x <= planeX ? 1 : 0;
  return clamp01((planeX - x) / falloff + 0.5);
}

/** Grid positions centred on the origin. */
export function gridPositions(count: [number, number, number?], spacing: number, depthSpacing = spacing): Vec3[] {
  const [cx, cy, cz] = [count[0], count[1], count[2] ?? 1].map((c) => Math.max(1, Math.round(c)));
  const out: Vec3[] = [];
  for (let z = 0; z < cz; z++)
    for (let y = 0; y < cy; y++)
      for (let x = 0; x < cx; x++)
        out.push([(x - (cx - 1) / 2) * spacing, ((cy - 1) / 2 - y) * spacing, (z - (cz - 1) / 2) * depthSpacing]);
  return out;
}

/** Positions evenly spaced on a circle. */
export function radialPositions(count: number, radius: number, plane: "XY" | "XZ" | "YZ" = "XY"): Vec3[] {
  const n = Math.max(1, Math.round(count));
  return Array.from({ length: n }, (_, i): Vec3 => {
    const a = (i / n) * Math.PI * 2;
    const u = Math.cos(a) * radius;
    const v = Math.sin(a) * radius;
    return plane === "XZ" ? [u, 0, v] : plane === "YZ" ? [0, u, v] : [u, v, 0];
  });
}

/**
 * Deterministic evaluation at time t of the tree connected to the Preview node.
 * Springs are integrated from t=0 at the doc's fps, so the same doc + time always
 * yields the same frame (needed for export).
 */
/** Spring/Delay simulations per doc. Docs are immutable, so a new edit = a new cache entry. */
const simCache = new WeakMap<SceneDoc, Map<string, number[][]>>();

export function evaluate(doc: SceneDoc, t: number): Frame {
  let docCache = simCache.get(doc);
  if (!docCache) simCache.set(doc, (docCache = new Map()));
  const empty: Frame = { clones: [] };
  const byId = new Map(doc.nodes.map((n) => [n.id, resolveNode(n, t)]));
  const { duration, fps } = doc.meta;
  const visiting = new Set<string>();

  const isModifier = (n: SceneNode) => CATEGORY[n.type] === "field" || n.type === "SineWave";

  const stream = (id: string | undefined): Stream | null => {
    const n = id ? byId.get(id) : undefined;
    if (!n || visiting.has(n.id)) return null;
    visiting.add(n.id);
    try {
      return evalNode(n);
    } finally {
      visiting.delete(n.id);
    }
  };

  const mainInput = (n: SceneNode) => n.inputs.find((i) => {
    const m = byId.get(i);
    return m && !isModifier(m);
  });

  const evalNode = (n: SceneNode): Stream | null => {
    switch (n.type) {
      case "TextNode": {
        const lines = n.split === "lines" ? n.text.split(/\r\n|\r|\n/) : [n.text];
        return lines.map((text, i) => ({ shape: "text", text, size: 1, positions: [[0, (lines.length - 1) / 2 - i, 0]], layers: [], clips: [] }));
      }
      case "BoxPrimitive":
        return [{ shape: "box", text: "", size: n.size, positions: [[0, 0, 0]], layers: [], clips: [] }];
      case "GridCloner":
      case "RadialCloner": {
        const src = stream(mainInput(n));
        if (!src) return null;
        const local = n.type === "GridCloner" ? gridPositions(n.count, n.spacing, n.depthSpacing) : radialPositions(n.count, n.radius, n.plane);
        if (src.some((part) => part.bases || part.layers.some((layer) => layer.matrix))) {
          return src.map((part) => {
            const bases = part.positions.flatMap((_, i) => {
              const base = partMatrix(part, i, t, true);
              return local.map((p) => {
                const matrix = mat4.clone(base);
                matrix[12] += p[0]; matrix[13] += p[1]; matrix[14] += p[2];
                return matrixValues(matrix);
              });
            });
            return { ...part, bases, positions: bases.map(matrixPosition), layers: [] };
          });
        }
        // Stacked cloners nest: every incoming clone gets its own copy of this cloner's layout.
        return src.map((part) => ({
          ...part,
          positions: part.positions.flatMap((o) => local.map((p): Vec3 => [o[0] + p[0], o[1] + p[1], o[2] + p[2]])),
          layers: [],
        }));
      }
      case "Transform": {
        const src = stream(mainInput(n));
        if (!src) return null;
        const matrix = transformMatrix(n);
        return src.map((part) => ({ ...part, layers: [...part.layers, { matrix, scale: [1, 1, 1], rotation: 0, weight: () => 0 }] }));
      }
      case "PlainEffector": {
        const src = stream(mainInput(n));
        if (!src) return null;
        const mods = n.inputs.map((i) => byId.get(i)).filter((m): m is SceneNode => !!m && isModifier(m));
        return src.map((part) => {
          const pos = part.bases || part.layers.some((layer) => layer.matrix)
            ? part.positions.map((_, i) => matrixPosition(partMatrix(part, i, t, true))) : part.positions;
          const xs = pos.map((p) => p[0]);
          const fields = mods.filter((m) => CATEGORY[m.type] === "field");
          const sines = mods.filter((m) => m.type === "SineWave");
          const spheres = new Map(fields.filter((f) => f.type === "SphericalField").map((f) => [f.id, pos.map((p) => sphereDistance(p, sphereCenter(f)))]));
          const fieldAt = (i: number, time: number, absoluteTime: number): number => {
            if (!fields.length) return 1;
            return Math.max(
              ...fields.map((f) => {
                if (f.type === "LinearField") {
                  return fieldWeight(pos[i][0], fieldPosition(f, time, duration, xs), f.falloff);
                }
                if (f.type === "SphericalField") {
                  const dists = spheres.get(f.id) ?? [];
                  const r = sphereRadius(f, isLegacySphere(f) ? time : absoluteTime, duration, dists);
                  return f.falloff <= 0 ? (dists[i] <= r ? 1 : 0) : clamp01((r - dists[i]) / f.falloff + 0.5);
                }
                return 0;
              }),
            );
          };
          const start = n.start ?? 0;
          const weight = (i: number, time: number) => time < start ? 0 : sines.reduce((w, s) => {
              if (s.type !== "SineWave") return w;
              return w * waveWeight(s, i, time);
            }, fieldAt(i, time - start, time));
          const rotationXYZ = effectorRotation(n);
          return { ...part, layers: [...part.layers, { scale: n.scale, rotation: rotationXYZ[2] * Math.PI / 180, rotationXYZ, position: n.position, weight }] };
        });
      }
      case "DelayEffector":
      case "Spring": {
        const src = stream(mainInput(n));
        if (!src) return null;
        const cloneCount = src.reduce((count, part) => count + part.positions.length, 0);
        let cloneOffset = 0;
        return src.map((part, partIdx) => {
          const offset = cloneOffset;
          cloneOffset += part.positions.length;
          let lastIndex = part.layers.length - 1;
          while (lastIndex >= 0 && part.layers[lastIndex].matrix) lastIndex--;
          if (lastIndex < 0) return part;
          const key = `${n.id}:${partIdx}`;
          let table = docCache.get(key);
          const last = part.layers[lastIndex];
          if (!table) {
          const k = n.type === "DelayEffector" ? 20 + n.tension * 180 : 40 + n.stiffness * 360;
          const c = n.type === "DelayEffector" ? 2 + n.friction * 28 : 1 + n.damping * 20;
          const dt = 1 / fps;
          // Simulate the whole clip once per doc and reuse it (cost no longer grows with t).
          const steps = Math.ceil(duration * fps);
          const count = part.positions.length;
          table = [new Array(count).fill(0)];
          const w = new Array(count).fill(0);
          const v = new Array(count).fill(0);
          for (let s = 1; s <= steps; s++) {
            for (let i = 0; i < count; i++) {
              const targetTime = n.type === "DelayEffector" ? delayTargetTime(n, offset + i, cloneCount, s * dt) : s * dt;
              const target = targetTime === null ? 0 : last.weight(i, targetTime);
              const a = k * (target - w[i]) - c * v[i];
              v[i] += a * dt;
              w[i] += v[i] * dt;
            }
            table.push([...w]);
          }
          docCache.set(key, table);
          }
          const tbl = table;
          const sprung = (i: number, time: number) => {
            const filtered = tbl[Math.min(tbl.length - 1, Math.max(0, Math.floor(time * fps)))][i];
            return n.type === "DelayEffector" ? delayBlend(n, last.weight(i, time), filtered) : filtered;
          };
          return { ...part, layers: part.layers.map((layer, i) => i === lastIndex ? { ...last, weight: sprung } : layer) };
        });
      }
      case "Mask": {
        const src = stream(mainInput(n));
        if (!src) return null;
        const clip: Clip = { id: n.id, axis: n.axis, value: maskPosition(n, t, duration), invert: n.invert };
        return src.map((part) => ({ ...part, clips: [...part.clips, clip] }));
      }
      case "Combiner": {
        const streams = n.inputs.map((i) => stream(i)).filter((x): x is Stream => !!x);
        if (!streams.length) return null;
        const k = streams.length;
        return streams.flatMap((st, idx) => {
          const dx = (idx - (k - 1) / 2) * n.offset;
          const matrix = mat4.translate(identityMatrix(), identityMatrix(), [dx, 0, 0]);
          return st.map((part) => part.bases || part.layers.some((layer) => layer.matrix)
            ? { ...part, layers: [...part.layers, { matrix, scale: [1, 1, 1], rotation: 0, weight: () => 0 }] }
            : { ...part, positions: part.positions.map((p) => [p[0] + dx, p[1], p[2]] as Vec3) });
        });
      }
      default:
        return null;
    }
  };

  const preview = doc.nodes.find((n) => n.type === "Preview");
  const s = stream(preview?.inputs[0]);
  if (!s) return empty;

  return {
    clones: s.flatMap((part) =>
      part.positions.map((position, i) => {
        let scale: Vec3 = [1, 1, 1];
        let rotation = 0;
        let weight = 0;
        for (const l of part.layers) {
          if (l.matrix) continue;
          const w = l.weight(i, t);
          scale = scale.map((v, k) => v * (1 + (l.scale[k] - 1) * w)) as Vec3;
          rotation += l.rotation * w;
          weight = Math.max(weight, w);
        }
        const staticMatrix = part.bases || part.layers.some((layer) => layer.matrix);
        const tilted = part.layers.some((layer) => layer.rotationXYZ?.[0] || layer.rotationXYZ?.[1]);
        if (staticMatrix || tilted || part.layers.some((layer) => layer.position?.some((v) => v !== 0))) {
          const matrix = partMatrix(part, i, t);
          scale = [Math.hypot(matrix[0], matrix[1], matrix[2]), Math.hypot(matrix[4], matrix[5], matrix[6]), Math.hypot(matrix[8], matrix[9], matrix[10])];
          if (mat4.determinant(matrix) < 0) scale[1] = -scale[1];
          // Planar effector-only output retains authored multi-turn angles for AE keys.
          if (staticMatrix || tilted) rotation = Math.atan2(matrix[1], matrix[0]);
          return { position: matrixPosition(matrix), scale, rotation, matrix: matrixValues(matrix), weight, shape: part.shape, text: part.text, size: part.size, clips: part.clips };
        }
        return { position, scale, rotation, weight, shape: part.shape, text: part.text, size: part.size, clips: part.clips };
      }),
    ),
  };
}
