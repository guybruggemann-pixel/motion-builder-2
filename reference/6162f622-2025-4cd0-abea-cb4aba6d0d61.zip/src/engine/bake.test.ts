import { describe, expect, it } from "vitest";
import { bake, cachedCount, getFrame, totalFrames } from "./bake";
import { evaluate } from "./evaluate";
import { defaultDoc } from "./schema";

describe("frame cache", () => {
  it("caches one frame per frame of the clip", async () => {
    const doc = structuredClone(defaultDoc);
    await new Promise<void>((r) => bake(doc, (d, t) => d === t && r()));
    expect(cachedCount(doc)).toBe(totalFrames(doc));
  });
  it("cached frames equal freshly evaluated ones", () => {
    const doc = structuredClone(defaultDoc);
    expect(getFrame(doc, 2)).toEqual(evaluate(structuredClone(defaultDoc), 2));
  });
});
