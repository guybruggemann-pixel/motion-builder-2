// Unified, serializable scene document. Every node, connection and setting lives here.
export type Vec3 = [number, number, number];

export type NodeCategory = "generator" | "cloner" | "effector" | "field" | "math";

interface Base {
  id: string;
  /** Seconds into the scene before this node kicks in; its own clock starts here. */
  start?: number;
  inputs: string[];
  ui: { x: number; y: number };
  /** Optional keyframes per top-level numeric param (scene seconds). Missing = static. */
  anim?: Record<string, { t: number; v: number; ease?: "linear" | "smooth" | "hold" | "bezier"; bezier?: [number, number, number, number] }[]>;
}

export interface TextNode extends Base { type: "TextNode"; text: string; split: "none" | "lines" }
export interface BoxPrimitive extends Base { type: "BoxPrimitive"; size: number }
export interface GridCloner extends Base { type: "GridCloner"; count: [number, number, number?]; spacing: number; depthSpacing?: number }
export interface RadialCloner extends Base { type: "RadialCloner"; count: number; radius: number; plane?: "XY" | "XZ" | "YZ" }
/** Per-clone local offsets; rotationXYZ (degrees) supersedes legacy Z rotation (radians). */
export interface PlainEffector extends Base { type: "PlainEffector"; scale: Vec3; uniformScale?: boolean; rotation: number; position?: Vec3; rotationXYZ?: Vec3 }
/** Static whole-stream transform around the scene origin; rotations are degrees. */
export interface TransformNode extends Base { type: "Transform"; position: Vec3; rotation: Vec3; scale: Vec3; uniformScale?: boolean }
/** Stagger is seconds per clone in incoming stream order; reverse changes stagger direction only. */
export interface DelayEffector extends Base { type: "DelayEffector"; tension: number; friction: number; stagger?: number; reverse?: boolean; strength?: number }
export type MotionCurve = "linear" | "ease-in" | "ease-out" | "ease-in-out" | "custom";
export type BezierPoints = [number, number, number, number];
export interface LinearField extends Base {
  type: "LinearField";
  falloff: number;
  /** Legacy looping sweep only; omitted by new fields. */
  speed?: number;
  from?: number;
  to?: number;
  /** Absolute scene time; omitted means the scene's end. */
  end?: number;
  curve?: MotionCurve;
  bezier?: BezierPoints;
}
export interface SphericalField extends Base {
  type: "SphericalField"; falloff: number;
  /** Legacy looping growth only. */
  speed?: number;
  center?: Vec3;
  radiusFrom?: number;
  radiusTo?: number;
  end?: number;
  curve?: MotionCurve;
  bezier?: BezierPoints;
}
export type Waveform = "sine" | "triangle" | "square" | "sawtooth";
/** Global phase is degrees; the existing per-clone offset remains radians. */
export interface SineWave extends Base { type: "SineWave"; frequency: number; offset: number; waveform?: Waveform; phase?: number; strength?: number }
export interface Spring extends Base { type: "Spring"; stiffness: number; damping: number }
/** Merges several node trees into one stream; inputs are spread along X by `offset`. */
export interface Combiner extends Base { type: "Combiner"; offset: number }
/** Clipping plane that hides everything past a line; the line sweeps from `from` to `to` over the clip (reveal/wipe). */
export interface MaskNode extends Base { type: "Mask"; axis: "x" | "y" | "z"; from: number; to: number; invert: boolean; end?: number; curve?: MotionCurve; bezier?: BezierPoints }
export interface PreviewNode extends Base { type: "Preview" }

export type SceneNode =
  | TextNode | BoxPrimitive | GridCloner | RadialCloner | PlainEffector | DelayEffector
  | LinearField | SphericalField | SineWave | Spring | Combiner | MaskNode | TransformNode | PreviewNode;
export type NodeType = SceneNode["type"];

export interface Cluster { id: string; name: string; x: number; y: number; w: number; h: number }

/** Static render cameras; inspection controls never edit these values. */
export interface SceneCamera {
  id: string;
  name: string;
  projection: "orthographic" | "perspective";
  position: Vec3;
  target: Vec3;
  fov: number;
  viewHeight: number;
  zoom: number;
}

export interface SceneDoc {
  meta: { mode: "ae-strict" | "web-native"; fps: number; duration: number; width?: number; height?: number };
  nodes: SceneNode[];
  clusters: Cluster[];
  cameras?: SceneCamera[];
  /** Omitted means legacy automatic front framing. */
  activeCameraId?: string;
}

export const CATEGORY: Record<NodeType, NodeCategory> = {
  TextNode: "generator",
  BoxPrimitive: "generator",
  GridCloner: "cloner",
  RadialCloner: "cloner",
  PlainEffector: "effector",
  Transform: "effector",
  DelayEffector: "effector",
  LinearField: "field",
  SphericalField: "field",
  SineWave: "math",
  Spring: "math",
  Combiner: "cloner",
  Mask: "effector",
  Preview: "math",
};

/** How many incoming wires a node accepts. 1 = a new wire replaces the old one. */
export const MAX_INPUTS: Record<NodeType, number> = {
  TextNode: 0,
  BoxPrimitive: 0,
  LinearField: 0,
  SphericalField: 0,
  SineWave: 0,
  GridCloner: 1,
  RadialCloner: 1,
  DelayEffector: 1,
  Spring: 1,
  Transform: 1,
  Preview: 1,
  Combiner: Infinity, // any number of trees
  Mask: 1,
  PlainEffector: Infinity, // one clone stream + any number of fields / math
};

/** Default parameters for a freshly created node of each type. */
export function createNode(type: NodeType, id: string, ui: { x: number; y: number }): SceneNode {
  const base = { id, inputs: [], ui };
  switch (type) {
    case "TextNode": return { ...base, type, text: "NODAL", split: "none" };
    case "BoxPrimitive": return { ...base, type, size: 0.8 };
    case "GridCloner": return { ...base, type, count: [5, 3], spacing: 1.6 };
    case "RadialCloner": return { ...base, type, count: 12, radius: 3 };
    case "PlainEffector": return { ...base, type, scale: [1, 2, 1], rotation: 0 };
    case "Transform": return { ...base, type, position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] };
    case "DelayEffector": return { ...base, type, tension: 0.5, friction: 0.3, stagger: 0, reverse: false, strength: 1 };
    case "LinearField": return { ...base, type, falloff: 3, from: -7, to: 7, curve: "linear" };
    case "SphericalField": return { ...base, type, falloff: 2, center: [0, 0, 0], radiusFrom: 0, radiusTo: 8, curve: "linear" };
    case "SineWave": return { ...base, type, frequency: 1, offset: 0.3, waveform: "sine", phase: 0, strength: 1 };
    case "Spring": return { ...base, type, stiffness: 0.6, damping: 0.15 };
    case "Combiner": return { ...base, type, offset: 0 };
    case "Mask": return { ...base, type, axis: "x", from: -6, to: 6, invert: false, curve: "linear" };
    case "Preview": return { ...base, type };
  }
}

export const ID_PREFIX: Record<NodeType, string> = {
  TextNode: "txt",
  BoxPrimitive: "box",
  GridCloner: "cln",
  RadialCloner: "rad",
  PlainEffector: "eff",
  Transform: "trf",
  DelayEffector: "dly",
  LinearField: "fld",
  SphericalField: "sph",
  SineWave: "sin",
  Spring: "spr",
  Combiner: "cmb",
  Mask: "msk",
  Preview: "out",
};

export const defaultDoc: SceneDoc = {
  meta: { mode: "ae-strict", fps: 30, duration: 4, width: 1920, height: 1080 },
  nodes: [
    { id: "txt_1", type: "TextNode", text: "CHALO", split: "none", inputs: [], ui: { x: 0, y: 40 } },
    { id: "cln_1", type: "GridCloner", count: [6, 4], spacing: 1.6, inputs: ["txt_1"], ui: { x: 280, y: 40 } },
    { id: "fld_1", type: "LinearField", falloff: 3, from: -7, to: 7, curve: "linear", inputs: [], ui: { x: 280, y: 260 } },
    { id: "eff_1", type: "PlainEffector", scale: [1, 3, 1], rotation: 0, inputs: ["cln_1", "fld_1"], ui: { x: 600, y: 40 } },
    { id: "dly_1", type: "DelayEffector", tension: 0.5, friction: 0.3, inputs: ["eff_1"], ui: { x: 880, y: 40 } },
    { id: "out_1", type: "Preview", inputs: ["dly_1"], ui: { x: 0, y: 0 } },
  ],
  clusters: [{ id: "grp_1", name: "Text grid", x: -24, y: -16, w: 552, h: 200 }],
};

/** Output frame size in pixels (older docs without a size default to 1920x1080). Encoders need even sizes. */
export function frameSize(meta: SceneDoc["meta"]) {
  const even = (v: number) => Math.max(16, Math.min(4096, Math.round(v / 2) * 2));
  return { width: even(meta.width ?? 1920), height: even(meta.height ?? 1080) };
}

export const FORMATS = [
  { label: "16:9", width: 1920, height: 1080 },
  { label: "9:16", width: 1080, height: 1920 },
  { label: "1:1", width: 1080, height: 1080 },
  { label: "4:5", width: 1080, height: 1350 },
] as const;

/** Node types whose effect can be delayed with a Start time (Animate phase timing). */
export const TIMED: NodeType[] = ["PlainEffector", "LinearField", "SphericalField", "SineWave", "Mask"];
