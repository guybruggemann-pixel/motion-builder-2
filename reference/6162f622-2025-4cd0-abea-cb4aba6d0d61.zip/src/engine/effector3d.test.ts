import { describe, expect, it } from "vitest";
import { evaluate } from "./evaluate";
import { defaultDoc, type PlainEffector, type SceneDoc, type SceneNode, type Vec3 } from "./schema";
import { effectorRotation, matrixValues, transformMatrix } from "./transforms";
import { getFrame } from "./bake";
import { useScene } from "./store";
import { aeScript } from "./aeExport";

const ui = { x: 0, y: 0 };
const eff = (patch: Partial<PlainEffector> = {}): PlainEffector => ({ id: "e", type: "PlainEffector", ui, inputs: ["b"], scale: [1, 1, 1], rotation: 0, ...patch });
const scene = (nodes: SceneNode[]): SceneDoc => ({ ...defaultDoc, cameras: [], activeCameraId: undefined, clusters: [], nodes: [
  { id: "b", type: "BoxPrimitive", inputs: [], ui, size: 0.8 }, ...nodes,
  { id: "out", type: "Preview", ui, inputs: [nodes.at(-1)?.id ?? "b"] },
] });
const close = (actual: number[], expected: number[]) => expected.forEach((v, i) => expect(actual[i]).toBeCloseTo(v, 5));
const sine: SceneNode = { id: "s", type: "SineWave", inputs: [], ui, frequency: 1, offset: 0 };

describe("3D Plain Effector", () => {
  it("preserves legacy flat output and explicit zero vectors", () => {
    const legacy = eff({ scale: [2, 3, 1], rotation: 0.7 });
    expect(evaluate(scene([legacy]), 1)).toEqual(evaluate(scene([{ ...legacy, position: [0, 0, 0], rotationXYZ: [0, 0, 0.7 * 180 / Math.PI] }]), 1));
    expect(evaluate(scene([legacy]), 1).clones[0].matrix).toBeUndefined();
    close(effectorRotation(legacy), [0, 0, 0.7 * 180 / Math.PI]);
  });
  it.each([{ time: 0.75, weight: 0 }, { time: 0, weight: 0.5 }, { time: 0.25, weight: 1 }])("weights all XYZ offsets at influence $weight", ({ time, weight }) => {
    const clone = evaluate(scene([sine, eff({ inputs: ["b", "s"], position: [2, -4, 6], rotationXYZ: [60, 30, 90], scale: [2, 3, 4] })]), time).clones[0];
    close(clone.position, [2 * weight, -4 * weight, 6 * weight]);
    expect(clone.matrix).toBeDefined();
    close(clone.matrix ?? [], matrixValues(transformMatrix({ position: [2 * weight, -4 * weight, 6 * weight], rotation: [60 * weight, 30 * weight, 90 * weight], scale: [1 + weight, 1 + 2 * weight, 1 + 3 * weight] })));
  });
  it.each([[90, 0, 0], [0, 90, 0], [0, 0, 90]] as Vec3[])("uses the shared degree convention for %j", (...rotation) => {
    const r = rotation as Vec3;
    const clone = evaluate(scene([eff({ rotationXYZ: r })]), 1).clones[0];
    if (r[2]) expect(clone.rotation).toBeCloseTo(Math.PI / 2);
    else close(clone.matrix ?? [], matrixValues(transformMatrix({ position: [0, 0, 0], rotation: r, scale: [1, 1, 1] })));
  });
  it("degree rotation supersedes rather than doubles legacy radians", () => {
    expect(evaluate(scene([eff({ rotation: Math.PI / 2, rotationXYZ: [0, 0, 45] })]), 0).clones[0].rotation).toBeCloseTo(Math.PI / 4);
  });
  it("keeps planar multi-turn effector angles unwrapped with position offsets", () => {
    const clone = evaluate(scene([eff({ position: [2, 0, 0], rotationXYZ: [0, 0, 720] })]), 0).clones[0];
    expect(clone.rotation).toBeCloseTo(4 * Math.PI);
    close(clone.position, [2, 0, 0]);
  });
  it("gates every offset before the node start", () => {
    const doc = scene([eff({ start: 1, position: [2, 3, 4], rotationXYZ: [30, 60, 90] })]);
    const early = evaluate(doc, 0.5).clones[0];
    close(early.position, [0, 0, 0]);
    close(early.matrix ?? [], matrixValues(transformMatrix({ position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] })));
    close(evaluate(doc, 1).clones[0].position, [2, 3, 4]);
  });
  it("keeps fields sampling static anchors rather than preceding animated offsets", () => {
    const field: SceneNode = { id: "f", type: "LinearField", inputs: [], ui, from: 0, to: 0, falloff: 0 };
    const clone = evaluate(scene([field, eff({ position: [10, 0, 0] }), eff({ id: "e2", inputs: ["e", "f"], position: [0, 2, 0] })]), 0).clones[0];
    close(clone.position, [10, 2, 0]);
  });
  it("composes local offsets with rotated and scaled static transforms", () => {
    const tr: SceneNode = { id: "tr", type: "Transform", ui, inputs: ["b"], position: [3, 0, 0], rotation: [0, 0, 90], scale: [2, 2, 2] };
    close(evaluate(scene([tr, eff({ inputs: ["tr"], position: [1, 0, 2] })]), 0).clones[0].position, [3, 2, 4]);
    close(evaluate(scene([eff({ position: [1, 0, 2] }), { ...tr, inputs: ["e"] }]), 0).clones[0].position, [3, 2, 4]);
  });
  it.each(["GridCloner", "RadialCloner"] as const)("resets animated offsets through %s while preserving static transforms", (type) => {
    const cloner: SceneNode = type === "GridCloner" ? { id: "c", type, ui, inputs: ["e"], count: [1, 1], spacing: 2 } : { id: "c", type, ui, inputs: ["e"], count: 1, radius: 2 };
    const tr: SceneNode = { id: "tr", type: "Transform", ui, inputs: ["b"], position: [3, 0, 5], rotation: [0, 0, 90], scale: [1, 1, 1] };
    const clone = evaluate(scene([tr, eff({ inputs: ["tr"], position: [10, 0, 0], rotationXYZ: [45, 0, 0] }), cloner]), 1).clones[0];
    close(clone.position, type === "GridCloner" ? [3, 0, 5] : [5, 0, 5]);
    expect(clone.rotation).toBeCloseTo(Math.PI / 2);
  });
  it.each(["Spring", "DelayEffector"] as const)("shares the filtered weight across offsets and scale through %s", (type) => {
    const filter: SceneNode = type === "Spring" ? { id: "filter", type, ui, inputs: ["e"], stiffness: 0.3, damping: 0.1 } : { id: "filter", type, ui, inputs: ["e"], tension: 0.3, friction: 0.1 };
    const doc = scene([eff({ position: [2, 3, 4], scale: [2, 2, 2], rotationXYZ: [30, 0, 0] }), filter]);
    const clone = evaluate(doc, 0.3).clones[0];
    expect(clone.weight).toBeGreaterThan(1);
    close(clone.position, [2 * clone.weight, 3 * clone.weight, 4 * clone.weight]);
    close(clone.scale, [1 + clone.weight, 1 + clone.weight, 1 + clone.weight]);
    expect(getFrame(doc, 0.3)).toEqual(evaluate(doc, 0.3));
    expect(evaluate({ ...doc }, 0.3)).toEqual(evaluate(doc, 0.3));
  });
  it("vector edits are immutable, undoable and invalidate cached frames", () => {
    useScene.setState({ doc: scene([eff()]), past: [], future: [] });
    const initial = useScene.getState().doc;
    const frame = getFrame(initial, 0);
    useScene.getState().updateNode("e", { position: [0, 0, 4], rotationXYZ: [20, 0, 0] });
    const edited = useScene.getState().doc;
    expect(getFrame(edited, 0)).not.toEqual(frame);
    useScene.getState().undo();
    expect(useScene.getState().doc).toBe(initial);
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(edited);
  });
  it("accepts planar AE output and rejects depth or tilt", () => {
    const colors = { idle: [1, 1, 1] as Vec3, live: [1, 1, 1] as Vec3, bg: [0, 0, 0] as Vec3 };
    expect(() => aeScript(scene([eff({ position: [2, 3, 0], rotationXYZ: [0, 0, 45] })]), colors)).not.toThrow();
    expect(() => aeScript(scene([eff({ position: [0, 0, 3] })]), colors)).toThrow("Use Render for depth");
    expect(() => aeScript(scene([eff({ rotationXYZ: [30, 0, 0] })]), colors)).toThrow("Use Render for depth");
  });
});