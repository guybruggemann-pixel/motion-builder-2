import { evaluate, type Frame } from "./evaluate";
import type { SceneDoc } from "./schema";

/** Finished frames per doc. Docs are immutable, so any edit starts a fresh, empty cache. */
const cache = new WeakMap<SceneDoc, (Frame | undefined)[]>();

export const totalFrames = (doc: SceneDoc) => Math.round(doc.meta.duration * doc.meta.fps) + 1;
const slot = (doc: SceneDoc) => {
  let c = cache.get(doc);
  if (!c) cache.set(doc, (c = new Array(totalFrames(doc))));
  return c;
};

/** Frame at time t, snapped to the doc's frame grid; computed once, then reused. */
export function getFrame(doc: SceneDoc, t: number): Frame {
  const c = slot(doc);
  const f = Math.min(c.length - 1, Math.max(0, Math.round(t * doc.meta.fps)));
  return (c[f] ??= evaluate(doc, f / doc.meta.fps));
}

export function cachedCount(doc: SceneDoc) {
  return slot(doc).reduce((n, f) => n + (f ? 1 : 0), 0);
}

/** Fill every frame in small chunks so the UI stays responsive. Returns a cancel function. */
export function bake(doc: SceneDoc, onProgress: (done: number, total: number) => void): () => void {
  const c = slot(doc);
  let i = 0;
  let stop = false;
  const step = () => {
    if (stop) return;
    const until = performance.now() + 12;
    while (i < c.length && performance.now() < until) {
      c[i] ??= evaluate(doc, i / doc.meta.fps);
      i++;
    }
    onProgress(cachedCount(doc), c.length);
    if (i < c.length) setTimeout(step, 0);
  };
  step();
  return () => { stop = true; };
}
