import { mat4, quat } from "gl-matrix";
import type { PlainEffector, TransformNode, Vec3 } from "./schema";

export function effectorRotation(node: Pick<PlainEffector, "rotation" | "rotationXYZ">): Vec3 {
  return node.rotationXYZ ?? [0, 0, node.rotation * 180 / Math.PI];
}

/** Column-major, float64 matrices keep scene math deterministic without renderer imports. */
export const identityMatrix = () => mat4.identity(new Float64Array(16));
export function transformMatrix(node: Pick<TransformNode, "position" | "rotation" | "scale">) {
  const q = quat.create();
  quat.fromEuler(q, ...node.rotation);
  return mat4.fromRotationTranslationScale(identityMatrix(), q, node.position, node.scale);
}
export function matrixValues(matrix: mat4): number[] { return Array.from(matrix); }
export function matrixPosition(matrix: mat4): Vec3 { return [matrix[12], matrix[13], matrix[14]]; }

/** AE's existing 2D path cannot faithfully represent depth, tilted planes or shear. */
export function isPlanarMatrix(m: number[]): boolean {
  const epsilon = 1e-6;
  const sx = Math.hypot(m[0], m[1]);
  const sy = Math.hypot(m[4], m[5]);
  return [m[2], m[6], m[8], m[9], m[14]].every((v) => Math.abs(v) < epsilon)
    && Math.abs(m[0] * m[4] + m[1] * m[5]) < epsilon * Math.max(1, sx * sy);
}