import { fitZoom } from "./framing";
import type { SceneCamera, SceneDoc, Vec3 } from "./schema";

export function activeCamera(doc: SceneDoc): SceneCamera | undefined {
  return doc.cameras?.find((camera) => camera.id === doc.activeCameraId);
}

export function cameraError(camera: SceneCamera): string | null {
  if (!camera.name.trim()) return "Give the camera a name.";
  if (![...camera.position, ...camera.target, camera.fov, camera.viewHeight, camera.zoom].every(Number.isFinite)) return "Camera values must be finite numbers.";
  if (Math.hypot(...camera.position.map((value, i) => value - camera.target[i])) < 0.001) return "Position and target must be different.";
  if (camera.fov < 1 || camera.fov > 179) return "Field of view must be between 1° and 179°.";
  if (camera.zoom < 0.01 || camera.zoom > 100) return "Zoom must be between 0.01 and 100.";
  if (camera.viewHeight <= 0) return "View height must be positive.";
  if (camera.projection !== "orthographic" && camera.projection !== "perspective") return "Choose a valid projection.";
  return null;
}

/** Identical world-space projection for any preview or export resolution at the same aspect. */
export function cameraView(camera: SceneCamera | undefined, width: number, height: number, extent: number) {
  const aspect = width / height;
  const viewHeight = camera ? camera.viewHeight / camera.zoom : height / fitZoom(width, height, extent);
  const position: Vec3 = camera ? [...camera.position] : [0, 0, 10];
  const target: Vec3 = camera ? [...camera.target] : [0, 0, 0];
  // Avoid lookAt singularity when a camera looks straight down the Y axis.
  const dx = position[0] - target[0], dz = position[2] - target[2];
  const up: Vec3 = Math.hypot(dx, dz) < 0.001 ? [0, 0, 1] : [0, 1, 0];
  return { projection: camera?.projection ?? "orthographic", position, target, up, aspect,
    fov: camera?.fov ?? 45, zoom: camera?.projection === "perspective" ? camera.zoom : 1,
    left: -viewHeight * aspect / 2, right: viewHeight * aspect / 2, top: viewHeight / 2, bottom: -viewHeight / 2,
    near: 0.01, far: Math.max(1000, Math.hypot(...position) + Math.hypot(...target) + 1000) };
}

export function newCamera(id: string, viewHeight: number): SceneCamera {
  return { id, name: `Camera ${id.replace("cam_", "")}`, projection: "orthographic", position: [0, 0, 30], target: [0, 0, 0], fov: 45, viewHeight, zoom: 1 };
}