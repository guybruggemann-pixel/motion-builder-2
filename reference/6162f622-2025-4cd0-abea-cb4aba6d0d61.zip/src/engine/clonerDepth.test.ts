import { describe, expect, it } from "vitest";
import { evaluate, gridPositions, radialPositions } from "./evaluate";
import { defaultDoc, type SceneDoc, type SceneNode, type GridCloner, type RadialCloner } from "./schema";
import { useScene } from "./store";
import { aeScript } from "./aeExport";
import { getFrame } from "./bake";

const ui = { x: 0, y: 0 };
const grid: GridCloner = { id: "g", type: "GridCloner", inputs: ["b"], ui, count: [2, 2, 3], spacing: 2, depthSpacing: 4 };
const ring: RadialCloner = { id: "r", type: "RadialCloner", inputs: ["g"], ui, count: 4, radius: 2, plane: "XZ" };
const scene = (nodes: SceneNode[]): SceneDoc => ({ ...defaultDoc, cameras: [], activeCameraId: undefined, clusters: [], nodes: [
  { id: "b", type: "BoxPrimitive", inputs: [], ui, size: 0.8 }, ...nodes,
  { id: "out", type: "Preview", inputs: [nodes.at(-1)?.id ?? "b"], ui },
] });

describe("3D cloners", () => {
  it("keeps legacy grids flat with the same ordered positions", () => {
    expect(gridPositions([2, 2], 2)).toEqual([[-1, 1, 0], [1, 1, 0], [-1, -1, 0], [1, -1, 0]]);
    expect(gridPositions([2, 2, 1], 2, 4)).toEqual(gridPositions([2, 2], 2));
  });
  it("centers depth layers with independent spacing", () => {
    const positions = evaluate(scene([grid]), 0).clones.map((c) => c.position);
    expect(positions).toHaveLength(12);
    expect(positions[0]).toEqual([-1, 1, -4]);
    expect(positions[4]).toEqual([-1, 1, 0]);
    expect(positions[11]).toEqual([1, -1, 4]);
  });
  it("defaults untouched depth spacing to XY spacing", () => {
    expect(gridPositions([1, 1, 3], 2)).toEqual([[0, 0, -2], [0, 0, 0], [0, 0, 2]]);
  });
  it.each(["XY", "XZ", "YZ"] as const)("places rings on %s without changing geometry orientation", (plane) => {
    const expected = plane === "XY" ? [[2, 0, 0], [0, 2, 0], [-2, 0, 0], [0, -2, 0]]
      : plane === "XZ" ? [[2, 0, 0], [0, 0, 2], [-2, 0, 0], [0, 0, -2]]
      : [[0, 2, 0], [0, 0, 2], [0, -2, 0], [0, 0, -2]];
    const clones = evaluate(scene([{ ...ring, inputs: ["b"], plane }]), 0).clones;
    clones.forEach((clone, i) => {
      clone.position.forEach((v, axis) => expect(v).toBeCloseTo(expected[i][axis], 8));
      expect(clone.rotation).toBe(0);
    });
    if (plane === "XY") expect(radialPositions(4, 2)).toEqual(radialPositions(4, 2, plane));
  });
  it("nests rings at every depth-grid point deterministically", () => {
    const doc = scene([grid, ring]);
    const frame = evaluate(doc, 1);
    expect(frame.clones).toHaveLength(48);
    expect(frame.clones[0].position).toEqual([1, 1, -4]);
    expect(frame).toEqual(evaluate(doc, 1));
    expect(getFrame(doc, 1)).toEqual(frame);
  });
  it("preserves source transforms on the matrix-bearing cloner path", () => {
    const doc = scene([{ id: "tr", type: "Transform", inputs: ["b"], ui, position: [3, 0, 5], rotation: [0, 0, 90], scale: [1, 1, 1] }, { ...grid, inputs: ["tr"] }]);
    const clones = evaluate(doc, 0).clones;
    expect(clones[0].position).toEqual([2, 1, 1]);
    expect(clones[11].position).toEqual([4, -1, 9]);
    expect(clones[0].rotation).toBeCloseTo(Math.PI / 2);
  });
  it("undoes and redoes depth and plane edits, with fresh cached frames", () => {
    useScene.setState({ doc: scene([{ ...grid, count: [2, 2] }, { ...ring, plane: "XY" }]), past: [], future: [] });
    const initial = useScene.getState().doc;
    expect(getFrame(initial, 0).clones).toHaveLength(16);
    useScene.getState().updateNode("g", { count: [2, 2, 3] });
    useScene.getState().updateNode("r", { plane: "YZ" });
    const edited = useScene.getState().doc;
    expect(getFrame(edited, 0).clones).toHaveLength(48);
    useScene.getState().undo();
    useScene.getState().undo();
    expect(useScene.getState().doc).toBe(initial);
    useScene.getState().redo();
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(edited);
  });
  it("rejects raw clone depth in flat AE export while retaining planar export", () => {
    const colors = { idle: [1, 1, 1] as [number, number, number], live: [1, 1, 1] as [number, number, number], bg: [0, 0, 0] as [number, number, number] };
    expect(() => aeScript(scene([grid]), colors)).toThrow("Use Render for depth");
    expect(() => aeScript(scene([{ ...ring, inputs: ["b"] }]), colors)).toThrow("Use Render for depth");
    expect(() => aeScript(scene([{ ...grid, count: [2, 2] }]), colors)).not.toThrow();
  });
});