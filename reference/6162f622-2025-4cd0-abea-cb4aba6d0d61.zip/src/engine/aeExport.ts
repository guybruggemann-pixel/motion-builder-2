import { totalFrames, getFrame } from "./bake";
import { FONT_SIZE, extentOf, fitZoom } from "./framing";
import { frameSize, type SceneDoc } from "./schema";
import { isPlanarMatrix } from "./transforms";
import { activeCamera } from "./cameras";

export type RGB = [number, number, number];

const r3 = (v: number) => Math.round(v * 1000) / 1000;
const r1 = (v: number) => Math.round(v * 10) / 10;
const str = (s: string) => JSON.stringify(s);

/**
 * Bakes the doc into an After Effects ExtendScript (.jsx): one comp at the doc's size/fps/length,
 * one layer per clone, and a keyframe on every frame for position, scale, rotation, opacity and color.
 * Framing matches the preview/render (same extent and zoom per frame). Masks are not exported yet.
 */
export function aeScript(doc: SceneDoc, colors: { idle: RGB; live: RGB; bg: RGB }, name = "Nodal"): string {
  if (activeCamera(doc)) throw new Error("AE export currently supports Auto framing only. Use Render for custom cameras, or select Auto before exporting to AE.");
  const { width, height } = frameSize(doc.meta);
  const fps = doc.meta.fps;
  const count = totalFrames(doc) - 1;
  const frames = Array.from({ length: count }, (_, i) => getFrame(doc, i / fps));
  if (frames.some((frame) => frame.clones.some((clone) => Math.abs(clone.position[2]) > 1e-6 || (clone.matrix && !isPlanarMatrix(clone.matrix))))) {
    throw new Error("AE export supports flat transforms only. Use Render for depth, X/Y rotation or sheared transforms.");
  }
  const zooms = frames.map((f) => fitZoom(width, height, extentOf(f.clones)));
  const z0 = zooms[0] || 1;
  const layers = Math.max(0, ...frames.map((f) => f.clones.length));
  const times = frames.map((_, i) => r3(i / fps));

  const out: string[] = [];
  out.push(
    "// Nodal → After Effects. File > Scripts > Run Script File…",
    "(function () {",
    "app.beginUndoGroup(" + str(name) + ");",
    `var comp = app.project.items.addComp(${str(name)}, ${width}, ${height}, 1, ${r3(count / fps)}, ${fps});`,
    `comp.bgColor = [${colors.bg.map(r3)}];`,
    `var T = [${times}];`,
    "function keys(p, v) { p.setValuesAtTimes(T, v); }",
  );

  for (let l = 0; l < layers; l++) {
    const first = frames.find((f) => f.clones[l])?.clones[l];
    if (!first) continue;
    const pos: string[] = [];
    const scale: string[] = [];
    const rot: string[] = [];
    const op: string[] = [];
    const col: string[] = [];
    frames.forEach((f, i) => {
      const c = f.clones[l];
      const z = zooms[i];
      if (!c) {
        pos.push(`[${width / 2},${height / 2}]`); scale.push("[100,100]"); rot.push("0"); op.push("0"); col.push(`[${colors.idle}]`);
        return;
      }
      pos.push(`[${r1(width / 2 + c.position[0] * z)},${r1(height / 2 - c.position[1] * z)}]`);
      const k = (z / z0) * 100;
      scale.push(`[${r1(c.scale[0] * k)},${r1(c.scale[1] * k)}]`);
      rot.push(String(r1((-c.rotation * 180) / Math.PI)));
      op.push("100");
      col.push(`[${(c.weight > 0.5 ? colors.live : colors.idle).map(r3)}]`);
    });

    if (first.shape === "text") {
      out.push(
        `var L = comp.layers.addText(${str(first.text)});`,
        "var d = L.property('Source Text').value;",
        `d.fontSize = ${r1(FONT_SIZE * z0)}; d.font = 'InterTight-SemiBold'; d.justification = ParagraphJustification.CENTER_JUSTIFY; d.applyFill = true; d.fillColor = [${colors.idle.map(r3)}];`,
        "L.property('Source Text').setValue(d);",
        // Center the anchor on the text box so position/scale behave like the preview.
        "var b = L.sourceRectAtTime(0, false); L.property('Anchor Point').setValue([b.left + b.width / 2, b.top + b.height / 2]);",
        "var fill = L.property('Effects').addProperty('ADBE Fill'); var C = fill.property('Color');",
      );
    } else {
      const s = r1(first.size * z0);
      out.push(
        "var L = comp.layers.addShape();",
        "var g = L.property('Contents').addProperty('ADBE Vector Group');",
        `g.property('Contents').addProperty('ADBE Vector Shape - Rect').property('Size').setValue([${s},${s}]);`,
        "var st = g.property('Contents').addProperty('ADBE Vector Graphic - Stroke'); st.property('Stroke Width').setValue(2);",
        "var C = st.property('Color');",
      );
    }
    out.push(
      `L.name = ${str(`${first.shape === "text" ? first.text : "Box"} ${l + 1}`)};`,
      "var X = L.property('Transform');",
      `keys(X.property('Position'), [${pos}]);`,
      `keys(X.property('Scale'), [${scale}]);`,
      `keys(X.property('Rotation'), [${rot}]);`,
      `keys(X.property('Opacity'), [${op}]);`,
      `keys(C, [${col}]);`,
    );
  }

  out.push("comp.openInViewer();", "app.endUndoGroup();", "})();");
  return out.join("\n");
}
