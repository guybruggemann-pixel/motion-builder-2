import type { PlainEffector, TransformNode, Vec3 } from "./schema";

export type ScaleNode = PlainEffector | TransformNode;

/** Linking is an edit, never an implicit reinterpretation of older scale vectors. */
export function setUniformScale(node: ScaleNode, uniformScale: boolean) {
  return { uniformScale, scale: uniformScale ? [node.scale[0], node.scale[0], node.scale[0]] as Vec3 : [...node.scale] as Vec3 };
}

export function editScale(node: ScaleNode, axis: number, value: number): { scale: Vec3 } {
  if (!Number.isFinite(value)) return { scale: [...node.scale] };
  const scale: Vec3 = [...node.scale];
  if (node.uniformScale) scale.fill(value);
  else if (axis >= 0 && axis < 3) scale[axis] = value;
  return { scale };
}