import { ArrayBufferTarget, Muxer } from "mp4-muxer";
import { frameSize, type SceneDoc } from "./schema";
import { totalFrames } from "./bake";
import { useTime } from "./time";
import { getCapture } from "./offscreen";


const nextPaint = () => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r())));

/**
 * Frame-stepped MP4 render: moves the playhead to every frame, waits for the preview to paint,
 * draws the scene off-screen at the doc's true frame size and encodes it (H.264 via WebCodecs).
 * Time comes from the frame index, never the wall clock, so slow frames never drop or drift.
 */
export async function renderMp4(doc: SceneDoc, _source: HTMLCanvasElement | null, onProgress: (p: number) => void): Promise<Blob> {
  if (typeof VideoEncoder === "undefined") throw new Error("This browser can't encode video. Try Chrome, Edge or Safari.");
  const { width, height } = frameSize(doc.meta);
  const fps = doc.meta.fps;
  // H.264 first (plays everywhere, incl. QuickTime/AE); VP9 in MP4 as fallback for browsers without H.264 encoding.
  const options = [
    { muxCodec: "avc" as const, codec: "avc1.640033" },
    { muxCodec: "vp9" as const, codec: "vp09.00.40.08" },
  ];
  let picked: (typeof options)[number] | null = null;
  let config: VideoEncoderConfig | null = null;
  for (const o of options) {
    const c: VideoEncoderConfig = { codec: o.codec, width, height, bitrate: 12_000_000, framerate: fps };
    if ((await VideoEncoder.isConfigSupported(c)).supported) { picked = o; config = c; break; }
  }
  if (!picked || !config) throw new Error("This browser can't encode video. Try Chrome, Edge or Safari.");

  const muxer = new Muxer({ target: new ArrayBufferTarget(), video: { codec: picked.muxCodec, width, height, frameRate: fps }, fastStart: "in-memory" });
  let failure: unknown = null;
  const encoder = new VideoEncoder({ output: (chunk, meta) => muxer.addVideoChunk(chunk, meta), error: (e) => (failure = e) });
  encoder.configure(config);

  const capture = getCapture();
  if (!capture) throw new Error("The preview isn't ready yet. Try again in a moment.");
  const { time: before, setTime } = useTime.getState();
  const count = totalFrames(doc) - 1; // last frame (t = duration) equals the loop start

  try {
    for (let i = 0; i < count; i++) {
      if (failure) throw failure;
      setTime(i / fps);
      await nextPaint();
      const pixels = capture.draw(width, height);
      const vf = new VideoFrame(pixels, { format: "RGBA", codedWidth: width, codedHeight: height, timestamp: Math.round((i * 1e6) / fps), duration: Math.round(1e6 / fps) });
      encoder.encode(vf, { keyFrame: i % (fps * 2) === 0 });
      vf.close();
      if (encoder.encodeQueueSize > 8) await new Promise((r) => setTimeout(r, 0));
      onProgress((i + 1) / count);
    }
    await encoder.flush();
    muxer.finalize();
    return new Blob([muxer.target.buffer], { type: "video/mp4" });
  } finally {
    if (encoder.state !== "closed") encoder.close();
    capture.dispose();
    setTime(before);
  }
}
