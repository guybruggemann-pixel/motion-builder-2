import type { SphericalField, Vec3 } from "./schema";
import { easeProgress, fieldInterval } from "./fieldMotion";

const finite = (value: number | undefined, fallback: number) => value !== undefined && Number.isFinite(value) ? value : fallback;
export function sphereCenter(field: SphericalField): Vec3 {
  return (field.center ?? [0, 0, 0]).map((v) => finite(v, 0)) as Vec3;
}
export function sphereDistance(position: Vec3, center: Vec3) {
  return Math.hypot(position[0] - center[0], position[1] - center[1], position[2] - center[2]);
}
export function isLegacySphere(field: SphericalField) {
  return field.speed !== undefined && field.center === undefined && field.radiusFrom === undefined && field.radiusTo === undefined && field.end === undefined && field.curve === undefined && field.bezier === undefined;
}
export function sphereRadius(field: SphericalField, time: number, duration: number, distances: number[]): number {
  const extent = (distances.length ? Math.max(...distances) : 0) + field.falloff;
  if (isLegacySphere(field)) {
    const local = Math.max(0, time - (field.start ?? 0));
    return extent * ((local * (field.speed ?? 1)) % duration) / duration;
  }
  const { start, end } = fieldInterval(field, duration);
  const progress = end > start ? (time - start) / (end - start) : time < start ? 0 : 1;
  const from = Math.max(0, finite(field.radiusFrom, 0));
  const to = Math.max(0, finite(field.radiusTo, 8));
  return from + (to - from) * easeProgress(progress, field.curve, field.bezier);
}
export function editableSphere(field: SphericalField, duration: number, positions: Vec3[]): SphericalField {
  const center = sphereCenter(field);
  const extent = (positions.length ? Math.max(...positions.map((p) => sphereDistance(p, center))) : 6) + field.falloff;
  return { ...field, speed: undefined, center, radiusFrom: Math.max(0, finite(field.radiusFrom, 0)),
    radiusTo: Math.max(0, finite(field.radiusTo, extent)), ...fieldInterval(field, duration), curve: field.curve ?? "linear" };
}