import { describe, expect, it } from "vitest";
import { removeKey, resolveNode, sampleKeys, setKey, neighbourKey } from "./keyframes";
import type { SceneNode } from "./schema";

describe("keyframes", () => {
  const keys = [{ t: 0, v: 0, ease: "linear" as const }, { t: 2, v: 10 }];
  it("interpolates linearly between keys", () => expect(sampleKeys(keys, 1)).toBe(5));
  it("clamps outside the keyed range", () => {
    expect(sampleKeys(keys, -1)).toBe(0);
    expect(sampleKeys(keys, 5)).toBe(10);
  });
  it("hold keeps the value until the next key", () => expect(sampleKeys([{ t: 0, v: 3, ease: "hold" }, { t: 1, v: 9 }], 0.99)).toBe(3));
  it("smooth eases in and out", () => expect(sampleKeys([{ t: 0, v: 0, ease: "smooth" }, { t: 1, v: 1 }], 0.25)).toBeCloseTo(0.15625));
  it("setKey replaces an existing key at the same time", () => {
    const k = setKey(setKey(undefined, 1, 2), 1, 7);
    expect(k).toHaveLength(1);
    expect(k[0].v).toBe(7);
  });
  it("removeKey and neighbourKey", () => {
    const k = setKey(setKey(undefined, 0, 1), 2, 3);
    expect(neighbourKey(k, 1, 1)?.t).toBe(2);
    expect(neighbourKey(k, 1, -1)?.t).toBe(0);
    expect(removeKey(k, 2)).toHaveLength(1);
  });
  it("resolves keyed vector axes", () => {
    const n = { id: "t", type: "Transform", position: [1, 2, 3], rotation: [0, 0, 0], scale: [1, 1, 1], inputs: [], ui: { x: 0, y: 0 }, anim: { "position.1": keys } } as SceneNode;
    expect((resolveNode(n, 1) as { position: number[] }).position).toEqual([1, 5, 3]);
  });
  it("leaves unkeyed nodes untouched", () => {
    const n = { id: "a", type: "Spring", stiffness: 1, damping: 2, inputs: [], ui: { x: 0, y: 0 } } as SceneNode;
    expect(resolveNode(n, 1)).toBe(n);
    const keyed = { ...n, anim: { stiffness: keys } } as SceneNode;
    expect((resolveNode(keyed, 1) as { stiffness: number }).stiffness).toBe(5);
  });
});
