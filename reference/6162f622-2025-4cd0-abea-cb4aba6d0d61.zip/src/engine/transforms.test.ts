import { describe, expect, it } from "vitest";
import { evaluate } from "./evaluate";
import { createNode, defaultDoc, type SceneDoc, type SceneNode, type TransformNode } from "./schema";
import { useScene } from "./store";
import { aeScript } from "./aeExport";

const ui = { x: 0, y: 0 };
const transform = (id: string, input: string, patch: Partial<TransformNode> = {}): TransformNode => ({
  id, inputs: [input], ui, type: "Transform", position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1], ...patch,
});
const text: SceneNode = { id: "t", inputs: [], ui, type: "TextNode", text: "A", split: "none" };
const doc = (nodes: SceneNode[]): SceneDoc => ({ ...defaultDoc, clusters: [], nodes: [text, ...nodes, { id: "out", type: "Preview", ui, inputs: [nodes.at(-1)?.id ?? "t"] }] });
const vectorClose = (actual: number[], expected: number[]) => expected.forEach((value, i) => expect(actual[i]).toBeCloseTo(value, 5));

describe("Transform node", () => {
  it("defaults to identity", () => {
    expect(createNode("Transform", "trf", ui)).toMatchObject({ position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] });
    const clone = evaluate(doc([transform("trf", "t")]), 0).clones[0];
    expect(clone.position).toEqual([0, 0, 0]);
    expect(clone.scale).toEqual([1, 1, 1]);
    expect(clone.matrix).toEqual([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  });
  it("offsets position on X, Y and Z", () => {
    expect(evaluate(doc([transform("trf", "t", { position: [2, -3, 4] })]), 0).clones[0].position).toEqual([2, -3, 4]);
  });
  it.each([
    { rotation: [90, 0, 0], position: [0, 1, 0], expected: [0, 0, 1] },
    { rotation: [0, 90, 0], position: [1, 0, 0], expected: [0, 0, -1] },
    { rotation: [0, 0, 90], position: [1, 0, 0], expected: [0, 1, 0] },
  ])("rotates the whole layout with $rotation degrees", ({ rotation, position, expected }) => {
    const clone = evaluate(doc([transform("a", "t", { position: position as TransformNode["position"] }), transform("b", "a", { rotation: rotation as TransformNode["rotation"] })]), 0).clones[0];
    vectorClose(clone.position, expected);
  });
  it("scales both the layout and geometry in XYZ", () => {
    const clone = evaluate(doc([transform("a", "t", { position: [1, 2, 3] }), transform("b", "a", { scale: [2, 3, 4] })]), 0).clones[0];
    vectorClose(clone.position, [2, 6, 12]);
    vectorClose(clone.scale, [2, 3, 4]);
  });
  it("composes in wire order rather than adding Euler angles or translations", () => {
    const movedThenRotated = evaluate(doc([transform("a", "t", { position: [2, 0, 0] }), transform("b", "a", { rotation: [0, 0, 90] })]), 0).clones[0];
    const rotatedThenMoved = evaluate(doc([transform("a", "t", { rotation: [0, 0, 90] }), transform("b", "a", { position: [2, 0, 0] })]), 0).clones[0];
    vectorClose(movedThenRotated.position, [0, 2, 0]);
    vectorClose(rotatedThenMoved.position, [2, 0, 0]);
  });
  it("transforms the cloned layout when placed after a cloner", () => {
    const grid: SceneNode = { id: "g", type: "GridCloner", inputs: ["t"], ui, count: [2, 1], spacing: 2 };
    const clones = evaluate(doc([grid, transform("trf", "g", { rotation: [0, 0, 90] })]), 0).clones;
    vectorClose(clones[0].position, [0, -1, 0]);
    vectorClose(clones[1].position, [0, 1, 0]);
  });
  it("preserves static source transforms through a cloner without rotating its layout", () => {
    const clones = evaluate(doc([transform("trf", "t", { rotation: [0, 0, 90], position: [3, 0, 0] }), { id: "g", type: "GridCloner", inputs: ["trf"], ui, count: [2, 1], spacing: 2 }]), 0).clones;
    vectorClose(clones[0].position, [2, 0, 0]);
    vectorClose(clones[1].position, [4, 0, 0]);
    expect(clones[0].rotation).toBeCloseTo(Math.PI / 2);
  });
  it("retains effector and spring animation and remains deterministic", () => {
    const scene = doc([
      { id: "e", type: "PlainEffector", inputs: ["t"], ui, start: 1, scale: [1, 3, 1], rotation: 0 },
      transform("trf", "e", { position: [2, 0, 0] }),
      { id: "s", type: "Spring", inputs: ["trf"], ui, stiffness: 0.5, damping: 0.5 },
    ]);
    expect(evaluate(scene, 0).clones[0].scale).toEqual([1, 1, 1]);
    expect(evaluate(scene, 3).clones[0].scale[1]).toBeGreaterThan(2);
    expect(evaluate(scene, 3)).toEqual(evaluate(structuredClone(scene), 3));
  });
  it("accepts one input and supports undo/redo of settings", () => {
    useScene.setState({ doc: defaultDoc, past: [], future: [] });
    useScene.getState().addNode("Transform", ui);
    useScene.getState().connect("txt_1", "trf_1");
    useScene.getState().connect("cln_1", "trf_1");
    expect(useScene.getState().doc.nodes.find((n) => n.id === "trf_1")?.inputs).toEqual(["cln_1"]);
    useScene.getState().updateNode("trf_1", { position: [1, 2, 3] });
    useScene.getState().undo();
    expect(useScene.getState().doc.nodes.find((n) => n.type === "Transform")?.position).toEqual([0, 0, 0]);
    useScene.getState().redo();
    expect(useScene.getState().doc.nodes.find((n) => n.type === "Transform")?.position).toEqual([1, 2, 3]);
  });
});

describe("Transform AE export boundaries", () => {
  const colors = { idle: [1, 1, 1] as [number, number, number], live: [0, 1, 0] as [number, number, number], bg: [0, 0, 0] as [number, number, number] };
  it("exports compatible planar transforms", () => {
    expect(() => aeScript(doc([transform("trf", "t", { position: [2, 3, 0], rotation: [0, 0, 90] })]), colors)).not.toThrow();
  });
  it.each([{ position: [0, 0, 2] }, { rotation: [30, 0, 0] }, { rotation: [0, 30, 0] }])("rejects unsupported 3D settings %j", (patch) => {
    expect(() => aeScript(doc([transform("trf", "t", patch as Partial<TransformNode>)]), colors)).toThrow("AE export supports flat transforms only");
  });
  it("rejects shear introduced by nonuniform scaling of rotated geometry", () => {
    expect(() => aeScript(doc([transform("a", "t", { rotation: [0, 0, 45] }), transform("b", "a", { scale: [2, 1, 1] })]), colors)).toThrow("sheared transforms");
  });
});