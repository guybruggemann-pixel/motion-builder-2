import type { DelayEffector } from "./schema";

/** Stagger follows the incoming clone order without moving or reordering clones. */
export function delayTargetTime(node: DelayEffector, index: number, count: number, time: number): number | null {
  const stagger = Number.isFinite(node.stagger) ? Math.max(0, node.stagger ?? 0) : 0;
  const rank = node.reverse ? count - 1 - index : index;
  const shifted = time - rank * stagger;
  return shifted < 0 ? null : shifted;
}

/** Zero strength bypasses Delay; full strength retains its filtered response and overshoot. */
export function delayBlend(node: DelayEffector, input: number, filtered: number): number {
  const strength = Number.isFinite(node.strength) ? Math.min(1, Math.max(0, node.strength ?? 1)) : 1;
  return strength === 0 ? input : strength === 1 ? filtered : input + (filtered - input) * strength;
}