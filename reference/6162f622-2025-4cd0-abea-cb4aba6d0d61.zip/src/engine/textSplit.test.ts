import { expect, it } from "vitest";
import { evaluate } from "./evaluate";
import { defaultDoc, type SceneDoc, type TextNode } from "./schema";

const text: TextNode = { id: "t", type: "TextNode", ui: { x: 0, y: 0 }, inputs: [], text: "FIRST\r\nSECOND\nTHIRD", split: "lines" };
const scene = (node: TextNode): SceneDoc => ({ ...defaultDoc, clusters: [], nodes: [node, { id: "out", type: "Preview", inputs: ["t"], ui: { x: 0, y: 0 } }] });
it("emits separate centered parts for each line", () => {
  const clones = evaluate(scene(text), 0).clones;
  expect(clones.map((c) => c.text)).toEqual(["FIRST", "SECOND", "THIRD"]);
  expect(clones.map((c) => c.position)).toEqual([[0, 1, 0], [0, 0, 0], [0, -1, 0]]);
});
it("keeps whole text as one clone", () => {
  const clones = evaluate(scene({ ...text, split: "none" }), 0).clones;
  expect(clones).toHaveLength(1);
  expect(clones[0].text).toBe(text.text);
  expect(clones[0].position).toEqual([0, 0, 0]);
});
it("preserves line placement through downstream cloners", () => {
  const doc = scene(text);
  doc.nodes.splice(1, 0, { id: "g", type: "GridCloner", inputs: ["t"], ui: { x: 0, y: 0 }, count: [2, 1], spacing: 2 });
  doc.nodes[2].inputs = ["g"];
  const clones = evaluate(doc, 0).clones;
  expect(clones).toHaveLength(6);
  expect(clones.map((c) => c.position)).toEqual([[-1, 1, 0], [1, 1, 0], [-1, 0, 0], [1, 0, 0], [-1, -1, 0], [1, -1, 0]]);
});