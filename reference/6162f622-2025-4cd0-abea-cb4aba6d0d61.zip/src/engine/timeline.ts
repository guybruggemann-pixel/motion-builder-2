import type { LinearField, SphericalField, Vec3 } from "./schema";
import { editableField, fieldInterval } from "./fieldMotion";
import { editableSphere } from "./sphericalMotion";

export type TimelineField = LinearField | SphericalField;

export function editFieldBoundary(field: TimelineField, boundary: "start" | "end", value: number, duration: number, fps: number, positions: Vec3[]): TimelineField {
  if (!Number.isFinite(value)) return field;
  const resolved = field.type === "LinearField"
    ? editableField(field, duration, positions.map((position) => position[0]))
    : editableSphere(field, duration, positions);
  const interval = fieldInterval(resolved, duration);
  const snapped = Math.min(duration, Math.max(0, Math.round(value * fps) / fps));
  return boundary === "start"
    ? { ...resolved, start: Math.min(interval.end, snapped) }
    : { ...resolved, end: Math.max(interval.start, snapped) };
}