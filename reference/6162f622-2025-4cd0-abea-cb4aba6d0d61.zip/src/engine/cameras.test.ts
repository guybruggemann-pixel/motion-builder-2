import { beforeEach, describe, expect, it } from "vitest";
import { activeCamera, cameraError, cameraView, newCamera } from "./cameras";
import { defaultDoc } from "./schema";
import { fitZoom } from "./framing";
import { useScene } from "./store";
import { aeScript } from "./aeExport";

describe("scene cameras", () => {
  beforeEach(() => useScene.setState({ doc: defaultDoc, past: [], future: [] }));
  it("keeps old documents on their automatic front camera", () => {
    expect(activeCamera(defaultDoc)).toBeUndefined();
    const view = cameraView(undefined, 1920, 1080, 12);
    expect(view.top * 2).toBe(1080 / fitZoom(1920, 1080, 12));
    expect(view.position).toEqual([0, 0, 10]);
  });
  it("uses the same orthographic world framing across output resolutions", () => {
    const camera = { ...newCamera("cam_1", 12), zoom: 2 };
    const small = cameraView(camera, 960, 540, 20), large = cameraView(camera, 1920, 1080, 2);
    expect(small).toEqual(large);
    expect(large.top).toBe(3);
    expect(large.right).toBeCloseTo(16 / 3);
  });
  it("resolves perspective lens, position, target and portrait aspect", () => {
    const camera = { ...newCamera("cam_1", 12), projection: "perspective" as const, fov: 60, position: [4, 2, 20] as [number, number, number], target: [1, 0, 0] as [number, number, number] };
    const view = cameraView(camera, 1080, 1920, 10);
    expect(view.aspect).toBe(9 / 16);
    expect(view.fov).toBe(60);
    expect(view.position).toEqual([4, 2, 20]);
    expect(view.target).toEqual([1, 0, 0]);
  });
  it("rejects singular and invalid camera settings without creating history", () => {
    const camera = newCamera("cam_1", 12);
    expect(cameraError({ ...camera, position: [0, 0, 0] })).not.toBeNull();
    useScene.getState().addCamera(12);
    const before = useScene.getState().doc;
    expect(useScene.getState().updateCamera("cam_1", { fov: 180 })).not.toBeNull();
    expect(useScene.getState().updateCamera("cam_1", { zoom: 0 })).not.toBeNull();
    expect(useScene.getState().doc).toBe(before);
    expect(cameraError({ ...camera, target: [NaN, 0, 0] })).not.toBeNull();
  });
  it("adds, duplicates, edits and deletes active cameras undoably", () => {
    useScene.getState().addCamera(12);
    useScene.getState().updateCamera("cam_1", { position: [3, 2, 10], name: "Main" });
    useScene.getState().addCamera(12, "cam_1");
    expect(activeCamera(useScene.getState().doc)?.position).toEqual([3, 2, 10]);
    expect(activeCamera(useScene.getState().doc)?.name).toBe("Main copy");
    useScene.getState().removeCamera("cam_2");
    expect(activeCamera(useScene.getState().doc)).toBeUndefined();
    useScene.getState().undo();
    expect(activeCamera(useScene.getState().doc)?.id).toBe("cam_2");
    useScene.getState().redo();
    expect(useScene.getState().doc.cameras).toHaveLength(1);
    useScene.getState().setActiveCamera("cam_1");
    expect(activeCamera(useScene.getState().doc)?.name).toBe("Main");
    useScene.getState().setActiveCamera();
    expect(activeCamera(useScene.getState().doc)).toBeUndefined();
  });
  it("rejects custom-camera AE output instead of silently changing the frame", () => {
    const colors = { idle: [1, 1, 1] as [number, number, number], live: [1, 1, 1] as [number, number, number], bg: [0, 0, 0] as [number, number, number] };
    useScene.getState().addCamera(12);
    expect(() => aeScript(useScene.getState().doc, colors)).toThrow("Auto framing only");
    useScene.getState().setActiveCamera();
    expect(() => aeScript(useScene.getState().doc, colors)).not.toThrow();
  });
});