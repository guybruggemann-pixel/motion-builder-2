import { afterEach, describe, expect, it } from "vitest";
import { maskPosition } from "./maskMotion";
import { evaluate } from "./evaluate";
import { getFrame } from "./bake";
import { useScene } from "./store";
import { type MaskNode, type SceneDoc } from "./schema";

const mask: MaskNode = { id: "m", type: "Mask", inputs: ["b"], ui: { x: 0, y: 0 }, axis: "x", from: -4, to: 4, invert: false, start: 1, end: 3, curve: "linear" };
const doc = (m = mask): SceneDoc => ({ meta: { fps: 30, duration: 4, mode: "web-native" }, clusters: [], nodes: [
  { id: "b", type: "BoxPrimitive", size: 1, inputs: [], ui: { x: 0, y: 0 } }, m,
  { id: "o", type: "Preview", inputs: ["m"], ui: { x: 0, y: 0 } },
] });
const initial = useScene.getState();
afterEach(() => useScene.setState(initial));

describe("Mask motion", () => {
  it("holds endpoints outside the absolute 1–3 second interval", () => {
    expect([0, 1, 2, 3, 4].map((t) => maskPosition(mask, t, 4))).toEqual([-4, -4, 0, 4, 4]);
  });
  it("supports reversed wipe endpoints", () => {
    expect([1, 2, 3].map((t) => maskPosition({ ...mask, from: 4, to: -4 }, t, 4))).toEqual([4, 0, -4]);
  });
  it("preserves legacy linear wipes to scene end", () => {
    const legacy = { ...mask, end: undefined, curve: undefined };
    expect(maskPosition(legacy, 0, 4)).toBe(-4);
    expect(maskPosition(legacy, 2.5, 4)).toBe(0);
    expect(maskPosition(legacy, 4, 4)).toBe(4);
    expect(maskPosition({ ...legacy, start: 4 }, 0, 4)).toBe(4);
  });
  it("makes an instantaneous cut at an equal start/end", () => {
    const instant = { ...mask, end: 1 };
    expect(maskPosition(instant, 0, 4)).toBe(-4);
    expect(maskPosition(instant, 1, 4)).toBe(4);
  });
  it("uses preset easing while retaining exact endpoints", () => {
    const eased = { ...mask, curve: "ease-in" as const };
    expect(maskPosition(eased, 1, 4)).toBe(-4);
    expect(maskPosition(eased, 2, 4)).toBeCloseTo(-1.4771455);
    expect(maskPosition(eased, 3, 4)).toBe(4);
  });
  it("uses custom Bézier controls", () => {
    expect(maskPosition({ ...mask, curve: "custom", bezier: [0, 0, 1, 1] }, 2, 4)).toBe(0);
  });
  it("emits independent stacked Z and Y planes with invert intact", () => {
    const d = doc({ ...mask, axis: "z", invert: true });
    d.nodes.splice(2, 0, { ...mask, id: "m2", inputs: ["m"], axis: "y" });
    d.nodes[d.nodes.length - 1].inputs = ["m2"];
    expect(evaluate(d, 2).clones[0].clips).toEqual([
      { id: "m", axis: "z", invert: true, value: 0 },
      { id: "m2", axis: "y", invert: false, value: 0 },
    ]);
  });
  it("keeps a static cut when edge endpoints match", () => {
    expect(maskPosition({ ...mask, from: 2, to: 2 }, 2, 4)).toBe(2);
  });
  it("reads edited clip values through bake and undo/redo", () => {
    const d = doc();
    useScene.setState({ doc: d, past: [], future: [] });
    expect(getFrame(d, 2).clones[0].clips[0].value).toBe(0);
    useScene.getState().updateNode("m", { end: 2, axis: "z" });
    const edited = useScene.getState().doc;
    expect(getFrame(edited, 2).clones[0].clips[0]).toEqual({ id: "m", axis: "z", invert: false, value: 4 });
    useScene.getState().undo();
    expect(useScene.getState().doc).toBe(d);
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(edited);
    expect(evaluate(edited, 2)).toEqual(getFrame(edited, 2));
  });
});