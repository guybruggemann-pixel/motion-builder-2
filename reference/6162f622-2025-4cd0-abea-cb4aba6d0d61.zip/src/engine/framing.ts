import type { Clone } from "./evaluate";

/** World-space font size of text clones (text planes are FONT_SIZE * 1.3 tall). */
export const FONT_SIZE = 0.42;

/** How much of the world a frame needs to show (text is wider than tall, so X is weighted more). */
export function extentOf(clones: Clone[]): number {
  if (!clones.length) return 6;
  let mx = 0;
  let my = 0;
  for (const c of clones) {
    mx = Math.max(mx, Math.abs(c.position[0]));
    my = Math.max(my, Math.abs(c.position[1]));
  }
  return Math.max(2 * mx + (clones.some((c) => c.shape === "text") ? 2 : 1), (2 * my + 1) * 1.8);
}

/** Pixels per world unit for a w x h frame — shared by preview, render and AE export. */
export const fitZoom = (w: number, h: number, extent: number) => Math.min(w / (extent + 3), h / (extent / 1.6 + 2));
