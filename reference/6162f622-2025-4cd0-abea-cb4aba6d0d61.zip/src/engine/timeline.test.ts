import { describe, expect, it } from "vitest";
import { editFieldBoundary } from "./timeline";
import type { LinearField, SphericalField } from "./schema";

const field: LinearField = { id: "field", type: "LinearField", inputs: [], ui: { x: 0, y: 0 }, falloff: 2, from: -5, to: 5, start: 1, end: 3 };
describe("field timeline boundaries", () => {
  it("sets the in point independently on a frame boundary", () => {
    const edited = editFieldBoundary(field, "start", 1.24, 4, 30, []);
    expect(edited.start).toBe(37 / 30);
    expect(edited.end).toBe(3);
  });
  it("sets the out point independently on a frame boundary", () => {
    const edited = editFieldBoundary(field, "end", 2.24, 4, 30, []);
    expect(edited.end).toBe(67 / 30);
    expect(edited.start).toBe(1);
  });
  it("keeps in and out ordered inside the scene", () => {
    expect(editFieldBoundary(field, "start", 5, 4, 30, []).start).toBe(3);
    expect(editFieldBoundary(field, "start", -5, 4, 30, []).start).toBe(0);
    expect(editFieldBoundary(field, "end", -5, 4, 30, []).end).toBe(1);
    expect(editFieldBoundary(field, "end", 5, 4, 30, []).end).toBe(4);
  });
  it("resolves legacy linear endpoints when setting out", () => {
    const legacy: LinearField = { id: "old", type: "LinearField", inputs: [], ui: { x: 0, y: 0 }, falloff: 2, speed: 1 };
    const edited = editFieldBoundary(legacy, "end", 2, 4, 30, [[-3, 0, 0], [4, 0, 0]]);
    expect(edited).toMatchObject({ from: -5, to: 6, end: 2, start: 0, curve: "linear", speed: undefined });
    expect(legacy.speed).toBe(1);
  });
  it("supports spherical in/out and resolves legacy radius", () => {
    const sphere: SphericalField = { id: "sphere", type: "SphericalField", inputs: [], ui: { x: 0, y: 0 }, falloff: 2, speed: 1 };
    const edited = editFieldBoundary(sphere, "end", 2, 4, 30, [[3, 4, 0]]);
    expect(edited).toMatchObject({ radiusFrom: 0, radiusTo: 7, start: 0, end: 2, speed: undefined });
    expect(editFieldBoundary(edited, "start", 1, 4, 30, []).start).toBe(1);
  });
});