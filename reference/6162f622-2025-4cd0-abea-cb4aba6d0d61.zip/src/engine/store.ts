import { create } from "zustand";
import { createNode, defaultDoc, ID_PREFIX, MAX_INPUTS, type Cluster, type NodeType, type SceneDoc, type SceneNode, type SceneCamera } from "./schema";
import { cameraError, newCamera } from "./cameras";

interface SceneState {
  doc: SceneDoc;
  past: SceneDoc[];
  future: SceneDoc[];
  selectedId: string | null;
  select: (id: string | null) => void;
  updateNode: (id: string, patch: Partial<SceneNode>) => void;
  updateMeta: (patch: Partial<SceneDoc["meta"]>) => void;
  addCamera: (viewHeight: number, sourceId?: string) => void;
  updateCamera: (id: string, patch: Partial<Omit<SceneCamera, "id">>) => string | null;
  removeCamera: (id: string) => void;
  setActiveCamera: (id?: string) => void;
  addNode: (type: NodeType, ui: { x: number; y: number }) => void;
  removeNodes: (ids: string[]) => void;
  moveNode: (id: string, ui: { x: number; y: number }) => void;
  connect: (source: string, target: string) => void;
  disconnect: (source: string, target: string) => void;
  addCluster: (c: Omit<Cluster, "id">) => void;
  updateCluster: (id: string, patch: Partial<Cluster>, history?: boolean) => void;
  removeClusters: (ids: string[]) => void;
  undo: () => void;
  redo: () => void;
}

const nextId = (doc: SceneDoc, prefix: string) => {
  const used = new Set([...doc.nodes.map((n) => n.id), ...doc.clusters.map((c) => c.id)]);
  let i = 1;
  while (used.has(`${prefix}_${i}`)) i++;
  return `${prefix}_${i}`;
};

export const useScene = create<SceneState>((set) => {
  /** Apply a change and record it in undo history. */
  const commit = (fn: (doc: SceneDoc) => SceneDoc) =>
    set((s) => ({ past: [...s.past.slice(-99), s.doc], future: [], doc: fn(s.doc) }));
  /** Apply a change without history (continuous drags). */
  const live = (fn: (doc: SceneDoc) => SceneDoc) => set((s) => ({ doc: fn(s.doc) }));

  return {
    doc: defaultDoc,
    past: [],
    future: [],
    selectedId: "dly_1",
    select: (selectedId) => set({ selectedId }),
    updateNode: (id, patch) =>
      commit((d) => ({ ...d, nodes: d.nodes.map((n) => (n.id === id ? ({ ...n, ...patch } as SceneNode) : n)) })),
    updateMeta: (patch) => commit((d) => ({ ...d, meta: { ...d.meta, ...patch } })),
    addCamera: (viewHeight, sourceId) => commit((d) => {
      const cameras = d.cameras ?? [];
      let i = 1;
      while (cameras.some((camera) => camera.id === `cam_${i}`)) i++;
      const id = `cam_${i}`;
      const source = cameras.find((camera) => camera.id === sourceId);
      const camera = source ? { ...source, id, name: `${source.name} copy`, position: [...source.position] as SceneCamera["position"], target: [...source.target] as SceneCamera["target"] } : newCamera(id, Number.isFinite(viewHeight) && viewHeight > 0 ? viewHeight : 12);
      return { ...d, cameras: [...cameras, camera], activeCameraId: id };
    }),
    updateCamera: (id, patch) => {
      let error: string | null = "Camera not found.";
      set((s) => {
        const camera = s.doc.cameras?.find((camera) => camera.id === id);
        if (!camera) return s;
        const updated = { ...camera, ...patch, id };
        error = cameraError(updated);
        if (error) return s;
        return { doc: { ...s.doc, cameras: s.doc.cameras?.map((camera) => camera.id === id ? updated : camera) }, past: [...s.past.slice(-99), s.doc], future: [] };
      });
      return error;
    },
    removeCamera: (id) => commit((d) => ({ ...d, cameras: d.cameras?.filter((camera) => camera.id !== id), activeCameraId: d.activeCameraId === id ? undefined : d.activeCameraId })),
    setActiveCamera: (id) => commit((d) => ({ ...d, activeCameraId: d.cameras?.some((camera) => camera.id === id) ? id : undefined })),
    addNode: (type, ui) =>
      set((s) => {
        if (type === "Preview") return s; // the single Preview output is built in
        const id = nextId(s.doc, ID_PREFIX[type]);
        return {
          past: [...s.past.slice(-99), s.doc],
          future: [],
          selectedId: id,
          doc: { ...s.doc, nodes: [...s.doc.nodes, createNode(type, id, ui)] },
        };
      }),
    removeNodes: (ids) =>
      commit((d) => ({
        ...d,
        nodes: d.nodes.filter((n) => n.type === "Preview" || !ids.includes(n.id)).map((n) => ({ ...n, inputs: n.inputs.filter((i) => !ids.includes(i)) })),
      })),
    moveNode: (id, ui) => live((d) => ({ ...d, nodes: d.nodes.map((n) => (n.id === id ? { ...n, ui } : n)) })),
    connect: (source, target) =>
      commit((d) => ({
        ...d,
        nodes: d.nodes.map((n) => {
          if (n.id !== target || source === target || n.inputs.includes(source)) return n;
          const max = MAX_INPUTS[n.type];
          if (max === 0) return n;
          return { ...n, inputs: max === 1 ? [source] : [...n.inputs, source] };
        }),
      })),
    disconnect: (source, target) =>
      commit((d) => ({
        ...d,
        nodes: d.nodes.map((n) => (n.id === target ? { ...n, inputs: n.inputs.filter((i) => i !== source) } : n)),
      })),
    addCluster: (c) => commit((d) => ({ ...d, clusters: [...d.clusters, { ...c, id: nextId(d, "grp") }] })),
    updateCluster: (id, patch, history = true) =>
      (history ? commit : live)((d) => ({ ...d, clusters: d.clusters.map((c) => (c.id === id ? { ...c, ...patch } : c)) })),
    removeClusters: (ids) => commit((d) => ({ ...d, clusters: d.clusters.filter((c) => !ids.includes(c.id)) })),
    undo: () =>
      set((s) => (s.past.length ? { doc: s.past[s.past.length - 1], past: s.past.slice(0, -1), future: [s.doc, ...s.future] } : s)),
    redo: () =>
      set((s) => (s.future.length ? { doc: s.future[0], future: s.future.slice(1), past: [...s.past, s.doc] } : s)),
  };
});
