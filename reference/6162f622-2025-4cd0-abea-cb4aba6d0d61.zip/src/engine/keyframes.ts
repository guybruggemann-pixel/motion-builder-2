import BezierEasing from "bezier-easing";
import type { BezierPoints, SceneNode } from "./schema";

/** Easing applied on the segment that leaves a key. */
export type KeyEase = "linear" | "smooth" | "hold" | "bezier";
export interface Key { t: number; v: number; ease?: KeyEase; bezier?: BezierPoints }
export type AnimMap = Record<string, Key[]>;

const SNAP = 1e-6;
const sorted = (keys: Key[]) => [...keys].sort((a, b) => a.t - b.t);

function eased(k: Key, u: number) {
  switch (k.ease ?? "smooth") {
    case "linear": return u;
    case "hold": return 0;
    case "bezier": { const [a, b, c, d] = k.bezier ?? [0.42, 0, 0.58, 1]; return BezierEasing(a, b, c, d)(u); }
    default: return u * u * (3 - 2 * u);
  }
}

/** Pure sample of a key list at time t (clamped before first / after last key). */
export function sampleKeys(keys: Key[], t: number): number {
  const ks = sorted(keys);
  if (t <= ks[0].t) return ks[0].v;
  const last = ks[ks.length - 1];
  if (t >= last.t) return last.v;
  for (let i = 0; i < ks.length - 1; i++) {
    const a = ks[i], b = ks[i + 1];
    if (t < b.t) return a.v + (b.v - a.v) * eased(a, (t - a.t) / (b.t - a.t));
  }
  return last.v;
}

export function animOf(node: SceneNode): AnimMap | undefined {
  return (node as { anim?: AnimMap }).anim;
}

/** Node with all keyed top-level numeric params replaced by their value at t. Unkeyed nodes are returned as-is. */
export function resolveNode<N extends SceneNode>(node: N, t: number): N {
  const anim = animOf(node);
  if (!anim) return node;
  const out = { ...node } as Record<string, unknown>;
  for (const [path, keys] of Object.entries(anim)) {
    if (!keys.length) continue;
    const [name, idx] = path.split(".");
    if (idx === undefined) { out[name] = sampleKeys(keys, t); continue; }
    const vec = [...((out[name] as number[] | undefined) ?? [0, 0, 0])];
    vec[Number(idx)] = sampleKeys(keys, t);
    out[name] = vec;
  }
  return out as N;
}

export function keyAt(keys: Key[] | undefined, t: number) {
  return keys?.find((k) => Math.abs(k.t - t) < SNAP);
}

/** Insert or replace a key at t; returns a new list. */
export function setKey(keys: Key[] | undefined, t: number, v: number): Key[] {
  const prev = keyAt(keys, t);
  const rest = (keys ?? []).filter((k) => k !== prev);
  return sorted([...rest, { ease: "smooth", ...prev, t, v }]);
}

export function removeKey(keys: Key[] | undefined, t: number): Key[] {
  return (keys ?? []).filter((k) => Math.abs(k.t - t) >= SNAP);
}

export function neighbourKey(keys: Key[] | undefined, t: number, dir: 1 | -1) {
  const ks = sorted(keys ?? []);
  return dir > 0 ? ks.find((k) => k.t > t + SNAP) : [...ks].reverse().find((k) => k.t < t - SNAP);
}
