import { afterEach, describe, expect, it } from "vitest";
import { delayBlend, delayTargetTime } from "./delayMotion";
import { createNode, type DelayEffector, type SceneDoc } from "./schema";
import { evaluate } from "./evaluate";
import { getFrame } from "./bake";
import { useScene } from "./store";

const ui = { x: 0, y: 0 };
const delay: DelayEffector = { id: "d", type: "DelayEffector", inputs: ["e"], ui, tension: 0.5, friction: 0.3 };
function scene(patch: Partial<DelayEffector> = {}): SceneDoc {
  return { meta: { fps: 30, duration: 3, mode: "web-native" }, clusters: [], nodes: [
    { id: "b", type: "BoxPrimitive", size: 1, inputs: [], ui },
    { id: "g", type: "GridCloner", count: [3, 1], spacing: 1, inputs: ["b"], ui },
    { id: "e", type: "PlainEffector", scale: [1, 3, 1], rotation: 0, inputs: ["g"], ui },
    { ...delay, ...patch }, { id: "o", type: "Preview", inputs: ["d"], ui },
  ] };
}
const original = useScene.getState();
afterEach(() => useScene.setState(original));

describe("Delay motion", () => {
  it("retains legacy defaults including frame-zero initialization", () => {
    const explicit = scene({ stagger: 0, reverse: false, strength: 1 });
    for (const t of [0, 1 / 30, 0.5, 2, 3]) expect(evaluate(scene(), t)).toEqual(evaluate(explicit, t));
    expect(evaluate(scene(), 0).clones[0].scale).toEqual([1, 1, 1]);
    expect(evaluate(scene(), 1 / 30).clones[0].weight).toBeCloseTo(110 / 900);
  });
  it("new nodes explicitly preserve the legacy response", () => {
    expect(createNode("DelayEffector", "d", ui)).toMatchObject({ stagger: 0, reverse: false, strength: 1 });
  });
  it("stagger uses seconds per incoming clone and holds before onset", () => {
    expect(delayTargetTime({ ...delay, stagger: 0.25 }, 2, 3, 0.4)).toBeNull();
    expect(delayTargetTime({ ...delay, stagger: 0.25 }, 2, 3, 0.75)).toBe(0.25);
    expect(evaluate(scene({ stagger: 0.5 }), 0.25).clones.map((c) => c.weight)).toEqual([expect.any(Number), 0, 0]);
    expect(evaluate(scene({ stagger: 0.5 }), 0.25).clones[0].weight).toBeGreaterThan(0);
  });
  it("reverse changes stagger direction without moving clone geometry", () => {
    const forward = evaluate(scene({ stagger: 0.5 }), 0.25);
    const reverse = evaluate(scene({ stagger: 0.5, reverse: true }), 0.25);
    expect(reverse.clones.map((c) => c.position)).toEqual(forward.clones.map((c) => c.position));
    expect(reverse.clones.map((c) => c.weight)).toEqual(forward.clones.map((c) => c.weight).reverse());
  });
  it("reverse has no effect at zero stagger, even with different upstream clone weights", () => {
    const d = scene();
    d.nodes.push({ id: "w", type: "SineWave", inputs: [], ui, frequency: 1, offset: 0.3 });
    d.nodes = d.nodes.map((n) => n.type === "PlainEffector" ? { ...n, inputs: [...n.inputs, "w"] } : n);
    const reversed = { ...d, nodes: d.nodes.map((n) => n.type === "DelayEffector" ? { ...n, reverse: true } : n) };
    expect(evaluate(reversed, 0.5)).toEqual(evaluate(d, 0.5));
  });
  it("zero strength bypasses Delay rather than removing the upstream effect", () => {
    const d = scene({ strength: 0, stagger: 1 });
    const bypass = { ...d, nodes: d.nodes.map((n) => n.type === "Preview" ? { ...n, inputs: ["e"] } : n) };
    for (const t of [0, 0.25, 2]) expect(evaluate(d, t)).toEqual(evaluate(bypass, t));
  });
  it("half strength blends upstream and filtered weights and preserves overshoot", () => {
    expect(delayBlend({ ...delay, strength: 0.5 }, 0.8, 0.2)).toBeCloseTo(0.5);
    expect(delayBlend(delay, 1, 1.4)).toBe(1.4);
    const full = evaluate(scene(), 0.25).clones[0].weight;
    expect(evaluate(scene({ strength: 0.5 }), 0.25).clones[0].weight).toBeCloseTo((1 + full) / 2);
  });
  it("clamps strength and treats invalid optional values as legacy defaults", () => {
    expect(delayBlend({ ...delay, strength: -2 }, 0.8, 0.2)).toBe(0.8);
    expect(delayBlend({ ...delay, strength: 2 }, 0.8, 0.2)).toBe(0.2);
    expect(delayBlend({ ...delay, strength: NaN }, 0.8, 0.2)).toBe(0.2);
    expect(delayTargetTime({ ...delay, stagger: Infinity }, 2, 3, 0.5)).toBe(0.5);
    expect(delayTargetTime({ ...delay, stagger: -1 }, 2, 3, 0.5)).toBe(0.5);
  });
  it("stagger spans split-text parts in the incoming stream", () => {
    const d = scene({ stagger: 0.5 });
    d.nodes = d.nodes.filter((n) => n.id !== "g").map((n) => n.id === "b" ? { id: "b", type: "TextNode" as const, text: "A\nB\nC", split: "lines" as const, inputs: [], ui } : n.type === "PlainEffector" ? { ...n, inputs: ["b"] } : n);
    const frame = evaluate(d, 0.25);
    expect(frame.clones.map((c) => c.text)).toEqual(["A", "B", "C"]);
    expect(frame.clones[0].weight).toBeGreaterThan(0);
    expect(frame.clones.slice(1).map((c) => c.weight)).toEqual([0, 0]);
  });
  it("agrees for cached, sequential and random-access sampling through chained sims", () => {
    const d = scene({ stagger: 0.1, reverse: true, strength: 0.5 });
    d.nodes.push({ id: "s", type: "Spring", stiffness: 0.6, damping: 0.15, inputs: ["d"], ui });
    d.nodes = d.nodes.map((n) => n.type === "Preview" ? { ...n, inputs: ["s"] } : n);
    for (let f = 0; f <= 90; f++) getFrame(d, f / 30);
    for (const f of [90, 4, 60, 0, 15]) expect(getFrame(d, f / 30)).toEqual(evaluate(structuredClone(d), f / 30));
  });
  it("edits invalidate caches and undo/redo restores the corresponding frame", () => {
    const d = scene();
    useScene.setState({ doc: d, past: [], future: [] });
    const before = getFrame(d, 0.25);
    useScene.getState().updateNode("d", { stagger: 0.5 });
    const changed = useScene.getState().doc;
    expect(getFrame(changed, 0.25)).not.toEqual(before);
    useScene.getState().undo();
    expect(getFrame(useScene.getState().doc, 0.25)).toEqual(before);
    useScene.getState().redo();
    expect(useScene.getState().doc).toBe(changed);
  });
});