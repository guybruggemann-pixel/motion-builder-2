/**
 * Bridge between the lazy-loaded 3D preview and the renderer: the preview registers a function
 * that draws the current scene off-screen at any size and returns top-down RGBA pixels.
 * Kept free of three.js imports so it is SSR-safe.
 */
export type Capture = { draw: (width: number, height: number) => Uint8Array; dispose: () => void };

let current: Capture | null = null;
export const registerCapture = (c: Capture | null) => (current = c);
export const getCapture = () => current;
