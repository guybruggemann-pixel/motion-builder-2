import { describe, expect, it } from "vitest";
import { fieldPosition, easeProgress, fieldInterval } from "./fieldMotion";
import { evaluate } from "./evaluate";
import { getFrame } from "./bake";
import { defaultDoc, type LinearField, type SceneDoc } from "./schema";

const field: LinearField = {
  id: "f", type: "LinearField", inputs: [], ui: { x: 0, y: 0 },
  falloff: 2, from: -4, to: 4, start: 1, end: 3, curve: "linear",
};

describe("Linear Field motion", () => {
  it("holds the start position before Start and the end position after End", () => {
    expect(fieldPosition(field, 0, 4, [0])).toBe(-4);
    expect(fieldPosition(field, 1, 4, [0])).toBe(-4);
    expect(fieldPosition(field, 3, 4, [0])).toBe(4);
    expect(fieldPosition(field, 4, 4, [0])).toBe(4);
  });
  it("derives speed from the interval rather than a speed parameter", () => {
    expect(fieldPosition(field, 2, 4, [0])).toBe(0);
    expect(fieldPosition({ ...field, end: 2 }, 1.5, 4, [0])).toBe(0);
    expect(fieldPosition({ ...field, speed: 99 }, 2, 4, [0])).toBe(0);
  });
  it("supports reverse sweeps and static endpoints", () => {
    expect(fieldPosition({ ...field, from: 4, to: -4 }, 1.5, 4, [0])).toBe(2);
    expect(fieldPosition({ ...field, from: 2, to: 2 }, 2, 4, [0])).toBe(2);
  });
  it("moves slower early for Ease in and faster early for Ease out", () => {
    expect(easeProgress(0.25, "ease-in")).toBeLessThan(0.25);
    expect(easeProgress(0.25, "ease-out")).toBeGreaterThan(0.25);
    expect(easeProgress(0.5, "ease-in-out")).toBeCloseTo(0.5);
  });
  it("evaluates the custom curve and preserves exact endpoints", () => {
    expect(easeProgress(0.5, "custom", [0, 0, 1, 0])).toBeCloseTo(0.125);
    expect(easeProgress(0, "custom", [0, 0, 1, 0])).toBe(0);
    expect(easeProgress(1, "custom", [0, 0, 1, 0])).toBe(1);
  });
  it("defaults End to scene length and handles zero-length intervals", () => {
    expect(fieldInterval({ ...field, end: undefined }, 6)).toEqual({ start: 1, end: 6 });
    expect(fieldPosition({ ...field, end: 1 }, 0.5, 4, [0])).toBe(-4);
    expect(fieldPosition({ ...field, end: 1 }, 1, 4, [0])).toBe(4);
    expect(fieldInterval({ ...field, start: 3, end: 1 }, 4)).toEqual({ start: 3, end: 3 });
  });
  it("retains automatic looping for Speed-only legacy documents", () => {
    const legacy: LinearField = { id: "f", type: "LinearField", inputs: [], ui: { x: 0, y: 0 }, falloff: 2, speed: 1 };
    expect(fieldPosition(legacy, 0, 4, [-2, 2])).toBe(-4);
    expect(fieldPosition(legacy, 2, 4, [-2, 2])).toBe(0);
    expect(fieldPosition(legacy, 4, 4, [-2, 2])).toBe(-4);
  });
  it("uses the new motion in deterministic evaluation and cached frames", () => {
    const doc: SceneDoc = { ...defaultDoc, nodes: defaultDoc.nodes.filter((n) => n.type !== "DelayEffector").map((n) => {
      if (n.type === "LinearField") return { ...field, id: n.id, curve: "ease-in" };
      if (n.type === "Preview") return { ...n, inputs: ["eff_1"] };
      return n;
    }) };
    const midpoint = evaluate(doc, 2);
    expect(midpoint.clones.some((c) => c.weight > 0 && c.weight < 1)).toBe(true);
    expect(getFrame(doc, 2)).toEqual(midpoint);
    expect(evaluate(structuredClone(doc), 2)).toEqual(midpoint);
    expect(evaluate(doc, 4).clones.map((c) => c.scale)).toEqual(evaluate(doc, 3).clones.map((c) => c.scale));
  });
});